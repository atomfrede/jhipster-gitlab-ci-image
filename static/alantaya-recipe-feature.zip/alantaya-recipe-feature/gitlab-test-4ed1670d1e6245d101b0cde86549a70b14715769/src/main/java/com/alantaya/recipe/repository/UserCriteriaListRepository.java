package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserCriteriaList;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for the UserBiometricList entity.
 */
public interface UserCriteriaListRepository extends JpaRepository<UserCriteriaList,Long> {

    public UserCriteriaList findByUserId(Long userId);

}
