package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.enumeration.UserState;
import com.fasterxml.jackson.annotation.JsonIgnore;
import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.*;
import org.hibernate.validator.constraints.Email;
import org.jasypt.hibernate4.type.EncryptedStringType;
import org.joda.time.DateTime;

import javax.persistence.CascadeType;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A user.
 */
@Entity
@Table(name = "T_USER")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@TypeDefs({
    @TypeDef(
        name = "encryptedString",
        typeClass = EncryptedStringType.class,
        parameters = {
            @org.hibernate.annotations.Parameter(name = "encryptorRegisteredName", value = "hibernateStringEncryptor")
        })}
)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class User extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @JsonIgnore
    @NotNull
    @Size(min = 5, max = 100)
    @Column(length = 100)
    private String password;

    @Size(max = 50)
    @Column(name = "first_name", length = 50)
    private String firstName;

    @Size(max = 50)
    @Column(name = "last_name", length = 50)
    private String lastName;

    @Email
    @Size(max = 100)
    @Column(length = 100, unique = true)
    private String email;

    @Size(max = 20)
    @Column(name = "phone_number",length = 20)
    private String phoneNumber;

    @Column(columnDefinition = "enum('ACTIVE','PENDING','DELETED') NOT NULL")
    @Enumerated(EnumType.STRING)
    private UserState state = UserState.PENDING;

    @Size(min = 2, max = 5)
    @Column(name = "lang_key", length = 5)
    private String langKey;

    @Size(max = 20)
    @Column(name = "activation_key", length = 20)
    private String activationKey;

    @Size(max = 20)
    @Column(name = "reset_key", length = 20)
    private String resetKey;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "reset_date", nullable = true)
    private DateTime resetDate = null;

    @JsonIgnore
    @Size(min = 5, max = 100)
    @Column(name = "one_time_password", length = 100)
    @Type(type = "encryptedString")
    private String oneTimePassword;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "last_login_attempt", nullable = true)
    private DateTime lastLoginAttempt = null;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "subscription_package_id")
    private SubscriptionPackage subscriptionPackage;

    @JsonIgnore
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "subscription_expiration_date", nullable = true)
    private DateTime subscriptionExpirationDate = null;

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "T_USER_AUTHORITY",
        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "authority_name", referencedColumnName = "name")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Authority> authorities = new HashSet<>();

    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "user")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<PersistentToken> persistentTokens = new HashSet<>();

    @ManyToOne
    private UserType userType;

    @ManyToOne
    @JoinColumn(name = "questionnaire_current_page_id")
    private QuestionnairePage currentQuestionnairePage;

    @ManyToOne
    @JoinColumn(name = "user_questionnaire_state_name")
    private UserQuestionnaireState questionnaireState;

    @ManyToMany
    @JoinTable(
        name = "T_USER_DISLIKED_FOODS",
        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "basicfood_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<BasicFood> dislikedFoods = new HashSet<>();

    @ManyToMany
    @JoinTable(
        name = "USER_MISSING_EQUIPMENT",
        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "cookingmode_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<CookingMode> missingEquipment = new HashSet<>();

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "city_id")
    private City city = null;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "author_id")
    private Author author = null;

    @Size(max = 250)
    @Column(name = "partner_code", length = 250)
    private String partnerCode;

    @Column(name = "is_generation_in_progress", nullable = false)
    private boolean isGenerationInProgress = false;

    @OneToOne
    @JoinColumn(name = "user_professional_information_id")
    private UserProfessionalInformation userProfessionalInformation;

    @ManyToMany
    @JoinTable(
        name = "user_relationship",
        joinColumns = {@JoinColumn(name = "supervisor_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<User> supervisedUsers = new HashSet<>();

    @Column(name = "is_zoho_synchronized", nullable = false)
    private boolean isZohoSynchronized = true;

    @Column(name = "zoho_id")
    private Long zohoId;

    @OneToOne
    @JoinColumn(name = "ws_user_data_id")
    private WSUserData wsUserData;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean isActive() {
        return UserState.ACTIVE.equals(state);
    }

    public UserState getState() {
        return state;
    }

    public void setState(UserState state) {
        this.state = state;
    }

    public String getActivationKey() {
        return activationKey;
    }

    public void setActivationKey(String activationKey) {
        this.activationKey = activationKey;
    }

    public String getResetKey() {
        return resetKey;
    }

    public void setResetKey(String resetKey) {
        this.resetKey = resetKey;
    }

    public DateTime getResetDate() {
        return resetDate;
    }

    public void setResetDate(DateTime resetDate) {
        this.resetDate = resetDate;
    }

    public String getLangKey() {
        return langKey;
    }

    public void setLangKey(String langKey) {
        this.langKey = langKey;
    }

    public Set<Authority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Set<Authority> authorities) {
        this.authorities = authorities;
    }

    public Set<PersistentToken> getPersistentTokens() {
        return persistentTokens;
    }

    public void setPersistentTokens(Set<PersistentToken> persistentTokens) {
        this.persistentTokens = persistentTokens;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public String getOneTimePassword() {
        return oneTimePassword;
    }

    public void setOneTimePassword(String oneTimePassword) {
        this.oneTimePassword = oneTimePassword;
    }

    public DateTime getLastLoginAttempt() {
        return lastLoginAttempt;
    }

    public void setLastLoginAttempt(DateTime lastLoginAttempt) {
        this.lastLoginAttempt = lastLoginAttempt;
    }

    public SubscriptionPackage getSubscriptionPackage() {
        return subscriptionPackage;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public Author getAuthor() {
        return author;
    }

    public WSUserData getWsUserData() {
        return wsUserData;
    }

    public void setWsUserData(WSUserData wsUserData) {
        this.wsUserData = wsUserData;
    }

    public void setSubscriptionPackage(SubscriptionPackage subscriptionPackage) {
        this.subscriptionPackage = subscriptionPackage;
    }

    public DateTime getSubscriptionExpirationDate() {
        return subscriptionExpirationDate;
    }

    public void setSubscriptionExpirationDate(DateTime subscriptionExpirationDate) {
        this.subscriptionExpirationDate = subscriptionExpirationDate;
    }

    public QuestionnairePage getCurrentQuestionnairePage() {
        return currentQuestionnairePage;
    }

    public void setCurrentQuestionnairePage(QuestionnairePage currentQuestionnairePage) {
        this.currentQuestionnairePage = currentQuestionnairePage;
    }

    public UserQuestionnaireState getQuestionnaireState() {
        return questionnaireState;
    }

    public void setQuestionnaireState(UserQuestionnaireState questionnaireState) {
        this.questionnaireState = questionnaireState;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Set<BasicFood> getDislikedFoods() {
        return dislikedFoods;
    }

    public void setDislikedFoods(Set<BasicFood> dislikedFoods) {
        this.dislikedFoods = dislikedFoods;
    }

    public Set<CookingMode> getMissingEquipment() {
        return missingEquipment;
    }

    public void setMissingEquipment(Set<CookingMode> missingEquipment) {
        this.missingEquipment = missingEquipment;
    }

    public String getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(String partnerCode) {
        this.partnerCode = partnerCode;
    }

    public boolean isGenerationInProgress() {
        return isGenerationInProgress;
    }

    public void setIsGenerationInProgress(boolean isGenerationInProgress) {
        this.isGenerationInProgress = isGenerationInProgress;
    }

    public Set<User> getSupervisedUsers() {
        return supervisedUsers;
    }

    public void setSupervisedUsers(Set<User> supervisedUsers) {
        this.supervisedUsers = supervisedUsers;
    }

    public UserProfessionalInformation getUserProfessionalInformation() {
        return userProfessionalInformation;
    }

    public void setUserProfessionalInformation(UserProfessionalInformation userProfessionalInformation) {
        this.userProfessionalInformation = userProfessionalInformation;
    }

    public boolean isZohoSynchronized() {
        return isZohoSynchronized;
    }

    public void setZohoSynchronized(boolean zohoSynchronized) {
        this.isZohoSynchronized = zohoSynchronized;
    }

    public Long getZohoId() {
        return zohoId;
    }

    public void setZohoId(Long zohoId) {
        this.zohoId = zohoId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        User user = (User) o;

        if (!email.equals(user.email)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }

    @Override
    public String toString() {
        return "User{" +
            "id=" + id +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", email='" + email + '\'' +
            ", state=" + state +
            '}';
    }
}
