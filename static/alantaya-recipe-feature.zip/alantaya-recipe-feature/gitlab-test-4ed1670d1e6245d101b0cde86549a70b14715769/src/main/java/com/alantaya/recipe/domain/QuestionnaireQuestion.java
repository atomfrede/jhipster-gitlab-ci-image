package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A QuestionnaireQuestion.
 */
@Entity
@Table(name = "QUESTIONNAIRE_QUESTION")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class QuestionnaireQuestion extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Size(max = 250)
    @Column(name = "question_text", length = 250, nullable = false)
    @JsonView(View.Minimal.class)
    private String questionText;

    @NotNull
    @Max(value = 100)
    @Column(name = "question_order", nullable = false)
    @JsonView(View.Minimal.class)
    private Integer questionOrder;

    @ManyToOne
    @JoinColumn(name="answerType")
    @JsonView(View.Minimal.class)
    private QuestionnaireAnswerType answerType;

    @ManyToOne
    @JsonView(View.Full.class)
    private QuestionnairePage page;

    @ManyToOne
    @JsonView(View.Minimal.class)
    private CriteriaGroup criteriaGroup;

    @OneToMany(mappedBy = "question")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.WithContainedEager.class)
    private Set<QuestionRelationship> relations = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public Integer getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(Integer questionOrder) {
        this.questionOrder = questionOrder;
    }

    public QuestionnaireAnswerType getAnswerType() {
        return answerType;
    }

    public void setAnswerType(QuestionnaireAnswerType questionnaireAnswerType) {
        this.answerType = questionnaireAnswerType;
    }

    public QuestionnairePage getPage() {
        return page;
    }

    public void setPage(QuestionnairePage questionnairePage) {
        this.page = questionnairePage;
    }

    public CriteriaGroup getCriteriaGroup() {
        return criteriaGroup;
    }

    public void setCriteriaGroup(CriteriaGroup criteriaGroup) {
        this.criteriaGroup = criteriaGroup;
    }

    public Set<QuestionRelationship> getRelations() {
        return relations;
    }

    public void setRelations(Set<QuestionRelationship> relations) {
        this.relations = relations;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        QuestionnaireQuestion questionnaireQuestion = (QuestionnaireQuestion) o;

        if ( ! Objects.equals(id, questionnaireQuestion.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "QuestionnaireQuestion{" +
                "id=" + id +
                ", questionText='" + questionText + "'" +
                ", questionOrder='" + questionOrder + "'" +
                '}';
    }
}
