/**
 * Created by max on 16/09/15.
 */
package com.alantaya.recipe.connected.device.withings.domain;
