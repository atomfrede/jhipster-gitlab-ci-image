package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.City;
import com.alantaya.recipe.domain.QCity;
import com.alantaya.recipe.repository.util.QueryDslUtil;
import com.alantaya.recipe.web.rest.dto.CitySearchQuery;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.types.Predicate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * Spring Data JPA repository for the City entity.
 */
public interface CityRepository extends JpaRepository<City,Long>, QueryDslPredicateExecutor<City> {

    default Iterable<City> findByNameLikeOrZipCodeLike(CitySearchQuery query) {
        BooleanBuilder where = new BooleanBuilder();

        if (null != query.getKeyword()) {
            String [] words = query.getKeyword().toLowerCase().split(" ");
            where.and(CityPredicates.nameContains(words));
            where.or(CityPredicates.zipCodeContains(words));
        }

        return findAll(
            where
        );
    }

    class CityPredicates {
        public static Predicate nameContains(final String ... searchedWords) {
            QCity city = QCity.city;
            return QueryDslUtil.likeAndLike(city.name.toLowerCase(), searchedWords);
        }

        public static Predicate zipCodeContains(final String ... searchedWords) {
            QCity city = QCity.city;
            return QueryDslUtil.likeAndLike(city.zipCode.stringValue().toLowerCase(), searchedWords);
        }
    }

}
