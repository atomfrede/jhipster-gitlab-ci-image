package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserSetting;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the UserSetting entity.
 */
public interface UserSettingRepository extends JpaRepository<UserSetting,Long> {

    @Query("select userSetting from UserSetting userSetting where userSetting.user.email = ?#{principal.username}")
    List<UserSetting> findAllForCurrentUser();

    List<UserSetting> findByUser(User user);
    UserSetting findBySettingKeyAndUser(String settingKey, User user);

}
