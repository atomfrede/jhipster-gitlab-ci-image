package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserQuestionnaireAnswerList;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for the UserQuestionnaireAnswers entity.
 */
public interface UserQuestionnaireAnswerListRepository extends JpaRepository<UserQuestionnaireAnswerList, Long> {

    public UserQuestionnaireAnswerList findByUserId(Long userId);

}
