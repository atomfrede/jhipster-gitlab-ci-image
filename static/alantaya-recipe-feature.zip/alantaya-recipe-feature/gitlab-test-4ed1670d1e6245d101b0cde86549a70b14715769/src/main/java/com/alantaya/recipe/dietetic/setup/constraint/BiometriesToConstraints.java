package com.alantaya.recipe.dietetic.setup.constraint;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticNutriment;
import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.CriteriaType;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.repository.NutrimentRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Service
public class BiometriesToConstraints {
    private static final Double ENERGY_RANGE = 0.1D;

    @Inject NutrimentRepository nutrimentRepository;

    public List<DieteticConstraint> setUp(List<DieteticConstraint> constraintsToCompute, List<UserBiometricValue> userBiometricValues) {
        if (userBiometricValues == null || userBiometricValues.isEmpty()) return constraintsToCompute;

        createEnergyConstraint(userBiometricValues).ifPresent(energyConstraint -> constraintsToCompute.add(energyConstraint));

        return constraintsToCompute;
    }


    private Optional<DieteticConstraint> createEnergyConstraint(List<UserBiometricValue> userBiometricValues) {
        final Optional<UserBiometricValue> energyBiometryValue = userBiometricValues.stream()
            .filter(userBiometry -> Biometry.ENERGY_ID.equals(userBiometry.getBiometryId()))
            .findFirst();
        if (!energyBiometryValue.isPresent()) return Optional.empty();

        final Double energy = energyBiometryValue.get().getValue();
        final Double maxEnergy = energy + (energy * ENERGY_RANGE);
        final Double minEnergy = energy - (energy * ENERGY_RANGE);

        final DieteticNutriment energyNutriment = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.CALORIE_ID));
        final DieteticConstraint energyConstraint = new DieteticConstraint(
            null,
            energyNutriment,
            CriteriaType.UTILISATEUR_ID,
            minEnergy,
            maxEnergy,
            null);
        return Optional.of(energyConstraint);
    }
}
