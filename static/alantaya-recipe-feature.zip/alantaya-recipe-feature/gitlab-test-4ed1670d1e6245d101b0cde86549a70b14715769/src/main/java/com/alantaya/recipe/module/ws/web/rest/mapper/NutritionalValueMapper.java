package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.module.ws.web.rest.dto.NutritionalValueDTO;
import com.alantaya.recipe.service.dto.BasicNutritionalValues;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring", uses = {})
public interface NutritionalValueMapper {

    @Mappings({
        @Mapping(source = "kCalories", target = "calories"),
        @Mapping(source = "lipidPercentage", target = "lipid"),
        @Mapping(source = "proteinPercentage", target = "protein"),
        @Mapping(source = "glucidPercentage", target = "glucid")
    })
    NutritionalValueDTO basicNutritionalValueToNutritionalValueDTO(BasicNutritionalValues basicNutritionalValues);

}
