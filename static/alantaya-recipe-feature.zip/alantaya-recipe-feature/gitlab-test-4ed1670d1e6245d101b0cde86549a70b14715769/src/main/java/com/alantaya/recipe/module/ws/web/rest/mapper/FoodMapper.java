package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.FoodQuantityByRecipe;
import com.alantaya.recipe.module.ws.web.rest.dto.FoodDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {RecipeStepMapper.class})
public interface FoodMapper {

    @Mapping(source = "amountInGrams", target = "quantity")
    @Mapping(source = "food.name", target = "name")
    @Mapping(source = "food.foodSection.name", target = "section")
    FoodDTO foodToFoodDTO(FoodQuantityByRecipe food);
    List<FoodDTO> foodsToFoodDTOs(Collection<FoodQuantityByRecipe> foods);

}
