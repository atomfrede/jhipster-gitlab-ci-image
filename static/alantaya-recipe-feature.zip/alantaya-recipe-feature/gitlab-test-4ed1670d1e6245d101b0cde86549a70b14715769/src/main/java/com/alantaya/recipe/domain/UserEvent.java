package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.enumeration.UserEventType;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.*;
import org.jasypt.hibernate4.type.EncryptedStringType;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserEvent.
 */
@Entity
@Table(name = "USER_EVENT")
@TypeDefs({
        @TypeDef(
                name="encryptedString",
                typeClass=EncryptedStringType.class,
                parameters= {
                        @org.hibernate.annotations.Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
                })}
)
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class UserEvent extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private UserEventType type;

    @Column(name = "content", nullable = false, columnDefinition = "clob")
    @Type(type = "encryptedString")
    private String content;

    @ManyToOne
    private User user;

    @ManyToOne
    private User supervisor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserEventType getType() {
        return type;
    }

    public void setType(UserEventType type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(User supervisor) {
        this.supervisor = supervisor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserEvent userEvent = (UserEvent) o;

        if ( ! Objects.equals(id, userEvent.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserEvent{" +
                "id=" + id +
                ", type='" + type + "'" +
                ", content='" + content + "'" +
                '}';
    }
}
