package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.WSUserData;
import com.alantaya.recipe.repository.WSUserDataRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

@Service
public class LicenceService {

    @Inject private WSUserDataRepository wsUserDataRepository;

    public boolean hasAvailableLicence(User user) {
        if (user.getWsUserData() == null)
            throw  new IllegalArgumentException("User should have a WsDataObject, userId: " + user.getId());

        long usedLicenceNumber = getUsedLicenceNumber(user).longValue();
        long totalLicenceNumber = user.getWsUserData().getNbLicence().longValue();
        return usedLicenceNumber < totalLicenceNumber;
    }

    public Integer getUsedLicenceNumber(User user) {
        Long count = user.getSupervisedUsers().stream()
                .filter(User::isActive)
                .count();
        return count.intValue();
    }

    public void updateLicence(User user, int nbLicence) {
        WSUserData wsUserData = user.getWsUserData();
        if (wsUserData == null) {
            wsUserData = new WSUserData();
            user.setWsUserData(wsUserData);
        }
        wsUserData.setNbLicence(nbLicence);
        wsUserDataRepository.save(wsUserData);
    }
}
