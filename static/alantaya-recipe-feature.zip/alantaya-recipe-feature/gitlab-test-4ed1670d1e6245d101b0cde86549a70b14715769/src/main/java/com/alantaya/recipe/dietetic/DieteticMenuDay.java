package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.domain.util.CustomLocalDateSerializer;
import com.alantaya.recipe.domain.util.ISO8601LocalDateDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.joda.time.LocalDate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class DieteticMenuDay implements DieteticStatistic, DieteticActualStatistic {

    private final List<DieteticMenu> menus;

    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
    private final LocalDate date;

    private final HashMap<DieteticElement, Double> quantityByDieteticElement;
    private final HashMap<DieteticElement, Double> actualQuantityByDieteticElement;

    public DieteticMenuDay(LocalDate date) {
        this.menus = new ArrayList<>();
        this.date = date;
        this.quantityByDieteticElement = new HashMap<>();
        this.actualQuantityByDieteticElement = new HashMap<>();
    }

    public DieteticMenuDay(List<UserMeal> meals, LocalDate date) {
        this.menus = meals.stream()
            .map(DieteticMenu::new)
            .collect(Collectors.toList());
        this.date = date;
        this.quantityByDieteticElement = new HashMap<>();
        this.actualQuantityByDieteticElement = new HashMap<>();
    }

    public List<DieteticMenu> getMenus() {
        return menus;
    }

    public LocalDate getDate() {
        return date;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        if (! quantityByDieteticElement.containsKey(dieteticElement)) {
            Double quantity = menus.stream()
                .mapToDouble(menu -> menu.getQuantityFor(dieteticElement))
                .sum();
            quantityByDieteticElement.put(dieteticElement, quantity);
        }
        return quantityByDieteticElement.get(dieteticElement);
    }

    @Override
    public Double getActualQuantityFor(DieteticElement dieteticElement) {
        if (! actualQuantityByDieteticElement.containsKey(dieteticElement)) {
            Double quantity = menus.stream()
                .mapToDouble(menu -> menu.getActualQuantityFor(dieteticElement))
                .sum();
            actualQuantityByDieteticElement.put(dieteticElement, quantity);
        }
        return actualQuantityByDieteticElement.get(dieteticElement);
    }
}
