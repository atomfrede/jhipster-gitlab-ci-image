package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.enumeration.UserState;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for the User entity.
 */
public interface UserRepository extends JpaRepository<User, Long>, QueryDslPredicateExecutor<User> {

    Optional<User> findOneByActivationKey(String activationKey);

    List<User> findAllByStateAndCreatedDateBefore(UserState state, DateTime dateTime);

    Optional<User> findOneByResetKey(String resetKey);

    Optional<User> findOneByEmail(String email);

    @Query("select user " +
        "from User user " +
        "left join fetch user.authorities " +
        "left join fetch user.dislikedFoods " +
        "left join fetch user.missingEquipment " +
        "left join fetch user.supervisedUsers " +
        "where user.email =:email")
    Optional<User> findOneByEmailWithEagerRelationship(@Param("email") String email);

    @Query("select user " +
        "from User user " +
        "left join fetch user.authorities " +
        "left join fetch user.dislikedFoods " +
        "left join fetch user.missingEquipment " +
        "left join fetch user.supervisedUsers " +
        "where user.id =:id")
    Optional<User> findOneByIdWithEagerRelationship(@Param("id") Long id);

    List<User> findAllByState(UserState state);

    List<User> findAllByAuthorities(Authority authority);

    Page<User> findAllByAuthorities(Authority authority, Pageable pageable);

    List<User> findBySubscriptionExpirationDateBeforeAndAuthorities(DateTime dateTime, Authority authority);
    List<User> findBySubscriptionExpirationDateBetweenAndAuthorities(DateTime startDate, DateTime endDate, Authority authority);

    List<User> findByIsZohoSynchronizedFalseAndZohoIdIsNull();
    List<User> findByIsZohoSynchronizedFalseAndZohoIdIsNotNull();
    List<User> findByEmailIn(Collection<String> userEmails);

    @Override
    void delete(User t);
}
