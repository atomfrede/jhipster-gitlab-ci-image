package com.alantaya.recipe.service;


import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticRestaurantDish;
import com.alantaya.recipe.dietetic.service.DieteticValidityService;
import com.alantaya.recipe.domain.RestaurantDish;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.RestaurantDishRepository;
import com.alantaya.recipe.service.dto.ValidatedRestaurantDish;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RestaurantDishService {

    @Inject private RestaurantDishRepository restaurantDishRepository;

    @Inject private MealPlanningGenerationService mealPlanningGenerationService;
    @Inject private DieteticValidityService dieteticValidityService;

    public List<ValidatedRestaurantDish> getValidatedRestaurantDishes(Long restaurantId, User user) {
        List<RestaurantDish> restaurantDishes = restaurantDishRepository.findByRestaurantId(restaurantId);
        return restaurantDishesToValidatedRestaurantDishes(restaurantDishes, user);
    }

    private List<ValidatedRestaurantDish> restaurantDishesToValidatedRestaurantDishes(List<RestaurantDish> restaurantDishes,
                                                                                      User user) {
        return restaurantDishes.stream().map(restaurantDish ->
            new ValidatedRestaurantDish(
                restaurantDish,
                isRestaurantDishValidForUser(restaurantDish, user)
            ))
            .collect(Collectors.toList());
    }

    private boolean isRestaurantDishValidForUser(RestaurantDish restaurantDish, User user) {
        final DieteticRestaurantDish dieteticRestaurantDish = new DieteticRestaurantDish(restaurantDish);
        final List<DieteticConstraint> dieteticConstraints = getToEliminateConstraints(user);

        return dieteticValidityService.isValidDieteticRestaurantDish(
            dieteticRestaurantDish,
            dieteticConstraints);
    }

    private List<DieteticConstraint> getToEliminateConstraints(User user) {
        final List<DieteticConstraint> constraints = mealPlanningGenerationService.getComputedConstraints(user);

        return constraints.stream()
            .filter(constraint -> Double.valueOf(0).equals(constraint.getMaxQuantity()))
            .collect(Collectors.toList());
    }

}
