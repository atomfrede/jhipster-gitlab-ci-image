package com.alantaya.recipe.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.alantaya.recipe.repository.util.QueryDslUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.QCriteria;
import com.alantaya.recipe.repository.querydsl.JoinDescriptor;
import com.alantaya.recipe.repository.querydsl.JoinFetchCapableRepository;
import com.alantaya.recipe.web.rest.dto.CriteriaSearchDTO;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.types.Predicate;

/**
 * Spring Data JPA repository for the Criteria entity.
 */
public interface CriteriaRepository extends JoinFetchCapableRepository<Criteria,Long> {

    @Query("select criteria " +
           "from Criteria criteria " +
           "left join fetch criteria.groups " +
           "left join fetch criteria.constraints " +
           "left join fetch criteria.criteriaProfilings " +
           "where criteria.id =:id")
    Criteria findOneWithEagerRelationships(@Param("id") Long id);

    @Query("select distinct criteria " +
           "from Criteria criteria " +
           "left join fetch criteria.groups " +
           "left join fetch criteria.constraints " +
           "left join fetch criteria.criteriaProfilings " +
           "where criteria.id in :ids")
    List<Criteria> findByIdInWithEagerRelationships(@Param("ids") Collection<Long> ids);

    default List<Criteria> search(CriteriaSearchDTO params) {
        final ArrayList<Criteria> criteriasList = new ArrayList<Criteria>(1000);
        findAll(WhereBuilder.build(params)).forEach(criteria -> criteriasList.add(criteria));
        return criteriasList;
    }

    default Page<Criteria> search(CriteriaSearchDTO params, Pageable page) {
        return findAll(
                WhereBuilder.build(params),
                page,
                JoinDescriptor.leftJoin(QCriteria.criteria.criteriaProfilings)
        );
    }

    public class WhereBuilder {

        public static BooleanBuilder build(CriteriaSearchDTO params) {
            BooleanBuilder where = new BooleanBuilder();
            if (StringUtils.isNoneBlank(params.getNameKeywords())) {
                String[] keywords = params.getNameKeywords().toLowerCase().split(" ");
                where.and(WhereBuilder.nameContains(keywords));
            }

            if (StringUtils.isNoneBlank(params.getDescriptionKeywords())) {
                String[] keywords = params.getDescriptionKeywords().toLowerCase().split(" ");
                where.and(WhereBuilder.descriptionContains(keywords));
            }

            if (null != params.getStateId())
                where.and(WhereBuilder.stateIdEquals(params.getStateId()));

            if (null != params.getTypeId())
                where.and(WhereBuilder.typeEquals(params.getTypeId()));

            return where;
        }

        public static Predicate stateIdEquals(final Long stateId) {
            QCriteria criteria = QCriteria.criteria;
            if(null == stateId) return criteria.state.isNull();
            return criteria.state.id.eq(stateId);
        }

        public static Predicate nameContains(final String... searchedWords) {
            return QueryDslUtil.likeAndLike(QCriteria.criteria.name.toLowerCase(), searchedWords);
        }

        public static Predicate descriptionContains(final String... searchedWords) {
            return QueryDslUtil.likeAndLike(QCriteria.criteria.description.toLowerCase(), searchedWords);
        }

        public static Predicate typeEquals(final Long typeId) {
            QCriteria criteria = QCriteria.criteria;
            if(null == typeId) return criteria.type.isNull();
            return criteria.type.id.eq(typeId);
        }

        public static Predicate lastModifiedByEquals(final String userEmail) {
            QCriteria criteria = QCriteria.criteria;
            if(null == userEmail) return criteria.lastModifiedBy.isNull();
            return criteria.lastModifiedBy.eq(userEmail);
        }
    }
}
