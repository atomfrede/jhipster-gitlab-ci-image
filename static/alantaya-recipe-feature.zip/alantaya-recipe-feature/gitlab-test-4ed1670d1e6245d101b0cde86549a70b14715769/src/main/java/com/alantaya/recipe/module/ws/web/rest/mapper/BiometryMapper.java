package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.module.ws.web.rest.dto.BiometryDTO;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring", uses = {UnitMapper.class})
public interface BiometryMapper {

    BiometryDTO biometryToWSBiometryDTOV1(Biometry biometry);
    List<BiometryDTO> biometricsToWSBiometricsDTOV1(List<Biometry> biometrics);
}
