package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.NutrimentFamily;
import org.joda.time.DateTime;

import java.util.Objects;

public class DieteticNutrimentFamily extends NutrimentFamily implements DieteticElement, DieteticStatistic {
    private final NutrimentFamily nutrimentFamily;

    public DieteticNutrimentFamily(NutrimentFamily nutrimentFamily) {
        this.nutrimentFamily = nutrimentFamily;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        return this.equals(dieteticElement) ? 1D : 0D;
    }

    @Override
    public DieteticElement getMacro() {
        return null;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public Long getId() {
        return nutrimentFamily.getId();
    }

    @Override
    public void setId(Long id) {
        nutrimentFamily.setId(id);
    }

    @Override
    public String getName() {
        return nutrimentFamily.getName();
    }

    @Override
    public void setName(String name) {
        nutrimentFamily.setName(name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticNutrimentFamily dieteticNutrimentFamily = (DieteticNutrimentFamily) o;

        return nutrimentFamily.equals(dieteticNutrimentFamily.nutrimentFamily);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), nutrimentFamily.getId());
    }

    @Override
    public String getCreatedBy() {
        return nutrimentFamily.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        nutrimentFamily.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return nutrimentFamily.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        nutrimentFamily.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return nutrimentFamily.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        nutrimentFamily.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return nutrimentFamily.getLastModifiedDate();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        nutrimentFamily.setLastModifiedDate(lastModifiedDate);
    }

    @Override
    public String toString() {
        return "DieteticNutrimentFamily{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
