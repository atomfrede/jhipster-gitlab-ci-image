package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.UserMealRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.service.dto.PlanningGenerationResultDTO;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Service
public class PlanningGenerationReportService {

    private final Logger log = LoggerFactory.getLogger(PlanningGenerationReportService.class);

    @Inject private UserMealRepository userMealRepository;
    @Inject private UserRepository userRepository;

    public List<PlanningGenerationResultDTO> getPlanningGenerationResults() {

        List<User> users = userRepository.findAll();

        List<PlanningGenerationResultDTO> results = new ArrayList<>();

        users.forEach(user -> {
            List<UserMeal> userMeals = userMealRepository.findByUserIdAndDateGreaterThan(user.getId(), LocalDate.now());
            long dayCount = userMeals.stream()
                .map(UserMeal::getDate)
                .distinct()
                .count();
            results.add(
                new PlanningGenerationResultDTO(user.getEmail(), user.getQuestionnaireState(), dayCount)
            );
        });

        return results;
    }

}
