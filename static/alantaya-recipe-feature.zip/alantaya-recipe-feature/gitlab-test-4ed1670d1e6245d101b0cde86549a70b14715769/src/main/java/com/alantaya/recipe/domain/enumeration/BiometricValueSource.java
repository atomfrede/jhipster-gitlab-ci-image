package com.alantaya.recipe.domain.enumeration;

public enum BiometricValueSource {
    ALANTAYA,
    WITHINGS;
}
