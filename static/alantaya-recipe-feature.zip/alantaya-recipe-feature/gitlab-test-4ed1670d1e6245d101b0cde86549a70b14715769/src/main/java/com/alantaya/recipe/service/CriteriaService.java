package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaState;
import com.alantaya.recipe.domain.CriteriaType;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.web.rest.dto.CriteriaSearchDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;

@Service
public class CriteriaService {

    @Inject
    private CriteriaRepository criteriaRepository;

    @Transactional(readOnly = true)
    public List<Criteria> getValidatedCriteriaProfil() {
        CriteriaSearchDTO query = new CriteriaSearchDTO();
        query.setStateId(CriteriaState.VALIDATED_ID);
        query.setTypeId(CriteriaType.PROFILE_ID);

        return criteriaRepository.search(query);
    }

}
