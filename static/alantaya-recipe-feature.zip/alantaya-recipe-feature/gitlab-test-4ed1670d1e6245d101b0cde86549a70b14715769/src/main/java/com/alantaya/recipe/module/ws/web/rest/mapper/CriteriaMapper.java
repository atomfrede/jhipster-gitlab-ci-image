package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaGroup;
import com.alantaya.recipe.module.ws.web.rest.dto.CriteriaDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.Set;

@Mapper(componentModel = "spring", uses = {})
public abstract class CriteriaMapper {

    public abstract List<CriteriaDTO> criteriaListToCriteriaDTOList(List<Criteria> criteriaList);

    @Mapping(target = "type", source = "type.name")
    public abstract CriteriaDTO criteriaToCriteriaDTO(Criteria criteria);

    public abstract  List<String> criteriaGroupListToStringList(Set<CriteriaGroup> group);

    public String criteriaGroupToString(CriteriaGroup criteriaGroup){
        return criteriaGroup.getName();
    }
}
