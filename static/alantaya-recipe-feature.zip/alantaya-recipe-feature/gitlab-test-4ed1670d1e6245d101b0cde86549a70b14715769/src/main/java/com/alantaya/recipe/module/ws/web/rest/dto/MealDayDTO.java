package com.alantaya.recipe.module.ws.web.rest.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.joda.ser.LocalDateSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.joda.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

@ApiModel(value = "MealDay",
    description = "Defines one day of meal: noon and evening.\n" +
        "\n" +
        "IMPORTANT: <<NutritionalValue>> displays the values of one person of the day.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"date\": \"2015-11-18\",\n" +
        "    \"nutritionalValue\": {...},\n" +
        "    \"meals\": [...]\n" +
        "}\n" +
        "----"
)
public class MealDayDTO {

    @ApiModelProperty(position = 0, required = true)
    @JsonSerialize(using = LocalDateSerializer.class)
    public LocalDate date;

    @ApiModelProperty(value = "total nutritional value of the day for one person", position = 2, required = true)
    private NutritionalValueDTO nutritionalValue;

    @ApiModelProperty(position = 3, required = true)
    private List<UserMealDTO> meals = new ArrayList<>(2);

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public NutritionalValueDTO getNutritionalValue() {
        return nutritionalValue;
    }

    public void setNutritionalValue(NutritionalValueDTO nutritionalValue) {
        this.nutritionalValue = nutritionalValue;
    }

    public List<UserMealDTO> getMeals() {
        return meals;
    }

    public void setMeals(List<UserMealDTO> meals) {
        this.meals = meals;
    }

    @Override
    public String toString() {
        return "MealDayDTO {" +
            "date=" + date +
            ", nutritionalValue=" + nutritionalValue +
            ", meals=" + meals +
            '}';
    }
}
