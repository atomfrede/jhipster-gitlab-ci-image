package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.WeightingFactor;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the WeightingFactor entity.
 */
public interface WeightingFactorRepository extends JpaRepository<WeightingFactor,Long> {

}
