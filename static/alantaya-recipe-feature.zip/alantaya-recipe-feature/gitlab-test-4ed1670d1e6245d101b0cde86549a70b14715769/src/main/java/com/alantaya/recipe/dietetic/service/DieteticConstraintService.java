package com.alantaya.recipe.dietetic.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.mapper.DieteticConstraintMapper;
import com.alantaya.recipe.dietetic.setup.constraint.BiometriesToConstraints;
import com.alantaya.recipe.dietetic.setup.constraint.DislikedFoodsToConstraints;
import com.alantaya.recipe.dietetic.setup.constraint.WeightingFactorToMinMaxConstraints;
import com.alantaya.recipe.domain.BasicFood;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.repository.FoodRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Service
public class DieteticConstraintService {
    @Inject private WeightingFactorToMinMaxConstraints weightingFactorToMinMaxConstraints;
    @Inject private DieteticConstraintMapper dieteticConstraintMapper;
    @Inject private BiometriesToConstraints biometryToConstraint;
    @Inject private DislikedFoodsToConstraints dislikedFoodsToConstraints;

    @Inject private UserProfilService userProfilService;
    @Inject private FoodRepository foodRepository;

    private List<DieteticConstraint> getComputedConstraints(List<Criteria> criterias,
                                                           List<UserBiometricValue> userBiometricValues,
                                                           List<BasicFood> dislikedBasicFoods)
    {
        List<DieteticConstraint> constraintToCompute = dieteticConstraintMapper.criteriasToDieteticConstraints(criterias);

        List<Food> dislikedFoods = foodRepository.findByBasicFoodIn(dislikedBasicFoods);

        constraintToCompute = dislikedFoodsToConstraints.setUp(constraintToCompute, dislikedFoods);
        constraintToCompute = biometryToConstraint.setUp(constraintToCompute, userBiometricValues);

        // A executer en dernier
        constraintToCompute = weightingFactorToMinMaxConstraints.setUp(constraintToCompute);

        return constraintToCompute;
    }

    public List<DieteticConstraint> getDieteticConstraints(List<Criteria> criterias,
                                                           Map<Long, UserBiometricValue> biometricValuesByBiometricId,
                                                           Collection<BasicFood> dislikedFoods) {
        final List<UserBiometricValue> mostRecentUserBiometricValues = new ArrayList<>(biometricValuesByBiometricId.values());

        // Setup data
        final List<Criteria> allCriterias = new ArrayList<>(criterias);
        userProfilService.getCriteriaFromUserProfile(biometricValuesByBiometricId).ifPresent(allCriterias::add);
        return getComputedConstraints(allCriterias, mostRecentUserBiometricValues, new ArrayList<>(dislikedFoods));
    }
}
