package com.alantaya.recipe.module.ws.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserCriteriaList;
import com.alantaya.recipe.repository.UserCriteriaListRepository;
import com.alantaya.recipe.service.CriteriaListSerializer;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class WSUserCriteriaService {

    @Inject private UserCriteriaListRepository userCriteriaListRepository;
    @Inject private CriteriaListSerializer criteriaListSerializer;

    @Transactional
    public void addUserCriteria(Long criteriaId, User user) {
        List<Long> criteriaIds = new ArrayList<>();
        criteriaIds.addAll(getUserCriteriaIds(user));
        criteriaIds.add(criteriaId);
        saveUserCriteriaIds(criteriaIds, user);
    }

    @Transactional
    public void deleteUserCriteria(Long criteriaId, User user) {
        List<Long> criteriaIds = getUserCriteriaIds(user);
        criteriaIds.remove(criteriaId);
        saveUserCriteriaIds(criteriaIds, user);
    }

    @Transactional(readOnly = true)
    public List<Long> getUserCriteriaIds(User user) {
        UserCriteriaList userCriteriaList = userCriteriaListRepository.findByUserId(user.getId());
        if (userCriteriaList == null) return Collections.emptyList();
        return new ArrayList<>(criteriaListSerializer.deserialize(userCriteriaList.getCriteriaList()));
    }

    private void saveUserCriteriaIds(List<Long> criteriaIds, User user) {
        UserCriteriaList userCriteriaList = userCriteriaListRepository.findByUserId(user.getId());
        if (userCriteriaList == null) {
            userCriteriaList = new UserCriteriaList();
            userCriteriaList.setUser(user);
        }
        userCriteriaList.setCriteriaList(criteriaListSerializer.serialize(criteriaIds));
        userCriteriaListRepository.save(userCriteriaList);
    }
}
