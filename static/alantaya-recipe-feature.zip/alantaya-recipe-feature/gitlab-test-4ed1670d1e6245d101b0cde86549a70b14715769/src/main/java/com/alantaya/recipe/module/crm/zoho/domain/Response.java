package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
public class Response {

    @XmlElement(name = "result")
    private Result result;

    public Response() {}
    public Response(Result result) {
        this.result = result;
    }

    public Result getResult() {
        return result;
    }

    public Contacts getContacts() {
        return result.getContacts();
    }

    @XmlTransient
    public void setResult(Result result) {
        this.result = result;
    }
}
