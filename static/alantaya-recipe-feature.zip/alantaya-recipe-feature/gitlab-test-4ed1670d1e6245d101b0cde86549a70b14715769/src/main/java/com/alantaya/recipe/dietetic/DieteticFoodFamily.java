package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.FoodFamily;
import com.alantaya.recipe.domain.FoodFamilyGroup;
import org.joda.time.DateTime;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DieteticFoodFamily extends FoodFamily implements DieteticElement, DieteticStatistic {
    private final FoodFamily foodFamily;
    private final DieteticFoodFamilyGroup dieteticFoodFamilyGroup;

    public DieteticFoodFamily(FoodFamily foodFamily) {
        this.foodFamily = foodFamily;
        FoodFamilyGroup foodFamilyGroup = this.foodFamily.getFoodFamilyGroup();
        this.dieteticFoodFamilyGroup = null != foodFamilyGroup ? new DieteticFoodFamilyGroup(foodFamilyGroup) : null;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        double quantity = dieteticElement.equals(this) ? 1D : 0D;
        if (null != dieteticFoodFamilyGroup)
            quantity += dieteticFoodFamilyGroup.getQuantityFor(dieteticElement);
        return quantity;
    }

    @Override
    public DieteticElement getMacro() {
        return dieteticFoodFamilyGroup;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public Long getId() {
        return foodFamily.getId();
    }

    @Override
    public void setId(Long id) {
        foodFamily.setId(id);
    }

    @Override
    public String getName() {
        return foodFamily.getName();
    }

    @Override
    public void setName(String name) {
        foodFamily.setName(name);
    }

    @Override
    public FoodFamilyGroup getFoodFamilyGroup() {
        return foodFamily.getFoodFamilyGroup();
    }

    @Override
    public void setFoodFamilyGroup(FoodFamilyGroup foodFamilyGroup) {
        foodFamily.setFoodFamilyGroup(foodFamilyGroup);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFoodFamily dieteticFoodFamily = (DieteticFoodFamily) o;

        return foodFamily.equals(dieteticFoodFamily.foodFamily);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), foodFamily.getId());
    }

    @Override
    public String getCreatedBy() {
        return foodFamily.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        foodFamily.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return foodFamily.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        foodFamily.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return foodFamily.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        foodFamily.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return foodFamily.getLastModifiedDate();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        foodFamily.setLastModifiedDate(lastModifiedDate);
    }

    @Override
    public String toString() {
        return "DieteticFoodFamily{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
