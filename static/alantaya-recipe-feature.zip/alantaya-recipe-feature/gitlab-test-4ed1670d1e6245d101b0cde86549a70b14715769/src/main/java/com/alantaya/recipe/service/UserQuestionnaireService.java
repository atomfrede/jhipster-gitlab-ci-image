package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.*;
import com.alantaya.recipe.repository.QuestionnaireQuestionRepository;
import com.alantaya.recipe.repository.UserQuestionnaireAnswerListRepository;
import com.alantaya.recipe.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.*;

@Service
public class UserQuestionnaireService {

    @Inject private UserService userService;
    @Inject private UserQuestionnaireAnswersSerializer answersSerializer;
    @Inject private UserQuestionnaireAnswerListRepository answerListRepository;
    @Inject private UserRepository userRepository;
    @Inject private QuestionnaireQuestionRepository questionRepository;
    @Inject private UserEventService userEventService;

    @Transactional
    public void endFirstLoginQuestionnaire() {
        User user = userService.getUser();
        user.setQuestionnaireState(UserQuestionnaireState.DONE);
        userRepository.save(user);
    }

    @Transactional
    public void save(Collection<UserQuestionnaireAnswer> answers) {
        User user = userService.getUser();

        updateUserQuestionnaireData(answers);

        UserQuestionnaireAnswerList answerList = answerListRepository.findByUserId(user.getId());
        if (null == answerList) {
            answerList = new UserQuestionnaireAnswerList();
            answerList.setUser(user);
        }
        List<UserQuestionnaireAnswer> existingUserAnswers = answersSerializer.deserialize(answerList.getAnswers());
        Collection<UserQuestionnaireAnswer> newAnswerList = updateExistingAnswersWithNewOnes(existingUserAnswers, answers);

        answerList.setAnswers(answersSerializer.serialize(newAnswerList));
        answerListRepository.save(answerList);
        userEventService.createQuestionnaireEvent(answers, user);
    }


    private void updateUserQuestionnaireData(Collection<UserQuestionnaireAnswer> answers) {
        User user = userService.getUser();

        if (! UserQuestionnaireState.DONE.equals(user.getQuestionnaireState())) {
            user.setQuestionnaireState(UserQuestionnaireState.PAUSED);
            if (answers.size() > 0) {
                UserQuestionnaireAnswer answer = answers.iterator().next();
                QuestionnaireQuestion question = questionRepository.getOne(answer.getQuestionId());
                user.setCurrentQuestionnairePage(question.getPage());
                userRepository.save(user);
            }
        }
    }

    private Collection<UserQuestionnaireAnswer> updateExistingAnswersWithNewOnes(Iterable<UserQuestionnaireAnswer> existingUserAnswers, Iterable<UserQuestionnaireAnswer> answersToAdd) {
        Map<Long, UserQuestionnaireAnswer> answerByQuestionId = new HashMap<>();
        existingUserAnswers.forEach(answer -> answerByQuestionId.put(answer.getQuestionId(), answer));
        answersToAdd.forEach(newAnswer -> answerByQuestionId.put(newAnswer.getQuestionId(), newAnswer));
        return answerByQuestionId.values();
    }

    @Transactional(readOnly = true)
    public List<UserQuestionnaireAnswer> getUserAnswers() {
        User user = userService.getUser();
        return getAnswers(user.getId());
    }

    @Transactional(readOnly = true)
    public List<UserQuestionnaireAnswer> getAnswers(Long userId) {
        UserQuestionnaireAnswerList answerList = answerListRepository.findByUserId(userId);
        if (null == answerList) return Collections.emptyList();
        return answersSerializer.deserialize(answerList.getAnswers());
    }

}
