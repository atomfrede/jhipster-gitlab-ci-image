package com.alantaya.recipe.domain;

import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Unit.
 */
@Entity
@Table(name = "T_UNIT")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class Unit implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 20)
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    @NotNull
    @Size(max = 5)
    @Column(name = "short_name", length = 5, nullable = false)
    private String shortName;

    @NotNull
    @Min(value = 0)
    @Column(name = "ratio_to_base_unit", nullable = false)
    private Double ratioToBaseUnit;

    @ManyToOne
    private UnitType type;

    @Column(name = "baseunit_id", nullable = true)
    private Long baseUnitId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public Double getRatioToBaseUnit() {
        return ratioToBaseUnit;
    }

    public void setRatioToBaseUnit(Double ratioToBaseUnit) {
        this.ratioToBaseUnit = ratioToBaseUnit;
    }

    public UnitType getType() {
        return type;
    }

    public void setType(UnitType unitType) {
        this.type = unitType;
    }

    public Long getBaseUnitId() {
        return baseUnitId;
    }

    public void setBaseUnitId(Long unitId) {
        this.baseUnitId = unitId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Unit unit = (Unit) o;

        if ( ! Objects.equals(id, unit.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Unit{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", shortName='" + shortName + "'" +
                ", ratioToBaseUnit='" + ratioToBaseUnit + "'" +
                '}';
    }
}
