package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.domain.UserEvent;
import com.alantaya.recipe.domain.UserQuestionnaireAnswer;
import com.alantaya.recipe.domain.enumeration.UserEventType;
import com.alantaya.recipe.repository.UserEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collection;

@Service
public class UserEventService {

    private final Logger log = LoggerFactory.getLogger(UserEventService.class);

    @Inject private UserEventRepository userEventRepository;
    @Inject private BiometricValueListSerializer biometricValueListSerializer;
    @Inject private UserQuestionnaireAnswersSerializer answersSerializer;
    @Inject private SupervisionService supervisionService;

    @Transactional
    public void createQuestionnaireEvent(Collection<UserQuestionnaireAnswer> answers, User user) {
        UserEvent userEvent = new UserEvent();
        supervisionService.getCurrentSupervisor().ifPresent(userEvent::setSupervisor);
        userEvent.setUser(user);
        userEvent.setType(UserEventType.QUESTIONNAIRE_UPDATE);
        userEvent.setContent(answersSerializer.serialize(answers));
        userEventRepository.save(userEvent);
    }

    @Transactional
    public void createBiometricEvent(Collection<UserBiometricValue> userBiometricValues, User user) {
        UserEvent userEvent = new UserEvent();
        supervisionService.getCurrentSupervisor().ifPresent(userEvent::setSupervisor);
        userEvent.setUser(user);
        userEvent.setType(UserEventType.BIOMETRICS_UPDATE);
        userEvent.setContent(biometricValueListSerializer.serialize(userBiometricValues));
        userEventRepository.save(userEvent);
    }
}
