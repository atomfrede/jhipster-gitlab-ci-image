package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlValue;

@XmlRootElement(name = "FL")
public class Field {

    @XmlAttribute(name = "val")
    private String name;

    @XmlValue
    private String value;

    public Field() {}
    public Field(String name) {
        this.name = name;
    }

    public Field(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    @XmlTransient
    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    @XmlTransient
    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Field{" +
            "name='" + name + '\'' +
            ", value='" + value + '\'' +
            '}';
    }
}
