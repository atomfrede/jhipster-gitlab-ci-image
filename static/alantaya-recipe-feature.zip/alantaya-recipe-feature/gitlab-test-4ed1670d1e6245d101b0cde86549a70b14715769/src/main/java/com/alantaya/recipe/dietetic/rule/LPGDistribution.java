package com.alantaya.recipe.dietetic.rule;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.repository.NutrimentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class LPGDistribution implements DieteticRule {
    private final Logger log = LoggerFactory.getLogger(LPGDistribution.class);

    private static final double MAX_LIPIDE = 0.40;
    private static final double MAX_PROTEINE = 0.15;
    private static final double MAX_GLUCIDE = 0.55;
    private static final double APPROXIMATION = 0.05;

    @Inject
    private NutrimentRepository nutrimentRepository;

    @Override
    public boolean isValid(DieteticStatistic dieteticStatistic, List<DieteticConstraint> dieteticConstraints) {
        if (dieteticStatistic instanceof DieteticMenuDay) {
            final Double lipidQuantity = dieteticStatistic.getQuantityFor(getLipidNutriment());
            final Double glucideQuantity = dieteticStatistic.getQuantityFor(getGlucideNutriment());
            final Double proteinQuantity = dieteticStatistic.getQuantityFor(getProteinNutriment());

            final double total = lipidQuantity + glucideQuantity + proteinQuantity;
            if (lipidQuantity / total > MAX_LIPIDE + APPROXIMATION) {
                DieteticLogUtil.log(log, dieteticStatistic, null, "Above max lipid -> "+ lipidQuantity / total + " > "+ MAX_LIPIDE + APPROXIMATION);
                return false;
            }
            if (proteinQuantity / total > MAX_PROTEINE + APPROXIMATION) {
                DieteticLogUtil.log(log, dieteticStatistic, null, "Above max protein -> "+ proteinQuantity / total + " > "+ MAX_PROTEINE + APPROXIMATION);
                return false;
            }
            if (glucideQuantity / total > MAX_GLUCIDE + APPROXIMATION) {
                DieteticLogUtil.log(log, dieteticStatistic, null, "Above max glucide -> "+ glucideQuantity / total + " > "+ MAX_GLUCIDE + APPROXIMATION);
                return false;
            }
            return true;
        }
        return true;
    }

    private DieteticNutriment getLipidNutriment() {
        return new DieteticNutriment(nutrimentRepository.findOne(Nutriment.LIPIDE_ID));
    }

    private DieteticNutriment getProteinNutriment() {
        return new DieteticNutriment(nutrimentRepository.findOne(Nutriment.PROTEINE_ID));
    }

    private DieteticNutriment getGlucideNutriment() {
        return new DieteticNutriment(nutrimentRepository.findOne(Nutriment.GLUCIDE_ID));
    }
}
