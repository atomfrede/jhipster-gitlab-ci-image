package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.QuestionnairePage;
import com.alantaya.recipe.repository.QuestionnairePageRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

@Service
public class QuestionnaireService {

    @Inject
    private QuestionnairePageRepository questionnairePageRepository;

    public QuestionnairePage getNextPage(Long pageid) {
        final QuestionnairePage questionnairePage = questionnairePageRepository.findOne(pageid);
        final Integer pageOrder = Integer.valueOf(questionnairePage.getPageOrder().intValue() + 1);
        return questionnairePageRepository.findByPageOrder(pageOrder);
    }

    public QuestionnairePage getPreviousPage(Long pageid) {
        final QuestionnairePage questionnairePage = questionnairePageRepository.findOne(pageid);
        final Integer pageOrder = Integer.valueOf(questionnairePage.getPageOrder().intValue() - 1);
        return questionnairePageRepository.findByPageOrder(pageOrder);
    }

}
