package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.EatenDish;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.repository.EatenDishRepository;
import com.alantaya.recipe.repository.UserMealRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@Service
public class UserEatenDishService {
    private final Logger log = LoggerFactory.getLogger(UserEatenDishService.class);

    @Inject private UserService userService;
    @Inject private UserMealRepository userMealRepository;
    @Inject private EatenDishRepository eatenDishRepository;

    @Transactional(readOnly = true)
    public List<UserMeal> getMostRecent() {
        final User currentUser = userService.getUser();
        return userMealRepository.findByUserAndEatenDishesIsNotNullOrderByDateDesc(currentUser);
    }

    @Transactional
    public void delete(Long id) {
        final User currentUser = userService.getUser();
        if (id == null) {
            log.error("Missing parameter: CurrentUser -> {}, EatenDishId -> {}", currentUser, id);
            return;
        }
        final EatenDish eatenDishToDelete = eatenDishRepository.findOne(id);
        if (eatenDishToDelete == null) {
            log.warn("No eaten dish to delete: CurrentUser -> {}, id -> {}", currentUser, id);
            return;
        }
        if (!currentUser.equals(eatenDishToDelete.getUser())) {
            log.error("User not match: CurrentUser -> {}, EatenDishUser -> {}", currentUser, eatenDishToDelete.getUser());
            return;
        }

        deleteEatenDishFromUserMeals(eatenDishToDelete, currentUser);
        eatenDishRepository.delete(eatenDishToDelete);
    }

    private List<UserMeal> deleteEatenDishFromUserMeals(EatenDish eatenDishToDelete, User user) {
        final List<UserMeal> userMealsWithEatenDishToDelete = userMealRepository.findByUserAndEatenDishes(user, Arrays.asList(eatenDishToDelete));
        userMealsWithEatenDishToDelete.forEach(userMeal -> userMeal.getEatenDishes().remove(eatenDishToDelete));
        return userMealRepository.save(userMealsWithEatenDishToDelete);
    }

    @Transactional
    public void save(UserMeal userMealWithEatenDishes) {
        final User currentUser = userService.getUser();
        if (userMealWithEatenDishes == null) {
            log.error("Missing parameter: CurrentUser -> {}, userMealWithEatenDishes -> {}", currentUser, userMealWithEatenDishes);
            return;
        }
        final UserMeal userMealToUpdate = userMealRepository.findOne(userMealWithEatenDishes.getId());
        if (userMealToUpdate == null) {
            log.error("No existing UserMeal: CurrentUser -> {}, userMealWithEatenDishes -> {}", currentUser, userMealWithEatenDishes);
            return;
        }
        if (!currentUser.equals(userMealToUpdate.getUser())) {
            log.error("Current user not match with the UserMeal: CurrentUser -> {}, userMealWithEatenDishes -> {}", currentUser, userMealWithEatenDishes);
            return;
        }
        final Set<EatenDish> eatenDishesToSave = userMealWithEatenDishes.getEatenDishes();
        final List<EatenDish> eatenDishesSaved = saveEatenDishes(eatenDishesToSave, currentUser);
        saveUserMealWithEatenDishes(userMealToUpdate, eatenDishesSaved);
    }

    private List<EatenDish> saveEatenDishes(Set<EatenDish> eatenDishesToSave, User user) {
        eatenDishesToSave.forEach(eatenDish -> {
            eatenDish.setUser(user);
            eatenDish.getFoodQuantities().forEach(foodQuantity -> foodQuantity.setEatenDish(eatenDish));
        });
        return eatenDishRepository.save(eatenDishesToSave);
    }

    private UserMeal saveUserMealWithEatenDishes(UserMeal userMealToUpdate, List<EatenDish> eatenDishesSaved) {
        userMealToUpdate.getEatenDishes().clear();
        userMealToUpdate.getEatenDishes().addAll(eatenDishesSaved);
        return userMealRepository.save(userMealToUpdate);
    }
}
