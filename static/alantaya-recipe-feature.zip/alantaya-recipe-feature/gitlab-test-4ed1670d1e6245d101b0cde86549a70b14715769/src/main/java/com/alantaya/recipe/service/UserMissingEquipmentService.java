package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.CookingMode;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class UserMissingEquipmentService {

    @Inject private UserService userService;
    @Inject private UserRepository userRepository;

    @Transactional
    public void saveMissingEquipment(Set<CookingMode> cookingModes) {
        final User user = userService.getUser();
        user.setMissingEquipment(cookingModes);
        userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public List<CookingMode> getMissingEquipment() {
        return new ArrayList<>(userService.getUser().getMissingEquipment());
    }

}
