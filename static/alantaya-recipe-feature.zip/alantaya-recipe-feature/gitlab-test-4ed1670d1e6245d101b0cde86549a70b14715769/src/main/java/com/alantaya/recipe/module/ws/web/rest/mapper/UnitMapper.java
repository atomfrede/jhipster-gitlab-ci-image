package com.alantaya.recipe.module.ws.web.rest.mapper;


import com.alantaya.recipe.domain.Unit;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {})
public abstract class UnitMapper {

    public String unitToShortName(Unit unit) {
        if(unit == null) return null;
        return unit.getShortName();
    }
}
