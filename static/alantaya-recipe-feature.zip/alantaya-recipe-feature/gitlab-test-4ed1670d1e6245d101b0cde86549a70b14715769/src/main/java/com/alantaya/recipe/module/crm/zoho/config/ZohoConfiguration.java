package com.alantaya.recipe.module.crm.zoho.config;

import com.alantaya.recipe.module.crm.zoho.domain.Contacts;
import com.alantaya.recipe.module.crm.zoho.domain.Response;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

@Configuration
@EnableConfigurationProperties(ZohoProperties.class)
public class ZohoConfiguration {

    @Inject private ZohoProperties zohoProperties;

    @Bean(name = "contactsMarshaller")
    public Marshaller getContactsMarshaller() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Contacts.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
        return jaxbMarshaller;
    }

    @Bean(name = "responseUnmarshaller")
    public Unmarshaller getContactsUnmarshaller() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Response.class);
        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
        return jaxbUnmarshaller;
    }

    @Bean
    public ZohoURIBuilderFactory getZohoURIBuilderFactory() {
        return new ZohoURIBuilderFactory(
            zohoProperties.getUrl().getBase(),
            zohoProperties.getAuthtoken(),
            zohoProperties.getScope(),
            zohoProperties.getNewFormat(),
            zohoProperties.getMultipleUpdateVersion());
    }

}
