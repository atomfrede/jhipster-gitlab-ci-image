package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.BasicFood;
import org.springframework.data.jpa.repository.*;

/**
 * Spring Data JPA repository for the BasicFood entity.
 */
public interface BasicFoodRepository extends JpaRepository<BasicFood,Long> {

}
