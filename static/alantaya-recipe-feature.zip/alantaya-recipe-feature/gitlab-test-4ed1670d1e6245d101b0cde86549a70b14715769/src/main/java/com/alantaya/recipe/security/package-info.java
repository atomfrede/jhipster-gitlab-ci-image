/**
 * Spring Security configuration.
 */
package com.alantaya.recipe.security;
