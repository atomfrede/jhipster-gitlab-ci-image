package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserBiometricList;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.repository.BiometryRepository;
import com.alantaya.recipe.repository.UserBiometricListRepository;
import com.alantaya.recipe.service.util.DateTimeUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.time.Instant;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class BiometricService {
    public static final MostRecentDateComparator MOST_RECENT_DATE_COMPARATOR = new MostRecentDateComparator();

    private final Logger log = LoggerFactory.getLogger(BiometricService.class);

    @Inject private UserBiometricListRepository userBiometricListRepository;
    @Inject private BiometryRepository biometryRepository;
    @Inject private BiometricValueListSerializer biometricValueListSerializer;
    @Inject private DieteticUtilService dieteticUtilService;
    @Inject private UserEventService userEventService;

    public void addBiometricValue(UserBiometricValue userBiometricValue, User user) {
        addBiometricValues(Collections.singletonList(userBiometricValue), user);
    }

    public void addBiometricValues(Collection<UserBiometricValue> userBiometricValues, User user) {
        internalAddBiometricValues(userBiometricValues, user);
        final List<UserBiometricValue> computedUserBiometricValues = new ArrayList<>(2);
        computedUserBiometricValues.addAll(getBMIs(userBiometricValues, user));
        getEnergy(userBiometricValues, user).ifPresent(computedUserBiometricValues::add);
        internalAddBiometricValues(computedUserBiometricValues, user);
    }

    private void internalAddBiometricValues(Collection<UserBiometricValue> userBiometricValues, User user) {
        if (userBiometricValues.isEmpty()) return;
        if (null == user) {
            log.error("Add biometricValue on unknown user");
            return;
        }
        UserBiometricList userBiometricList = userBiometricListRepository.findByUserId(user.getId());

        List<UserBiometricValue> values;
        if (null == userBiometricList) {
            userBiometricList = new UserBiometricList();
            userBiometricList.setUser(user);
            values = new ArrayList<>();
        } else {
            values = biometricValueListSerializer.deserialize(userBiometricList.getBiometricValues());
        }

        for (UserBiometricValue value : userBiometricValues) {
            if (null == biometryRepository.findOne(value.getBiometryId())) {
                log.error("Add biometricValue with unknown biometryId : " + value.getBiometryId());
                return;
            }
            values.add(value);
        }

        userBiometricList.setBiometricValues(biometricValueListSerializer.serialize(values));
        userBiometricListRepository.save(userBiometricList);
        userEventService.createBiometricEvent(userBiometricValues, user);
    }



    public UserBiometricValue getBeforeLastUserBiometricValue(Long biometryId, User user) {
        final List<UserBiometricValue> allUserBiometricValues = getBiometricValues(user);
        return getInternalBeforeLastUserBiometricValue(biometryId, allUserBiometricValues);
    }

    public Map<Long, UserBiometricValue> getAllBeforeLastUserBiometricValue(User user) {
        final List<UserBiometricValue> allUserBiometricValues = getBiometricValues(user);
        final Collection<UserBiometricValue> mostRecentUserBiometricValues = getInternalBiometricValueByBiometricId(allUserBiometricValues).values();
        return mostRecentUserBiometricValues.stream()
            .map(UserBiometricValue::getBiometryId)
            .map(biometryId -> getInternalBeforeLastUserBiometricValue(biometryId, allUserBiometricValues))
            .filter(Objects::nonNull)
            .collect(Collectors.toMap(UserBiometricValue::getBiometryId, u -> u));
    }

    private UserBiometricValue getInternalBeforeLastUserBiometricValue(Long biometryId, List<UserBiometricValue> allUserBiometricValues) {
        final List<UserBiometricValue> valuesFilteredByBiometric = allUserBiometricValues.stream()
            .filter(userBiometricValue -> biometryId.equals(userBiometricValue.getBiometryId()))
            .sorted(BiometricService.MOST_RECENT_DATE_COMPARATOR)
            .collect(Collectors.toList());
        if (valuesFilteredByBiometric.size() < 2) return null;
        return valuesFilteredByBiometric.get(1);
    }

    public UserBiometricValue getBiometricValue(Long biometryId, User user) {
        if (Biometry.AGE_ID.equals(biometryId)) return getAge(user).orElse(null);

        UserBiometricList userBiometricList = userBiometricListRepository.findByUserId(user.getId());
        if (null == userBiometricList) return null;

        List<UserBiometricValue> values = biometricValueListSerializer.deserialize(userBiometricList.getBiometricValues());

        return getLastBiometricValue(biometryId, values);
    }

    private UserBiometricValue getLastBiometricValue(Long biometryId, List<UserBiometricValue> values) {
        return values.stream()
                     .sorted(MOST_RECENT_DATE_COMPARATOR)
                     .filter(value -> value.getBiometryId().equals(biometryId))
                     .findFirst().orElse(null);
    }

    public List<UserBiometricValue> getBiometricValues(User user) {
        UserBiometricList userBiometricList = userBiometricListRepository.findByUserId(user.getId());
        if (null == userBiometricList) return Collections.emptyList();

        List<UserBiometricValue> userBiometricListDeserialize = biometricValueListSerializer.deserialize(userBiometricList.getBiometricValues());
        getAge(user).ifPresent(userBiometricListDeserialize::add);
        return userBiometricListDeserialize;
    }

    public List<UserBiometricValue> getBiometricValuesBetween(User user, DateTime fromDate, DateTime toDate) {
        return getBiometricValues(user).stream()
            .filter(
                userBiometricValue -> {
                    DateTime date = userBiometricValue.getCreatedDate();
                    return DateTimeUtils.isBetween(date, fromDate, toDate);
                }
            ).collect(Collectors.toList());
    }

    public Map<Long, UserBiometricValue> getLatestBiometricValueByBiometricId(User user) {
        List<UserBiometricValue> values = getBiometricValues(user);
        return getInternalBiometricValueByBiometricId(values);
    }

    public List<UserBiometricValue> getBiometricValuesForBiometric(Long biometricId, User user, DateTime fromDate) {
        return getBiometricValues(user).stream()
            .filter(value -> value.getBiometryId().equals(biometricId))
            .filter(value -> value.getCreatedDate().isAfter(fromDate))
            .collect(Collectors.toList());
    }

    private Map<Long, UserBiometricValue> getInternalBiometricValueByBiometricId(List<UserBiometricValue> values) {
        if (values.isEmpty()) return Collections.emptyMap();

        return values.stream()
            .sorted(MOST_RECENT_DATE_COMPARATOR)
            .collect(Collectors.toMap(UserBiometricValue::getBiometryId, v -> v, (v1, v2) -> v1));
    }

    private Optional<UserBiometricValue> getEnergy(Collection<UserBiometricValue> userBiometricValues, User user) {
        final UserBiometricValue sex = getBiometricValue(Biometry.SEXE_ID, user);
        final UserBiometricValue age = getBiometricValue(Biometry.AGE_ID, user);
        final UserBiometricValue weight = getBiometricValue(Biometry.WEIGHT_ID, user);
        final UserBiometricValue size = getBiometricValue(Biometry.SIZE_ID, user);
        final UserBiometricValue sportActivity = getBiometricValue(Biometry.ACTIVITY_ID, user);
        if (sex == null || age == null || weight == null || size == null || sportActivity == null) return Optional.empty();

        final Double energyValue = dieteticUtilService.getDailyEnergyNeeds(sex.getValue(),
            age.getValue(),
            size.getValue(),
            weight.getValue(),
            sportActivity.getValue());
        final UserBiometricValue energy = new UserBiometricValue();
        energy.setBiometryId(Biometry.ENERGY_ID);
        energy.setCreatedDate(DateTime.now());
        energy.setValue(energyValue);

        return Optional.of(energy);
    }

    private List<UserBiometricValue> getBMIs(Collection<UserBiometricValue> userBiometricValues, User user) {
        List<UserBiometricValue> sizeList = getBiometricValuesFromList(Biometry.SIZE_ID, userBiometricValues);
        List<UserBiometricValue> weightList = getBiometricValuesFromList(Biometry.WEIGHT_ID, userBiometricValues);
        if (sizeList.isEmpty() && weightList.isEmpty()) return Collections.emptyList();

        List<UserBiometricValue> bmis = new ArrayList<>();
        sizeList.forEach(size -> getBMI(size, null, user).ifPresent(bmis::add));
        weightList.forEach(weight -> getBMI(null, weight, user).ifPresent(bmis::add));

        return bmis;
    }

    private Optional<UserBiometricValue> getBMI(UserBiometricValue size, UserBiometricValue weight, User user) {
        if (size == null && weight == null) return Optional.empty();
        if (size == null) size = getBiometricValue(Biometry.SIZE_ID, user);
        if (weight == null) weight = getBiometricValue(Biometry.WEIGHT_ID, user);
        if (weight == null || size == null) return Optional.empty();

        DateTime latestDate = DateTimeUtils.max(weight.getCreatedDate(), size.getCreatedDate());

        final Double bmiValue = dieteticUtilService.getBMI(weight.getValue(), size.getValue());
        final UserBiometricValue bmi = new UserBiometricValue();
        bmi.setBiometryId(Biometry.BMI_ID);
        bmi.setCreatedDate(latestDate);
        bmi.setValue(bmiValue);

        return Optional.of(bmi);
    }

    private List<UserBiometricValue> getBiometricValuesFromList(Long biometricId,
                                                                Collection<UserBiometricValue> userBiometricValues) {
        return userBiometricValues.stream()
            .filter(userBiometricValue -> biometricId.equals(userBiometricValue.getBiometryId()))
            .collect(Collectors.toList());
    }

    private Optional<UserBiometricValue> getAge(User user) {
        final UserBiometricValue birthDateBiometry = getBiometricValue(Biometry.BIRTHDATE_ID, user);
        if (birthDateBiometry == null) return Optional.empty();

        final java.time.LocalDate birthDate = Instant.ofEpochMilli(birthDateBiometry.getValue().longValue()).atZone(ZoneId.systemDefault()).toLocalDate();
        final Double ageValue = (double) java.time.LocalDate.now().getYear() - birthDate.getYear();
        final UserBiometricValue age = new UserBiometricValue();
        age.setBiometryId(Biometry.AGE_ID);
        age.setCreatedDate(DateTime.now());
        age.setValue(ageValue);

        return Optional.of(age);
    }

    private static class MostRecentDateComparator implements Comparator<UserBiometricValue> {

        @Override
        public int compare(UserBiometricValue v1, UserBiometricValue v2) {
            return v2.getCreatedDate().compareTo(v1.getCreatedDate());
        }

    }
}
