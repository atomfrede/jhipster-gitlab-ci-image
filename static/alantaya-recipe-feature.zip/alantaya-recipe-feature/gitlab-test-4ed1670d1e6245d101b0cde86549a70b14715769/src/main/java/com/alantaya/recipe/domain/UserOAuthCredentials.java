package com.alantaya.recipe.domain;

import com.alantaya.recipe.config.oauth.OAuthRequestToken;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserOAuthCredentials.
 */
@Entity
@Table(name = "USER_OAUTH_CREDENTIALS")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class UserOAuthCredentials implements OAuthRequestToken, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "provider_user_id", nullable = false)
    private Long providerUserId;

    @NotNull
    @Size(max = 256)
    @Column(name = "access_token", length = 256, nullable = false)
    private String accessToken;

    @NotNull
    @Size(max = 256)
    @Column(name = "access_secret", length = 256, nullable = false)
    private String accessSecret;

    @ManyToOne
    private User user;

    public UserOAuthCredentials() {
    }

    public UserOAuthCredentials(Long providerUserId, String accessToken, String accessSecret, User user) {
        this.providerUserId = providerUserId;
        this.accessToken = accessToken;
        this.accessSecret = accessSecret;
        this.user = user;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProviderUserId() {
        return providerUserId;
    }

    public void setProviderUserId(Long providerUserId) {
        this.providerUserId = providerUserId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getAccessSecret() {
        return accessSecret;
    }

    public void setAccessSecret(String accessSecret) {
        this.accessSecret = accessSecret;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String getToken() {
        return accessToken;
    }

    @Override
    public String getSecret() {
        return getAccessSecret();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserOAuthCredentials userOAuthCredentials = (UserOAuthCredentials) o;

        if ( ! Objects.equals(id, userOAuthCredentials.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserOAuthCredentials{" +
                "id=" + id +
                ", providerUserId='" + providerUserId + "'" +
                ", accessToken='" + accessToken + "'" +
                ", accessSecret='" + accessSecret + "'" +
                '}';
    }
}
