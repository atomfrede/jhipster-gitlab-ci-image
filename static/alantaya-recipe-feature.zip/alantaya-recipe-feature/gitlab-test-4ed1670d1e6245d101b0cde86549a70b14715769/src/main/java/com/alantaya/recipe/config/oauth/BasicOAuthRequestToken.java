package com.alantaya.recipe.config.oauth;


public final class BasicOAuthRequestToken implements OAuthRequestToken {
    private String token, secret;

    public BasicOAuthRequestToken(String token, String secret) {
        this.token = token;
        this.secret = secret;
    }

    public String getToken() {
        return token;
    }

    public String getSecret() {
        return secret;
    }
}
