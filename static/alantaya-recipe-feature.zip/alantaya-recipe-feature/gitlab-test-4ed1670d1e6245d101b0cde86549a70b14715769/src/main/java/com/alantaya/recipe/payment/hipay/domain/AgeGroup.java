package com.alantaya.recipe.payment.hipay.domain;


public class AgeGroup {

    public static final String OVER_12 = "+12";
    public static final String OVER_16 = "+16";
    public static final String OVER_18 = "+18";
    public static final String ALL = "ALL";

}
