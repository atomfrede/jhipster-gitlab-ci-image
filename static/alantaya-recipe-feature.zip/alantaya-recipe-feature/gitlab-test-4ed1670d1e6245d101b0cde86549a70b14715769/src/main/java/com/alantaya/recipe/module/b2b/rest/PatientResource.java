package com.alantaya.recipe.module.b2b.rest;

import com.alantaya.recipe.module.b2b.rest.dto.PatientDTO;
import com.alantaya.recipe.module.b2b.service.PatientService;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.UserService;
import com.codahale.metrics.annotation.Timed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.Valid;
import java.util.Optional;

/**
 * REST controller for managing patient.
 */
@RestController
@RequestMapping("/api")
public class PatientResource {

    private final Logger log = LoggerFactory.getLogger(PatientResource.class);

    @Inject private PatientService patientService;
    @Inject private UserService userService;
    @Inject private UserRepository userRepository;

    /**
     * POST  /patients -> Create a new patient.
     */
    @RequestMapping(value = "/patients",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.PRO)
    @Transactional
    public ResponseEntity<?> create(@Valid @RequestBody PatientDTO patientDTO) {
        log.debug("REST request to save patient : {}", patientDTO);
        return userRepository.findOneByEmail(patientDTO.getEmail())
            .map(patient -> new ResponseEntity<>("e-mail address already in use", HttpStatus.BAD_REQUEST))
            .orElseGet(() -> {
                patientService.createPatient(userService.getUser(),
                    patientDTO.getEmail(),
                    patientDTO.getFirstName(),
                    patientDTO.getLastName(),
                    patientDTO.getPhoneNumber());
                return new ResponseEntity<>(HttpStatus.CREATED);
            });
    }

    /**
     * GET  /patients/:id -> get patient
     */
    @RequestMapping(value = "/patients/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.PRO)
    @Transactional(readOnly = true)
    public ResponseEntity<PatientDTO> getPatient(@PathVariable Long id) {
        log.debug("REST request to get patient : {}", id);
        return Optional.ofNullable(userRepository.findOne(id))
            .map(user -> new PatientDTO(user))
            .map(patientDTO -> new ResponseEntity<>(patientDTO, HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
}


