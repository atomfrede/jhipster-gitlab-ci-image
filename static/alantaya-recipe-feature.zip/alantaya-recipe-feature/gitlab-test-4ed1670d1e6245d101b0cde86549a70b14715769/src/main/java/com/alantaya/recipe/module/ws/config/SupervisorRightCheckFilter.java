package com.alantaya.recipe.module.ws.config;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.UserDetailsDTO;
import com.alantaya.recipe.service.SupervisionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

public class SupervisorRightCheckFilter extends GenericFilterBean {

    private static final Logger logger = LoggerFactory.getLogger(SupervisorRightCheckFilter.class);

    private UserRepository userRepository;
    private SupervisionService supervisionService;

    public SupervisorRightCheckFilter(UserRepository userRepository, SupervisionService supervisionService) {
        this.userRepository = userRepository;
        this.supervisionService = supervisionService;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        Long supervisedUserId = getSupervisedUserId(httpRequest);
        if (supervisedUserId == null) {
            chain.doFilter(request, response);
            return;
        }

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (! (principal instanceof UserDetailsDTO)) {
            logger.error("Error casting principal");
            httpResponse.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            return;
        }

        UserDetailsDTO userDetailsDTO = (UserDetailsDTO) principal;
        User wsSupervisor = userRepository.findOneByEmailWithEagerRelationship(userDetailsDTO.getUsername()).get();

        Optional<User> userSupervised = userRepository.findOneByIdWithEagerRelationship(supervisedUserId);
        if (! userSupervised.isPresent()) {
            logger.error("WSUser {} try to update user with id {} but this user does not exists",
                userDetailsDTO.getUsername());
            httpResponse.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        if (! userSupervised.get().isActive()) {
            logger.error("WSUser {} try to update user with id {} but this user state is {}",
                userDetailsDTO.getUsername(), userSupervised.get().getState());
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        boolean isSupervised = supervisionService.isSupervisedBy(userSupervised.get(), wsSupervisor);
        if (! isSupervised) {
            logger.error("WSUser {} try to update user with id {} but has no rights on it",
                userDetailsDTO.getUsername(), supervisedUserId);
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        chain.doFilter(request, response);
    }

    private Long getSupervisedUserId(HttpServletRequest request) {
        String [] queryParams = request.getRequestURI().split("/");
        for (int index = 0; index < queryParams.length; index++) {
            int nextIndex = index + 1;
            if("users".equals(queryParams[index]) && queryParams.length > nextIndex) {
                String strUserId = queryParams[nextIndex];
                return Long.valueOf(strUserId);
            }
        }
        return null;
    }
}
