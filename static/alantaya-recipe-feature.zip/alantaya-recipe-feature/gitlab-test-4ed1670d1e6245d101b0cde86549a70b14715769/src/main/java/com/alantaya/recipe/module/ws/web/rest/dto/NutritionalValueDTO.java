package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "NutritionalValue",
    description = "Use in <<Recipe>> and <<MealDay>>.\n" +
        "\n" +
        "IMPORTANT: The value display is for one person.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"calories\": 1522,\n" +
        "    \"lipid\": 28,\n" +
        "    \"protein\": 13,\n" +
        "    \"glucid\": 57\n" +
        "}\n" +
        "----"
)
public class NutritionalValueDTO {
    @ApiModelProperty(value = "defined in kcal", position = 0, required = true)
    private Integer calories;

    @ApiModelProperty(value = "defined in percentage", position = 1, required = true)
    private Integer lipid;

    @ApiModelProperty(value = "defined in percentage", position = 2, required = true)
    private Integer protein;

    @ApiModelProperty(value = "defined in percentage", position = 3, required = true)
    private Integer glucid;

    public Integer getCalories() {
        return calories;
    }

    public void setCalories(Integer calories) {
        this.calories = calories;
    }

    public Integer getLipid() {
        return lipid;
    }

    public void setLipid(Integer lipid) {
        this.lipid = lipid;
    }

    public Integer getProtein() {
        return protein;
    }

    public void setProtein(Integer protein) {
        this.protein = protein;
    }

    public Integer getGlucid() {
        return glucid;
    }

    public void setGlucid(Integer glucid) {
        this.glucid = glucid;
    }

    @Override
    public String toString() {
        return "NutritionalValueDTO{" +
            "calories='" + calories + '\'' +
            ", lipid='" + lipid + '\'' +
            ", protein='" + protein + '\'' +
            ", glucid='" + glucid + '\'' +
            '}';
    }
}
