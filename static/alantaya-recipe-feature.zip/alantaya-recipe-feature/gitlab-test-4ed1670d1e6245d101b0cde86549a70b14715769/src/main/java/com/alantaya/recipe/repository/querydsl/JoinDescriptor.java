package com.alantaya.recipe.repository.querydsl;

import com.mysema.query.JoinType;
import com.mysema.query.types.CollectionExpression;

public class JoinDescriptor {
    public final CollectionExpression<?, ?> path;
    public final JoinType type;

    private JoinDescriptor(CollectionExpression<?, ?> path, JoinType type) {
        this.path = path;
        this.type = type;
    }

    public static <P> JoinDescriptor innerJoin(CollectionExpression<?, P> path) {
        return new JoinDescriptor(path, JoinType.INNERJOIN);
    }

    public static <P> JoinDescriptor join(CollectionExpression<?, P> path) {
        return new JoinDescriptor(path, JoinType.JOIN);
    }

    public static <P> JoinDescriptor leftJoin(CollectionExpression<?, P> path) {
        return new JoinDescriptor(path, JoinType.LEFTJOIN);
    }

    public static <P> JoinDescriptor rightJoin(CollectionExpression<?, P> path) {
        return new JoinDescriptor(path, JoinType.RIGHTJOIN);
    }

    public static <P> JoinDescriptor fullJoin(CollectionExpression<?, P> path) {
        return new JoinDescriptor(path, JoinType.FULLJOIN);
    }
    
}