package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.FoodQuantityByRecipe;
import com.alantaya.recipe.domain.Recipe;

import java.util.*;

public class DieteticFoodQuantityByRecipe extends FoodQuantityByRecipe implements DieteticStatistic {

    private final FoodQuantityByRecipe foodQuantityByRecipe;
    private final DieteticFood dieteticFood;

    public DieteticFoodQuantityByRecipe(FoodQuantityByRecipe foodQuantityByRecipe) {
        this.foodQuantityByRecipe = foodQuantityByRecipe;
        this.dieteticFood = new DieteticFood(foodQuantityByRecipe.getFood());
    }

    public DieteticFood getDieteticFood() {
        return dieteticFood;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        Double quantity = dieteticFood.getQuantityFor(dieteticElement) * getAmountInGrams();
        return quantity;
    }

    @Override
    public Long getId() {
        return foodQuantityByRecipe.getId();
    }

    @Override
    public void setId(Long id) {
        foodQuantityByRecipe.setId(id);
    }

    @Override
    public Integer getAmountInGrams() {
        return foodQuantityByRecipe.getAmountInGrams();
    }

    @Override
    public void setAmountInGrams(Integer amountInGrams) {
        foodQuantityByRecipe.setAmountInGrams(amountInGrams);
    }

    @Override
    public Food getFood() {
        return foodQuantityByRecipe.getFood();
    }

    @Override
    public void setFood(Food food) {
        foodQuantityByRecipe.setFood(food);
    }

    @Override
    public Recipe getRecipe() {
        return foodQuantityByRecipe.getRecipe();
    }

    @Override
    public void setRecipe(Recipe recipe) {
        foodQuantityByRecipe.setRecipe(recipe);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFoodQuantityByRecipe dieteticFoodQuantityByRecipe = (DieteticFoodQuantityByRecipe) o;

        return foodQuantityByRecipe.equals(dieteticFoodQuantityByRecipe.foodQuantityByRecipe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), foodQuantityByRecipe.getId());
    }

    @Override
    public String toString() {
        return "DieteticFoodQuantityByRecipe{" +
            "id=" + getId() +
            ", amountInGrams='" + getAmountInGrams() + "'" +
            '}';
    }
}
