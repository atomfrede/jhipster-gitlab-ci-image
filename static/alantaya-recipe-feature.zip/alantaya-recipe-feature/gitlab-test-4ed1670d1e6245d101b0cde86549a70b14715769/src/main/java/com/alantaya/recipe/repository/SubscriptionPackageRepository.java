package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.SubscriptionPackage;
import org.springframework.data.jpa.repository.*;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for the SubscriptionPackage entity.
 */
public interface SubscriptionPackageRepository extends JpaRepository<SubscriptionPackage,Long> {
    SubscriptionPackage findOneByPartnerCode(String partnerCode);
}
