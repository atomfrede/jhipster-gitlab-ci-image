package com.alantaya.recipe.dietetic.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticLogUtil;
import com.alantaya.recipe.dietetic.DieteticMenuPattern;
import com.alantaya.recipe.dietetic.DieteticRecipe;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.RecipeState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DieteticRecipeService {
    private final Logger log = LoggerFactory.getLogger(DieteticRecipeService.class);

    @Inject private DieteticValidityService dieteticValidityService;

    public List<DieteticRecipe> getComputedRecipe(List<Recipe> recipes, List<DieteticConstraint> constraints, DieteticMenuPattern menuPattern) {
        log.debug(DieteticLogUtil.ALGO, "Entrée compute sur les recettes -> "+recipes.size()+" recettes");
        recipes = recipes.stream()
            .filter(recipe -> recipe.getState().getId().equals(RecipeState.VALIDATE_ID))
            .collect(Collectors.toList());
        List<DieteticRecipe> computedDieteticRecipes = recipes.stream()
            .map(DieteticRecipe::new)
            .collect(Collectors.toList());

        computedDieteticRecipes = getRecipeFilteredByConstraint(computedDieteticRecipes, constraints);
        computedDieteticRecipes = getRecipeFilteredByMenuPattern(computedDieteticRecipes, menuPattern);

        log.debug(DieteticLogUtil.ALGO, "Sortie compute sur les recettes -> "+computedDieteticRecipes.size()+" recettes");
        return computedDieteticRecipes;
    }

    public List<DieteticRecipe> getRecipeFilteredByMenuPattern(List<DieteticRecipe> recipes, DieteticMenuPattern menuPattern) {
        if (menuPattern == null || menuPattern.getRecipeTypesId().isEmpty()) return Collections.emptyList();
        final Long[] recipeTypesId = menuPattern.getRecipeTypesId().toArray(new Long[menuPattern.getRecipeTypesId().size()]);
        return recipes.stream()
            .filter(recipe -> isRecipeIsSameTypeId(recipe, recipeTypesId))
            .collect(Collectors.toList());
    }

    public List<DieteticRecipe> getRecipeFilteredByRecipeTypesId(List<DieteticRecipe> recipes, Long... recipeTypesId) {
        return recipes.stream()
            .filter(recipe -> isRecipeIsSameTypeId(recipe, recipeTypesId))
            .collect(Collectors.toList());
    }

    public List<DieteticRecipe> getRecipeFilteredByConstraint(List<DieteticRecipe> recipes, List<DieteticConstraint> constraints) {
        return recipes.stream()
            .filter(recipe -> dieteticValidityService.isValid(recipe, constraints))
            .collect(Collectors.toList());
    }

    private boolean isRecipeIsSameTypeId(DieteticRecipe recipe, Long... recipeTypesId) {
        return recipe != null
            && Arrays.asList(recipeTypesId).stream()
            .anyMatch(typeId -> typeId.equals(recipe.getType().getId()));
    }
}
