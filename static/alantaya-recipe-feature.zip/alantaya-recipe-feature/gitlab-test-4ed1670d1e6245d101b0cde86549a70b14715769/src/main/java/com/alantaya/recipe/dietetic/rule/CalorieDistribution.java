package com.alantaya.recipe.dietetic.rule;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.MealType;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.repository.NutrimentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Service
public class CalorieDistribution implements DieteticRule {
    private final Logger log = LoggerFactory.getLogger(CalorieDistribution.class);

    private static final double AVERAGE_MIDI = 0.4;
    private static final double AVERAGE_SOIR = 0.35;

    @Inject
    private NutrimentRepository nutrimentRepository;

    @Override
    public boolean isValid(DieteticStatistic dieteticStatistic, List<DieteticConstraint> dieteticConstraints) {
        if (dieteticStatistic instanceof DieteticMenu) {
            final DieteticMenu menu = (DieteticMenu) dieteticStatistic;
            final Long mealTypeId = menu.getMealType().getId();
            if (mealTypeId == null) return true;

            final Optional<DieteticConstraint> userCalorieConstraint =  getCalorieConstraint(dieteticConstraints);
            if (! userCalorieConstraint.isPresent()) return true;

            final Double menuCalorie = menu.getQuantityFor(getCalorieNutriment());
            if (menuCalorie == null) {
                DieteticLogUtil.log(log, dieteticStatistic, userCalorieConstraint.get(), "No calory found in the menu");
                return false;
            }

            final Double userMinCalorie = userCalorieConstraint.get().getMinQuantity();
            final Double userMaxCalorie = userCalorieConstraint.get().getMaxQuantity();
            final double minCalorieForMeal;
            final double maxCalorieForMeal;
            if (MealType.MIDI_ID.equals(mealTypeId)) {
                minCalorieForMeal = userMinCalorie * AVERAGE_MIDI;
                maxCalorieForMeal = userMaxCalorie * AVERAGE_MIDI;
            }
            else if (MealType.SOIR_ID.equals(mealTypeId)) {
                minCalorieForMeal = userMinCalorie * AVERAGE_SOIR;
                maxCalorieForMeal = userMaxCalorie * AVERAGE_SOIR;
            }
            else {
                return true;
            }

            if (menuCalorie >= minCalorieForMeal && menuCalorie <= maxCalorieForMeal) {
                return true;
            }
            else {
                DieteticLogUtil.log(log, dieteticStatistic, userCalorieConstraint.get(), "Not respected ->  "+ menuCalorie + " [min: "+ minCalorieForMeal + ", max:"+maxCalorieForMeal +"]");
                return false;
            }
        }
        return true;
    }

    private DieteticNutriment getCalorieNutriment() {
        return new DieteticNutriment(nutrimentRepository.findOne(Nutriment.CALORIE_ID));
    }

    private Optional<DieteticConstraint> getCalorieConstraint(List<DieteticConstraint> dieteticConstraints) {
        return dieteticConstraints.stream()
            .filter(this::isCalorieConstraint)
            .findFirst();
    }

    private boolean isCalorieConstraint(DieteticConstraint dieteticConstraint){
        return (dieteticConstraint.getDieteticElement() instanceof DieteticNutriment)
            && Nutriment.CALORIE_ID.equals(dieteticConstraint.getDieteticElement().getId());
    }

}
