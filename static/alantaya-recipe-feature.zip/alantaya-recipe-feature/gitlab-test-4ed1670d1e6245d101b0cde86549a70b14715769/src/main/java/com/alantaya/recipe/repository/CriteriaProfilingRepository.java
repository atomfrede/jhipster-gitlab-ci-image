package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.CriteriaProfiling;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.User;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the CriteriaProfiling entity.
 */
public interface CriteriaProfilingRepository extends JpaRepository<CriteriaProfiling,Long> {
    
    List<CriteriaProfiling> findByCriteriaId(Long criteriaId);
}
