package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A CriteriaConstraint.
 */
@Entity
@Table(name = "T_CRITERIA_CONSTRAINT")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CriteriaConstraint implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "min_quantity")
    private Double minQuantity;

    @Column(name = "max_quantity")
    private Double maxQuantity;

    @Size(max = 255)
    @Column(name = "comment", length = 255, nullable = true)
    private String comment;

    @ManyToOne
    @JsonIgnore
    private Criteria criteria;

    @ManyToOne
    private Food food;

    @ManyToOne
    private FoodFamily foodFamily;

    @ManyToOne
    private FoodFamilyGroup foodFamilyGroup;

    @ManyToOne
    private Nutriment nutriment;

    @ManyToOne
    private NutrimentFamily nutrimentFamily;

    @ManyToOne
    private WeightingFactor weightingFactor;

    @ManyToOne
    private Unit minQuantityUnit;

    @ManyToOne
    private Unit maxQuantityUnit;

    @ManyToOne
    private FoodTag foodTag;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getMinQuantity() {
        return minQuantity;
    }

    public void setMinQuantity(Double minQuantity) {
        this.minQuantity = minQuantity;
    }

    public Double getMaxQuantity() {
        return maxQuantity;
    }

    public void setMaxQuantity(Double maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Criteria getCriteria() {
        return criteria;
    }

    public void setCriteria(Criteria criteria) {
        this.criteria = criteria;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public FoodFamily getFoodFamily() {
        return foodFamily;
    }

    public void setFoodFamily(FoodFamily foodFamily) {
        this.foodFamily = foodFamily;
    }

    public FoodFamilyGroup getFoodFamilyGroup() {
        return foodFamilyGroup;
    }

    public void setFoodFamilyGroup(FoodFamilyGroup foodFamilyGroup) {
        this.foodFamilyGroup = foodFamilyGroup;
    }

    public Nutriment getNutriment() {
        return nutriment;
    }

    public void setNutriment(Nutriment nutriment) {
        this.nutriment = nutriment;
    }

    public NutrimentFamily getNutrimentFamily() {
        return nutrimentFamily;
    }

    public void setNutrimentFamily(NutrimentFamily nutrimentFamily) {
        this.nutrimentFamily = nutrimentFamily;
    }

    public WeightingFactor getWeightingFactor() {
        return weightingFactor;
    }

    public void setWeightingFactor(WeightingFactor weightingFactor) {
        this.weightingFactor = weightingFactor;
    }

    public Unit getMinQuantityUnit() {
        return minQuantityUnit;
    }

    public void setMinQuantityUnit(Unit unit) {
        this.minQuantityUnit = unit;
    }

    public Unit getMaxQuantityUnit() {
        return maxQuantityUnit;
    }

    public void setMaxQuantityUnit(Unit unit) {
        this.maxQuantityUnit = unit;
    }

    public FoodTag getFoodTag() {
        return foodTag;
    }

    public void setFoodTag(FoodTag foodTag) {
        this.foodTag = foodTag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CriteriaConstraint criteriaConstraint = (CriteriaConstraint) o;

        if ( ! Objects.equals(id, criteriaConstraint.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, criteria, food, foodFamily, foodFamilyGroup, nutriment, nutrimentFamily, foodTag);

    }

    @Override
    public String toString() {
        return "CriteriaConstraint{" +
                "id=" + id +
                ", minQuantity='" + minQuantity + "'" +
                ", maxQuantity='" + maxQuantity + "'" +
                ", comment='" + comment + "'" +
                '}';
    }
}
