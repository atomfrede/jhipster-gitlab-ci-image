package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticMenuPattern;
import com.alantaya.recipe.dietetic.service.AlgorithmService;
import com.alantaya.recipe.dietetic.service.DieteticConstraintService;
import com.alantaya.recipe.domain.BasicFood;
import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.service.dto.MealPlanning;
import com.alantaya.recipe.web.rest.dto.DieteticConstraintDTO;
import com.alantaya.recipe.web.rest.dto.TestMealGenerationQuery;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.*;

@Service
public class TestMealPlanningGenerationService {

    private final Logger log = LoggerFactory.getLogger(TestMealPlanningGenerationService.class);

    @Inject private DieteticConstraintService dieteticConstraintService;
    @Inject private AlgorithmService algorithmService;
    @Inject private CriteriaRepository criteriaRepository;
    @Inject private DieteticUtilService dieteticUtilService;

    @Transactional(readOnly = true)
    public MealPlanning generateMenu(TestMealGenerationQuery query) {

        final DieteticMenuPattern menuPattern = MenuPatternFactory.DEFAULT_DIETETIC_MENU_PATTERN;
        final List<DieteticConstraint> computedConstraints = getDieteticConstraints(query);

        LocalDate startDate = LocalDate.now().minusDays(LocalDate.now().dayOfWeek().get() - 1);
        return algorithmService.generateMealPlanning(
            computedConstraints,
            menuPattern,
            startDate,
            startDate.plusDays(query.getPlanningLengthInDays()));
    }

    @Transactional(readOnly = true)
    public List<DieteticConstraint> getDieteticConstraints(TestMealGenerationQuery query) {
        final List<Criteria> criterias = criteriaRepository.findByIdInWithEagerRelationships(query.getCriteriaIds());
        final Set<BasicFood> dislikedFood = Collections.emptySet();

        final Map<Long, UserBiometricValue> userBiometricValueByBiometricId = getBiometricValueByBiomioetricId(query.getBiometrics());

        return dieteticConstraintService.getDieteticConstraints(
            criterias,
            userBiometricValueByBiometricId,
            dislikedFood
        );
    }

    private Map<Long, UserBiometricValue> getBiometricValueByBiomioetricId(List<Double> biometricValues) {
        final Map<Long, UserBiometricValue> userBiometricValueMap = new HashMap<>();
        for (int index = 0, max = biometricValues.size(); index < max; index ++) {
            Double value = biometricValues.get(index);
            if (null != value) {
                Long biometryId = Long.valueOf(index);
                userBiometricValueMap.put(biometryId,
                    new UserBiometricValue(DateTime.now(), biometryId, value));
            }
        }

        final Double energyValue = dieteticUtilService.getDailyEnergyNeeds(
            userBiometricValueMap.get(Biometry.SEXE_ID).getValue(),
            userBiometricValueMap.get(Biometry.AGE_ID).getValue(),
            userBiometricValueMap.get(Biometry.SIZE_ID).getValue(),
            userBiometricValueMap.get(Biometry.WEIGHT_ID).getValue(),
            userBiometricValueMap.get(Biometry.ACTIVITY_ID).getValue()
        );
        userBiometricValueMap.put(Biometry.ENERGY_ID, new UserBiometricValue(DateTime.now(), Biometry.ENERGY_ID, energyValue));
        userBiometricValueMap.put(Biometry.BIRTHDATE_ID, new UserBiometricValue(
            DateTime.now().minusYears(userBiometricValueMap.get(Biometry.AGE_ID).getValue().intValue()),
            Biometry.BIRTHDATE_ID,
            energyValue));

        return userBiometricValueMap;
    }
}
