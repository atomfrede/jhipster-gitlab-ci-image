package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.SubscriptionPackageState;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the SubscriptionPackageState entity.
 */
public interface SubscriptionPackageStateRepository extends JpaRepository<SubscriptionPackageState,Long> {

}
