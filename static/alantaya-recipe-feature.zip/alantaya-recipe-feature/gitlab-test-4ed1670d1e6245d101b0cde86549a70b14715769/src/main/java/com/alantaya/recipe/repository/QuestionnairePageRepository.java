package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.QuestionnairePage;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the QuestionnairePage entity.
 */
public interface QuestionnairePageRepository extends JpaRepository<QuestionnairePage,Long> {

    public QuestionnairePage findByPageOrder(Integer pageOrder);

}
