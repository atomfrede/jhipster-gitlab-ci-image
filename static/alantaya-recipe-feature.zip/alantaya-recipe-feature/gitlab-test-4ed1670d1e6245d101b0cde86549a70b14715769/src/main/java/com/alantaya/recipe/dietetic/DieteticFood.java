package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.*;
import org.joda.time.DateTime;

import java.util.*;
import java.util.stream.Collectors;

public class DieteticFood extends Food implements DieteticElement, DieteticStatistic {

    private final Food food;
    private final DieteticFoodFamily dieteticFoodFamily;
    private final List<DieteticFoodTag> dieteticFoodTags;
    private final List<DieteticNutrimentPerFood> dieteticNutrimentPerFoods;

    public DieteticFood(Food food) {
        this.food = food;
        FoodFamily foodFamily = food.getFoodFamily();
        this.dieteticFoodFamily = null != foodFamily ? new DieteticFoodFamily(foodFamily) : null;
        this.dieteticFoodTags = food.getTags().stream()
            .map(DieteticFoodTag::new)
            .collect(Collectors.toList());
        this.dieteticNutrimentPerFoods = food.getNutrimentQuantitys().stream()
            .map(DieteticNutrimentPerFood::new)
            .collect(Collectors.toList());
    }

    public DieteticFoodFamily getDieteticFoodFamily() {
        return dieteticFoodFamily;
    }

    public List<DieteticFoodTag> getDieteticFoodTags() {
        return dieteticFoodTags;
    }

    public List<DieteticNutrimentPerFood> getDieteticNutrimentPerFoods() {
        return dieteticNutrimentPerFoods;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        double quantity = dieteticElement.equals(this) ? 1D : 0D;
        quantity += dieteticNutrimentPerFoods.stream()
            .mapToDouble(nutrimentQuantity -> nutrimentQuantity.getQuantityFor(dieteticElement))
            .sum();
        quantity += dieteticFoodTags.stream()
            .mapToDouble(tag -> tag.getQuantityFor(dieteticElement))
            .sum();
        if (null != dieteticFoodFamily)
            quantity += dieteticFoodFamily.getQuantityFor(dieteticElement);
        return quantity;
    }

    @Override
    public DieteticElement getMacro() {
        return dieteticFoodFamily;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        food.setLastModifiedDate(lastModifiedDate);
    }

    @Override
    public Long getId() {
        return food.getId();
    }

    @Override
    public void setId(Long id) {
        food.setId(id);
    }

    @Override
    public String getName() {
        return food.getName();
    }

    @Override
    public void setName(String name) {
        food.setName(name);
    }

    @Override
    public String getCompleteName() {
        return food.getCompleteName();
    }

    @Override
    public void setCompleteName(String completeName) {
        food.setCompleteName(completeName);
    }

    @Override
    public String getPieceName() {
        return food.getPieceName();
    }

    @Override
    public void setPieceName(String pieceName) {
        food.setPieceName(pieceName);
    }

    @Override
    public Double getAveragePieceWeight() {
        return food.getAveragePieceWeight();
    }

    @Override
    public void setAveragePieceWeight(Double averagePieceWeight) {
        food.setAveragePieceWeight(averagePieceWeight);
    }

    @Override
    public Double getDensity() {
        return food.getDensity();
    }

    @Override
    public void setDensity(Double density) {
        food.setDensity(density);
    }

    @Override
    public Boolean getIsRepetableInAMeal() {
        return food.getIsRepetableInAMeal();
    }

    @Override
    public void setIsRepetableInAMeal(Boolean isRepetableInAMeal) {
        food.setIsRepetableInAMeal(isRepetableInAMeal);
    }

    @Override
    public Boolean getIsHiddenInShoppingList() {
        return food.getIsHiddenInShoppingList();
    }

    @Override
    public void setIsHiddenInShoppingList(Boolean isHiddenInShoppingList) {
        food.setIsHiddenInShoppingList(isHiddenInShoppingList);
    }

    @Override
    public FoodFamily getFoodFamily() {
        return food.getFoodFamily();
    }

    @Override
    public void setFoodFamily(FoodFamily foodFamily) {
        food.setFoodFamily(foodFamily);
    }

    @Override
    public FoodSection getFoodSection() {
        return food.getFoodSection();
    }

    @Override
    public void setFoodSection(FoodSection foodSection) {
        food.setFoodSection(foodSection);
    }

    @Override
    public FoodState getFoodState() {
        return food.getFoodState();
    }

    @Override
    public void setFoodState(FoodState foodState) {
        food.setFoodState(foodState);
    }

    @Override
    public Unit getFavoriteUnit() {
        return food.getFavoriteUnit();
    }

    @Override
    public void setFavoriteUnit(Unit Unit) {
        food.setFavoriteUnit(Unit);
    }

    @Override
    public Set<NutrimentPerFood> getNutrimentQuantitys() {
        return food.getNutrimentQuantitys();
    }

    @Override
    public void setNutrimentQuantitys(Set<NutrimentPerFood> NutrimentPerFoods) {
        food.setNutrimentQuantitys(NutrimentPerFoods);
    }

    @Override
    public BasicFood getBasicFood() {
        return food.getBasicFood();
    }

    @Override
    public void setBasicFood(BasicFood basicFood) {
        food.setBasicFood(basicFood);
    }

    @Override
    public Set<FoodTag> getTags() {
        return food.getTags();
    }

    @Override
    public void setTags(Set<FoodTag> tags) {
        food.setTags(tags);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFood dieteticFood = (DieteticFood) o;

        return food.equals(dieteticFood.food);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), food.getId());
    }

    @Override
    public String getCreatedBy() {
        return food.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        food.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return food.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        food.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return food.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        food.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return food.getLastModifiedDate();
    }

    @Override
    public String toString() {
        return "DieteticFood{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
