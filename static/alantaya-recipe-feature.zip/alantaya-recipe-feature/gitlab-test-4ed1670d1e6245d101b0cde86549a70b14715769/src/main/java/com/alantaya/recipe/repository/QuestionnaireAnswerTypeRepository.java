package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.QuestionnaireAnswerType;
import org.springframework.data.jpa.repository.*;

/**
 * Spring Data JPA repository for the QuestionnaireAnswerType entity.
 */
public interface QuestionnaireAnswerTypeRepository extends JpaRepository<QuestionnaireAnswerType,Long> {

}
