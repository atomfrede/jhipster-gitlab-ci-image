package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Criteria;
import org.jboss.logging.MDC;
import org.slf4j.Logger;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

public class DieteticLogUtil {
    public static final Marker ALGO = MarkerFactory.getMarker("ALGO");

    public static void log(Logger log, DieteticStatistic dieteticStatistic, DieteticConstraint dieteticConstraint, String message) {
        MDC.put("Rule", log.getName().replace("com.alantaya.recipe.dietetic.rule.", ""));
        MDC.put("DSType", dieteticStatistic.getClass().getSimpleName());
        if (dieteticStatistic instanceof DieteticFoodQuantityByRecipe) {
            final DieteticFoodQuantityByRecipe dieteticFoodQuantityByRecipe = (DieteticFoodQuantityByRecipe) dieteticStatistic;
            MDC.put("DSName", "["+ dieteticFoodQuantityByRecipe.getFood().getId() +"] "+ dieteticFoodQuantityByRecipe.getFood().getName());
        }
        else if (dieteticStatistic instanceof DieteticRecipe) {
            final DieteticRecipe dieteticRecipe = (DieteticRecipe) dieteticStatistic;
            MDC.put("DSName",  "["+ dieteticRecipe.getId() +"] "+dieteticRecipe.getTitle());
        }
        else {
            MDC.put("DSName",  "");
        }
        if (dieteticConstraint != null) {
            final DieteticElement dieteticElement = dieteticConstraint.getDieteticElement();
            MDC.put("DCType", dieteticElement.getClass().getSimpleName());
            MDC.put("DCName",  "["+ dieteticElement.getId() +"] "+ dieteticElement.getLogName());
            final Criteria criteria = dieteticConstraint.getCriteria();
            MDC.put("DCDef",  "criteria -> ["+ (criteria == null ? "-1" : criteria.getId()) +" - "+ (criteria == null ? "null" : criteria.getType().getName())+"] "+ (criteria == null ? "Criteria Volatile" : criteria.getName())
                    + ", min -> " +dieteticConstraint.getMinQuantity()
                    + ", max -> " +dieteticConstraint.getMaxQuantity()
                    + ", ponderation -> " +dieteticConstraint.getWeightingFactorRatio());
        }
        else {
            MDC.put("DCType", "");
            MDC.put("DCName", "");
            MDC.put("DCDef", "");
        }
        MDC.put("Erreur", message);
        log.debug(DieteticLogUtil.ALGO, message);
    }
}
