package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Unit;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Unit entity.
 */
public interface UnitRepository extends JpaRepository<Unit,Long> {

}
