package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement(name="row")
public class RowXML {

    @XmlAttribute
    private int no = 0;

    @XmlElement(name = "FL")
    private List<Field> fields = new ArrayList<>();

    public List<Field> getFields() {
        return fields;
    }

    @XmlTransient
    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public int getNo() {
        return no;
    }

    @XmlTransient
    public void setNo(int no) {
        this.no = no;
    }

}
