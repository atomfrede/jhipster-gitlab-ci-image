/**
 * Spring Data JPA repositories.
 */
package com.alantaya.recipe.repository;
