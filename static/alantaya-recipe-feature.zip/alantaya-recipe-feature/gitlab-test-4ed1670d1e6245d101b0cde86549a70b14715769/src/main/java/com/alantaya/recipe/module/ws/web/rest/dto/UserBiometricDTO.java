package com.alantaya.recipe.module.ws.web.rest.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.joda.ser.DateTimeSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.joda.time.DateTime;

@ApiModel(value="UserBiometry",
    description =  "<<Biometry>> of the user: weight, size, BMI...\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"createdDate\": 1449705600000,\n" +
        "    \"biometryId\": 1,\n" +
        "    \"value\": 90\n" +
        "}\n" +
        "----"
)
public class UserBiometricDTO {

    @ApiModelProperty(value = "created date", position = 0, required = true)
    @JsonSerialize(using = DateTimeSerializer.class)
    private DateTime createdDate = DateTime.now();

    @ApiModelProperty(value = "biometry id", position = 1, required = true)
    private Long biometryId;

    @ApiModelProperty(position = 2, required = true)
    private Double value;

    public DateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public Long getBiometryId() {
        return biometryId;
    }

    public void setBiometryId(Long biometryId) {
        this.biometryId = biometryId;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "UserBiometryDTO{" +
            "createdDate=" + createdDate +
            ", biometryId=" + biometryId +
            ", value=" + value +
            '}';
    }
}
