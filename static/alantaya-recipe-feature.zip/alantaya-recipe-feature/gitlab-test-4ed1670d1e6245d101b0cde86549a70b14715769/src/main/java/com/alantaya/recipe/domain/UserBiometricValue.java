package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.enumeration.BiometricValueSource;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.joda.ser.DateTimeSerializer;
import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class UserBiometricValue {

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = DateTimeSerializer.class)
    private DateTime createdDate = DateTime.now();

    @NotNull
    private Long biometryId;

    @NotNull
    private Double value;

    private BiometricValueSource biometricValueSource = BiometricValueSource.ALANTAYA;

    public UserBiometricValue() {}
    public UserBiometricValue(DateTime createdDate, Long biometryId, Double value) {
        this(createdDate,biometryId, value, BiometricValueSource.ALANTAYA);
    }
    public UserBiometricValue(DateTime createdDate,
                              Long biometryId,
                              Double value,
                              BiometricValueSource biometricValueSource) {
        this.createdDate = createdDate;
        this.biometryId = biometryId;
        this.value = value;
        this.biometricValueSource = biometricValueSource;
    }

    public DateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public Long getBiometryId() {
        return biometryId;
    }

    public void setBiometryId(Long biometryId) {
        this.biometryId = biometryId;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public BiometricValueSource getBiometricValueSource() {
        return biometricValueSource;
    }

    public void setBiometricValueSource(BiometricValueSource biometricValueSource) {
        this.biometricValueSource = biometricValueSource;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserBiometricValue that = (UserBiometricValue) o;

        DateTime zonedCreatedDate = createdDate != null ? createdDate.withZone(DateTimeZone.UTC) : null;
        DateTime otherZonedCreatedDate = that.createdDate != null ? that.createdDate.withZone(DateTimeZone.UTC) : null;
        if (zonedCreatedDate != null ? !zonedCreatedDate.equals(otherZonedCreatedDate) : otherZonedCreatedDate != null) return false;
        if (biometryId != null ? !biometryId.equals(that.biometryId) : that.biometryId != null) return false;
        if (value != null ? !value.equals(that.value) : that.value != null) return false;
        return biometricValueSource == that.biometricValueSource;

    }

    @Override
    public int hashCode() {
        int result = createdDate != null ? createdDate.hashCode() : 0;
        result = 31 * result + (biometryId != null ? biometryId.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        result = 31 * result + (biometricValueSource != null ? biometricValueSource.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UserBiometricValue{" +
            "createdDate=" + createdDate +
            ", biometryId=" + biometryId +
            ", value=" + value +
            ", biometricValueSource=" + biometricValueSource +
            '}';
    }
}
