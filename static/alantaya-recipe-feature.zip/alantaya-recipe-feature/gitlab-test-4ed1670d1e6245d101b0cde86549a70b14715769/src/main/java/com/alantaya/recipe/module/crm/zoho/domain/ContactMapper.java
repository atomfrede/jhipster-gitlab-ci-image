package com.alantaya.recipe.module.crm.zoho.domain;

import com.alantaya.recipe.domain.User;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {})
public interface ContactMapper {

    @Mappings({
        @Mapping(source = "zohoId", target = "no"),
        @Mapping(target = "contactOwner", ignore = true),
        @Mapping(target = "accountName", ignore = true),
        @Mapping(target = "typeDeProspect", ignore = true),
        @Mapping(target = "bilanDietetique", ignore = true),
        @Mapping(target = "teleConseil", ignore = true),
        @Mapping(source = "firstName", target = "firstName"),
        @Mapping(source = "lastName", target = "lastName"),
        @Mapping(source = "email", target = "email"),
        @Mapping(source = "createdBy", target = "createdBy"),
        @Mapping(source = "createdDate", target = "createdTime"),
        @Mapping(source = "lastModifiedBy", target = "modifiedBy"),
        @Mapping(source = "lastModifiedDate", target = "modifiedTime"),
        @Mapping(source = "lastLoginAttempt", target = "lastActivityTime")
    })
    Contact userToContact(User user);
    List<Contact> usersToContacts(Collection<User> user);

    default String dateTimeToString(DateTime dateTime) {
        return DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZ").print(dateTime);
    }
}
