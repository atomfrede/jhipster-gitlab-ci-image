package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="Biometry",
    description = "Defines a human metric: weight, size, BMI...\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"id\": 1,\n" +
        "    \"name\": \"Poids\",\n" +
        "    \"description\": null,\n" +
        "    \"unit\": \"kg\"\n" +
        "}\n" +
        "----"
)
public class BiometryDTO {
    @ApiModelProperty(position = 0, required = true)
    private Long id;

    @ApiModelProperty(position = 1, required = true)
    private String name;

    @ApiModelProperty(position = 2, required = false)
    private String description;

    @ApiModelProperty(value = "unit short name ex: cm, kg...", position = 3, required = false)
    private String unit;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "BiometryDTO{" +
            "id=" + id +
            ", name='" + name + '\'' +
            ", description='" + description + '\'' +
            ", unit='" + unit + '\'' +
            '}';
    }
}
