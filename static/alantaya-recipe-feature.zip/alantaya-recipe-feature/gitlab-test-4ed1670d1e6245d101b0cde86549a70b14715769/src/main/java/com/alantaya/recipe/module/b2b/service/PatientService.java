package com.alantaya.recipe.module.b2b.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.enumeration.UserState;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.MailService;
import com.alantaya.recipe.service.SupervisionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.HashSet;
import java.util.Set;

@Service
public class PatientService {
    private final Logger log = LoggerFactory.getLogger(PatientService.class);

    @Inject private PasswordEncoder passwordEncoder;
    @Inject private UserRepository userRepository;
    @Inject private SupervisionService supervisionService;
    @Inject private MailService mailService;

    @Transactional
    public void createPatient(User pro,
                              String email,
                              String firstName,
                              String lastName,
                              String phoneNumber) {
        String password = "f&RLk87sh!@?";
        String encryptedPassword = passwordEncoder.encode(password);
        Set<Authority> authorities = new HashSet<>(1);
        authorities.add(new Authority(AuthoritiesConstants.USER));

        User newPatient = new User();
        newPatient.setPassword(encryptedPassword);
        newPatient.setFirstName(firstName);
        newPatient.setLastName(lastName);
        newPatient.setEmail(email);
        newPatient.setState(UserState.ACTIVE);
        newPatient.setAuthorities(authorities);
        newPatient.setLangKey("fr");
        newPatient.setPhoneNumber(phoneNumber);

        User patientSaved = userRepository.save(newPatient);
        supervisionService.addUserRelationship(pro, patientSaved);
        mailService.sendPatientRegistrationEmail(patientSaved, password);
    }
}
