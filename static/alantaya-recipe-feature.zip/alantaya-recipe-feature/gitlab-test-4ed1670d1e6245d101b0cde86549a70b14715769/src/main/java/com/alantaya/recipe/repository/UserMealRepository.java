package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.EatenDish;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import org.joda.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface UserMealRepository extends JpaRepository<UserMeal,Long> {

    @Query("select distinct userMeal " +
        "from UserMeal userMeal " +
        "left join fetch userMeal.mealType " +
        "left join fetch userMeal.recipes recipe " +
        "left join fetch recipe.type " +
        "left join fetch recipe.state " +
        "left join fetch recipe.foodQuantities recipeFoodQuantities " +
        "left join fetch recipeFoodQuantities.food recipeFood " +
        "left join fetch recipeFood.foodSection foodSection " +
        "left join fetch recipeFood.favoriteUnit " +
        "left join fetch userMeal.eatenDishes eatenDishe " +
        "left join fetch eatenDishe.type " +
        "left join fetch eatenDishe.foodQuantities eatenDisheFoodQuantities " +
        "left join fetch eatenDisheFoodQuantities.food eatenDisheFood " +
        "left join fetch eatenDisheFood.foodSection foodSection " +
        "left join fetch eatenDisheFood.favoriteUnit " +
        "where userMeal.user =:user and (userMeal.date between :startDate and :endDate)")
    List<UserMeal> findByUserAndDateBetween (
        @Param("user") User user,
        @Param("startDate") LocalDate startDate,
        @Param("endDate") LocalDate endDate
    );

    @Query("select distinct userMeal " +
        "from UserMeal userMeal " +
        "left join fetch userMeal.mealType " +
        "left join fetch userMeal.recipes recipe " +
        "left join fetch recipe.type " +
        "left join fetch recipe.state " +
        "left join fetch recipe.difficultyLevel " +
        "left join fetch recipe.costLevel " +
        "left join fetch recipe.season " +
        "left join fetch recipe.originCountry " +
        "left join fetch recipe.steps " +
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.basicFood " +
        "left join fetch food.favoriteUnit " +
        "left join fetch userMeal.eatenDishes eatenDishe " +
        "left join fetch eatenDishe.type " +
        "left join fetch eatenDishe.foodQuantities eatenDisheFoodQuantities " +
        "left join fetch eatenDisheFoodQuantities.food eatenDisheFood " +
        "left join fetch eatenDisheFood.foodSection foodSection " +
        "left join fetch eatenDisheFood.favoriteUnit " +
        "where userMeal.id =:id")
    @Override
    UserMeal findOne(@Param("id")Long id);

    @Query("select distinct userMeal " +
        "from UserMeal userMeal " +
        "left join fetch userMeal.mealType " +
        "left join fetch userMeal.recipes recipe " +
        "left join fetch recipe.type " +
        "left join fetch recipe.state " +
        "left join fetch recipe.difficultyLevel " +
        "left join fetch recipe.costLevel " +
        "left join fetch recipe.season " +
        "left join fetch recipe.originCountry " +
        "left join fetch recipe.steps " +
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.basicFood " +
        "left join fetch food.favoriteUnit " +
        "left join fetch userMeal.eatenDishes eatenDishe " +
        "left join fetch eatenDishe.type " +
        "left join fetch eatenDishe.foodQuantities eatenDisheFoodQuantities " +
        "left join fetch eatenDisheFoodQuantities.food eatenDisheFood " +
        "left join fetch eatenDisheFood.foodSection foodSection " +
        "left join fetch eatenDisheFood.favoriteUnit " +
        "where userMeal.user = :user and userMeal.id =:id")
    Optional<UserMeal> findOneByUserAndId(@Param("user") User user, @Param("id")Long id);

    List<UserMeal> findByUserAndEatenDishes(User user, List<EatenDish> eatenDishes);

    @Query("select distinct userMeal " +
        "from UserMeal userMeal " +
        "left join fetch userMeal.mealType " +
        "left join fetch userMeal.eatenDishes eatenDishe " +
        "left join fetch eatenDishe.type " +
        "where userMeal.user = ?1 and eatenDishe != null order by userMeal.date desc")
    List<UserMeal> findByUserAndEatenDishesIsNotNullOrderByDateDesc(User user);

    @Modifying
    @Query("delete from UserMeal userMeal where userMeal.user = ?1 and userMeal.date in (?2)")
    void deleteByUserAndDateIn(User user, Collection<LocalDate> localDates);

    @Modifying
    @Query("delete from UserMeal userMeal where userMeal.user = ?1 and userMeal.date >= ?2")
    void deleteByUserAndDateFrom(User user, LocalDate localDate);

    @Query("select distinct userMeal " +
        "from UserMeal userMeal " +
        "left join fetch userMeal.mealType " +
        "left join fetch userMeal.recipes recipe " +
        "left join fetch recipe.type " +
        "left join fetch recipe.state " +
        "left join fetch recipe.difficultyLevel " +
        "left join fetch recipe.costLevel " +
        "left join fetch recipe.season " +
        "left join fetch recipe.originCountry " +
        "left join fetch recipe.steps " +
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.basicFood " +
        "left join fetch food.favoriteUnit " +
        "left join fetch userMeal.eatenDishes eatenDishe " +
        "left join fetch eatenDishe.type " +
        "left join fetch eatenDishe.foodQuantities eatenDisheFoodQuantities " +
        "left join fetch eatenDisheFoodQuantities.food eatenDisheFood " +
        "left join fetch eatenDisheFood.foodSection foodSection " +
        "left join fetch eatenDisheFood.favoriteUnit " +
        "where userMeal.user = :user and userMeal.date = :date and userMeal.mealType.id = :mealTypeId")
    Optional<UserMeal> findOneByUserAndDateAndMealType(
        @Param("user") User user,
        @Param("date") LocalDate Date,
        @Param("mealTypeId") Long mealTypeId);

    List<UserMeal> findByUserIdAndDateGreaterThan(Long userId, LocalDate startDate);
}
