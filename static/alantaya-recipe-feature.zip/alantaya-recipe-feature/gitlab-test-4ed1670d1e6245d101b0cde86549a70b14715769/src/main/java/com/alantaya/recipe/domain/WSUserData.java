package com.alantaya.recipe.domain;

import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * A WSUserData.
 */
@Entity
@Table(name = "WS_USER_DATA")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class WSUserData implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "nb_licence", nullable = false)
    private Integer nbLicence;

    public WSUserData() {
    }

    public WSUserData(Integer nbLicence) {
        this.nbLicence = nbLicence;
    }

    public Integer getNbLicence() {
        return nbLicence;
    }

    public void setNbLicence(Integer nbLicence) {
        this.nbLicence = nbLicence;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof WSUserData)) return false;

        WSUserData that = (WSUserData) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        return !(nbLicence != null ? !nbLicence.equals(that.nbLicence) : that.nbLicence != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (nbLicence != null ? nbLicence.hashCode() : 0);
        return result;
    }
}
