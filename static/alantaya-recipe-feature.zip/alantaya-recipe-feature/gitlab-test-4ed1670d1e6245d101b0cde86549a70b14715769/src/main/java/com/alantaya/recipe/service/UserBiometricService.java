package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserBiometricValue;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class UserBiometricService {
    private final Logger log = LoggerFactory.getLogger(UserBiometricService.class);

    @Inject private BiometricService biometryService;
    @Inject private UserService userService;

    public void addBiometricValue(UserBiometricValue userBiometricValue) {
        User user = userService.getUser();
        biometryService.addBiometricValue(userBiometricValue, user);
    }

    public void addBiometricValues(Collection<UserBiometricValue> userBiometricValues) {
        User user = userService.getUser();
        biometryService.addBiometricValues(userBiometricValues, user);
    }

    public UserBiometricValue getBeforeLastUserBiometricValue(Long biometryId) {
        User user = userService.getUser();
        return biometryService.getBeforeLastUserBiometricValue(biometryId, user);
    }


    public Map<Long, UserBiometricValue> getAllBeforeLastUserBiometricValue() {
        final User user = userService.getUser();
        return biometryService.getAllBeforeLastUserBiometricValue(user);
    }

    public UserBiometricValue getBiometricValue(Long biometryId) {
        User user = userService.getUser();
        return biometryService.getBiometricValue(biometryId, user);
    }

    public List<UserBiometricValue> getBiometricValuesForBiometric(Long biometryId, DateTime fromDate) {
        User user = userService.getUser();
        return biometryService.getBiometricValuesForBiometric(biometryId, user, fromDate);
    }

    public List<UserBiometricValue> getBiometricValues() {
        User user = userService.getUser();
        return biometryService.getBiometricValues(user);
    }

    public Map<Long, UserBiometricValue> getLatestBiometricValueByBiometricId() {
        User user = userService.getUser();
        return biometryService.getLatestBiometricValueByBiometricId(user);
    }
}
