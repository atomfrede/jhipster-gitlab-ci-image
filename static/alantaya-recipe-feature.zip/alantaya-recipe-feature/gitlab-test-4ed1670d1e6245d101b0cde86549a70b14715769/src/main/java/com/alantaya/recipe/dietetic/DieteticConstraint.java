package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaType;

import java.util.Objects;

public class DieteticConstraint {
    private Long id;
    private DieteticElement dieteticElement;
    private Criteria criteria;
    private Double minQuantity;
    private Double maxQuantity;
    private Double weightingFactorRatio;

    public DieteticConstraint() {}

    public DieteticConstraint(Long id,
                              DieteticElement dieteticElement,
                              Long criteriaTypeId,
                              Double minQuantity,
                              Double maxQuantity,
                              Double weightingFactorRatio)
    {
        this(id,
            dieteticElement,
            createCriteria(criteriaTypeId),
            minQuantity,
            maxQuantity,
            weightingFactorRatio);
    }

    private static Criteria createCriteria(Long criteriaTypeId) {
        final CriteriaType criteriaType = new CriteriaType();
        criteriaType.setId(criteriaTypeId);
        final Criteria criteria = new Criteria();
        criteria.setId(-1L);
        criteria.setName("Criteria Volatile");
        criteria.setType(criteriaType);
        return criteria;
    }

    public DieteticConstraint(Long id,
                              DieteticElement dieteticElement,
                              Criteria criteria,
                              Double minQuantity,
                              Double maxQuantity,
                              Double weightingFactorRatio)
    {
        this.id = id;
        this.dieteticElement = dieteticElement;
        this.criteria = criteria;
        this.minQuantity = minQuantity;
        this.maxQuantity = maxQuantity;
        this.weightingFactorRatio = weightingFactorRatio;
    }

    public Long getId() {
        return id;
    }

    public DieteticElement getDieteticElement() {
        return dieteticElement;
    }

    public Double getMinQuantity() {
        return minQuantity;
    }

    public Double getMaxQuantity() {
        return maxQuantity;
    }

    public Double getWeightingFactorRatio() {
        return weightingFactorRatio;
    }

    public Long getCriteriaTypeId() {
        return criteria.getType().getId();
    }

    public Criteria getCriteria() {
        return criteria;
    }

    public void setCriteria(Criteria criteria) {
        this.criteria = criteria;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setDieteticElement(DieteticElement dieteticElement) {
        this.dieteticElement = dieteticElement;
    }


    public void setMinQuantity(Double minQuantity) {
        this.minQuantity = minQuantity;
    }

    public void setMaxQuantity(Double maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    public void setWeightingFactorRatio(Double weightingFactorRatio) {
        this.weightingFactorRatio = weightingFactorRatio;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticConstraint dieteticConstraint = (DieteticConstraint) o;

        if ( ! Objects.equals(id, dieteticConstraint.getId())) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, dieteticElement);
    }

    @Override
    public String toString() {
        return "DieteticConstraint{" +
            "id=" + id +
            ", dieteticElement='" + dieteticElement + "'" +
            ", minQuantity='" + minQuantity + "'" +
            ", maxQuantity='" + maxQuantity + "'" +
            ", weightingFactorRatio='" + weightingFactorRatio + "'" +
            '}';
    }
}
