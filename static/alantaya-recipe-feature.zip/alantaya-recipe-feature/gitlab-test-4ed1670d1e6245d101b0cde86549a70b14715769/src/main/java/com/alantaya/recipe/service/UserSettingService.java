package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserSetting;
import com.alantaya.recipe.repository.UserSettingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class UserSettingService {
    private final Logger log = LoggerFactory.getLogger(UserSettingService.class);

    @Inject private UserService userService;
    @Inject private SettingService settingService;

    public void saveSetting(UserSetting setting) {
        final User currentUser = userService.getUser();
        settingService.saveSetting(setting, currentUser);
    }

    public UserSetting getUserSetting(UserSettingType type) {
        final User currentUser = userService.getUser();
        return settingService.getUserSetting(type, currentUser);
    }

    public List<UserSetting> getUserSettings() {
        final User currentUser = userService.getUser();
        return settingService.getUserSettings(currentUser);
    }
}
