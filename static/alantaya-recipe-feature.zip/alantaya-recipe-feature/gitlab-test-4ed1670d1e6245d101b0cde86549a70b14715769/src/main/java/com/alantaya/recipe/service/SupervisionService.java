package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import java.util.Optional;
import java.util.stream.Stream;

@Service
public class SupervisionService {
    private final Logger log = LoggerFactory.getLogger(SupervisionService.class);

    @Inject private UserRepository userRepository;

    @Transactional
    public void addUserRelationship(User supervisor, User user) {
        if (! supervisor.getAuthorities().contains(Authority.SUPERVISOR)) {
            log.debug("User has not right to create relationship: user -> {}", supervisor);
            return;
        }
        supervisor.getSupervisedUsers().add(user);
        userRepository.save(supervisor);
    }

    @Transactional
    public void deleteUserRelationship(User supervisor, User user) {
        if (!supervisor.getAuthorities().contains(Authority.SUPERVISOR)) {
            log.debug("User has not right to delete relationship: user -> {}", supervisor);
            return;
        }
        supervisor.getSupervisedUsers().remove(user);
        userRepository.save(supervisor);
    }

    @Transactional(readOnly = true)
    public Optional<User> getSupervisedUser(Cookie[] cookies, User supervisor) {
        Optional<Long> supervisedUserId = getSupervisedUserId(cookies);
        if (!supervisedUserId.isPresent()) {
            return Optional.empty();
        }

        User supervisedUser = userRepository.findOne(supervisedUserId.get());
        if (supervisor.getAuthorities().contains(Authority.ADMIN)
            && supervisor.getAuthorities().contains(Authority.SUPERVISOR)) {
            return Optional.of(supervisedUser);
        }
        else if (supervisor.getAuthorities().contains(Authority.SUPERVISOR)
            && supervisor.getSupervisedUsers().contains(supervisedUser)) {
            return Optional.of(supervisedUser);
        }
        log.debug("User has not right to supervise another user: user -> {}", supervisor);
        return Optional.empty();
    }

    @Transactional(readOnly = true)
    public boolean isSupervisedBy(User supervisedUser, User supervisor) {
        return supervisor.getSupervisedUsers().contains(supervisedUser);
    }

    @Transactional(readOnly = true)
    public Optional<User> getCurrentSupervisor() {
        return userRepository.findOneByEmail(SecurityUtils.getCurrentEmail());
    }

    private Optional<Long> getSupervisedUserId(Cookie[] cookies) {
        return Stream.of(cookies)
            .filter(this::isSupervisionCookie)
            .map(Cookie::getValue)
            .map(Long::valueOf)
            .findFirst();
    }

    private boolean isSupervisionCookie(Cookie cookie) {
        return "supervisedUserId".equals(cookie.getName());
    }
}
