package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.QuestionnaireQuestion;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserQuestionnaireAnswer;
import com.alantaya.recipe.repository.BiometryRepository;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.repository.QuestionnaireQuestionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PersonalDataExportService {

    @Inject private UserService userService;
    @Inject private UserBiometricService userBiometricService;
    @Inject private BiometryRepository biometryRepository;
    @Inject private UserQuestionnaireService userQuestionnaireService;
    @Inject private QuestionnaireQuestionRepository questionnaireQuestionRepository;
    @Inject private CriteriaRepository criteriaRepository;

    @Transactional(readOnly = true)
    public String getUserPersonalDataExport() {
        return getUserBiometryExport() + getUserTasteExport() + getUserQuestionnaireExport();
    }

    private String getUserBiometryExport() {
        StringBuilder biometricsExport = new StringBuilder();
        biometricsExport.append("Mes biométries:\n");

        userBiometricService.getBiometricValues().forEach(
            userBiometricValue -> {
                Biometry biometric = biometryRepository.getOne(userBiometricValue.getBiometryId());
                biometricsExport.append(userBiometricValue.getCreatedDate())
                    .append(";")
                    .append(biometric.getName())
                    .append(";")
                    .append(userBiometricValue.getValue())
                    .append("\n");
            }
        );

        biometricsExport.append("\n");
        return biometricsExport.toString();
    }

    private String getUserTasteExport() {
        User user = userService.getUser();
        StringBuilder tasteExport = new StringBuilder();
        tasteExport.append("Mes gouts:\n");

        user.getDislikedFoods().forEach(
            basicFood -> tasteExport.append(basicFood.getName()).append("\n")
        );

        tasteExport.append("\n");
        return tasteExport.toString();
    }

    private String getUserQuestionnaireExport() {
        StringBuilder questionnaireExport = new StringBuilder();
        questionnaireExport.append("Mon Profil:\n");

        List<UserQuestionnaireAnswer> answers = userQuestionnaireService.getUserAnswers();
        answers.forEach(
            answer -> {
                QuestionnaireQuestion question = questionnaireQuestionRepository.findOne(answer.getQuestionId());
                questionnaireExport
                    .append(question.getPage().getName())
                    .append(";")
                    .append(question.getQuestionText())
                    .append(";")
                    .append(getCriteriaNameList(answer.getCriteriaIds()))
                    .append(";")
                    .append(answer.getStrAnswer())
                    .append("\n");
            }
        );

        questionnaireExport.append("\n");
        return questionnaireExport.toString();
    }

    private List<String> getCriteriaNameList(List<Long> criteriaIds) {
        return criteriaIds.stream()
            .map(id -> criteriaRepository.findOne(id).getQuestionnaireName())
            .collect(Collectors.toList());
    }
}
