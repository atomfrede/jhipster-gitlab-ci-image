package com.alantaya.recipe.connected.device.withings.domain;

public class WithingsResponse {
    private Integer status;
    private MeasureResult body;

    public WithingsResponse() {}

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public MeasureResult getBody() {
        return body;
    }

    public void setBody(MeasureResult body) {
        this.body = body;
    }

    @Override
    public String toString() {
        return "WithingsResponse{" +
                "status=" + status +
                ", body=" + body +
                '}';
    }
}
