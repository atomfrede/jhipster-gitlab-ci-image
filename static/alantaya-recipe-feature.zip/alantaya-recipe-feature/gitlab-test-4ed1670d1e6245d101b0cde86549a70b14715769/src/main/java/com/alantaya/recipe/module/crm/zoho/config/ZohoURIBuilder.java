package com.alantaya.recipe.module.crm.zoho.config;

import org.apache.http.client.utils.URIBuilder;

import java.net.URI;
import java.net.URISyntaxException;

public class ZohoURIBuilder {

    private String baseZohoUrl;
    private URIBuilder uri;

    public ZohoURIBuilder(String baseZohoUrl, String authtoken, String scope, String newFormat) {
        this.baseZohoUrl = baseZohoUrl;
        uri = new URIBuilder()
            .setParameter("authtoken", authtoken)
            .setParameter("scope", scope)
            .setParameter("newFormat", newFormat);
    }

    public ZohoURIBuilder(String baseZohoUrl, String authtoken, String scope, String newFormat, String version) {
        this.baseZohoUrl = baseZohoUrl;
        uri = new URIBuilder()
            .setParameter("authtoken", authtoken)
            .setParameter("scope", scope)
            .setParameter("version", version);
    }

    public ZohoURIBuilder setPath(String path){
        uri.setPath(baseZohoUrl + path);
        return this;
    }

    public ZohoURIBuilder setId(String id){
        uri.setParameter("id", id);
        return this;
    }

    public ZohoURIBuilder setSearch(String key, String value){
        uri.setParameter("searchColumn", key.toLowerCase());
        uri.setParameter("searchValue", value);
        return this;
    }


    public ZohoURIBuilder setXmlData(String xmlData){
        uri.setParameter("xmlData", xmlData);
        return this;
    }

    public URI build() throws URISyntaxException {
        return uri.build();
    }
}
