package com.alantaya.recipe.dietetic;


import com.alantaya.recipe.domain.EatenDish;
import com.alantaya.recipe.domain.FoodQuantityByEatenDish;
import com.alantaya.recipe.domain.RecipeType;
import com.alantaya.recipe.domain.User;

import java.util.*;
import java.util.stream.Collectors;

public class DieteticEatenDish extends EatenDish implements DieteticStatistic {

    private EatenDish eatenDish;
    private final List<DieteticFoodQuantityByEatenDish> dieteticFoodQuantityByEatenDish;

    public DieteticEatenDish(EatenDish eatenDish) {
        this.eatenDish = eatenDish;
        this.dieteticFoodQuantityByEatenDish = eatenDish.getFoodQuantities().stream()
            .map(DieteticFoodQuantityByEatenDish::new)
            .collect(Collectors.toList());
    }

    public List<DieteticFoodQuantityByEatenDish> getDieteticFoodQuantities() {
        return dieteticFoodQuantityByEatenDish;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        Double quantity = dieteticFoodQuantityByEatenDish.stream()
            .mapToDouble(foodQuantity -> foodQuantity.getQuantityFor(dieteticElement))
            .sum();
        return quantity;
    }

    @Override
    public Long getId() {
        return eatenDish.getId();
    }

    @Override
    public void setId(Long id) {
        eatenDish.setId(id);
    }

    @Override
    public String getTitle() {
        return eatenDish.getTitle();
    }

    @Override
    public void setTitle(String title) {
        eatenDish.setTitle(title);
    }

    @Override
    public RecipeType getType() {
        return eatenDish.getType();
    }

    @Override
    public void setType(RecipeType recipeType) {
        eatenDish.setType(recipeType);
    }

    @Override
    public User getUser() {
        return eatenDish.getUser();
    }

    @Override
    public void setUser(User user) {
        eatenDish.setUser(user);
    }

    @Override
    public Set<FoodQuantityByEatenDish> getFoodQuantities() {
        return eatenDish.getFoodQuantities();
    }

    @Override
    public void setFoodQuantities(Set<FoodQuantityByEatenDish> foodQuantities) {
        eatenDish.setFoodQuantities(foodQuantities);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticEatenDish dieteticEatenDish = (DieteticEatenDish) o;

        return eatenDish.equals(dieteticEatenDish.eatenDish);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), eatenDish.getId());
    }

    @Override
    public String toString() {
        return "DieteticEatenDish{" +
            "id=" + getId() +
            ", title='" + getTitle() + "'" +
            '}';
    }
}
