package com.alantaya.recipe.module.b2b.rest.dto;

import com.alantaya.recipe.domain.City;
import com.alantaya.recipe.domain.UserProfessionalInformation;
import com.alantaya.recipe.domain.enumeration.JobType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Email;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfessionalDTO extends UserProfessionalInformation {
    @NotNull
    @Pattern(regexp = "^(?=.*\\W)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).*$")
    @Size(min = 8, max = 100)
    private String password;

    @Size(max = 50)
    private String firstName;

    @Size(max = 50)
    private String lastName;

    @Email
    @Size(min = 5, max = 100)
    @NotNull
    private String email;

    public UserProfessionalDTO() {}
    public UserProfessionalDTO(String firstName,
                               String lastName,
                               String address,
                               City city,
                               String phoneNumber,
                               String adeliNumber,
                               JobType jobType,
                               String jobNumber,
                               String diplomaName,
                               Integer diplomaYear,
                               String comment) {
        super(address,
            city,
            phoneNumber,
            adeliNumber,
            jobType,
            jobNumber,
            diplomaName,
            diplomaYear,
            comment,
            true);
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "UserProfessionalDTO{" +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", email='" + email + '\'' +
            '}';
    }
}
