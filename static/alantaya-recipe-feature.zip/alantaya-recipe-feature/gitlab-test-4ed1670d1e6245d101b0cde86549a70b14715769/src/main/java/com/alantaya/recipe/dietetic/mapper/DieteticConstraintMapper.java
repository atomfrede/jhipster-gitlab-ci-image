package com.alantaya.recipe.dietetic.mapper;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaConstraint;
import org.mapstruct.DecoratedWith;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@Mapper(componentModel = "spring", uses = {})
@DecoratedWith(DieteticConstraintDecorator.class)
public abstract class DieteticConstraintMapper {

    @Mapping(target = "dieteticElement", ignore = true)
    @Mapping(target = "weightingFactorRatio", source = "weightingFactor.ratio")
    public abstract DieteticConstraint criteriaConstraintToDieteticConstraint(CriteriaConstraint criteriaConstraint);
    public abstract List<DieteticConstraint> criteriaConstraintsToDieteticConstraints(Set<CriteriaConstraint> criteriaConstraints);

    public List<DieteticConstraint> criteriaToDieteticConstraints(Criteria criteria) {
        if (criteria == null) return Collections.emptyList();
        return criteriaConstraintsToDieteticConstraints(criteria.getConstraints());
    }

    public List<DieteticConstraint> criteriasToDieteticConstraints(List<Criteria> criterias) {
        final List<DieteticConstraint> dieteticConstraints = new ArrayList<>(10000);
        criterias.stream().forEach( criteria -> dieteticConstraints.addAll(criteriaToDieteticConstraints(criteria)) );
        return dieteticConstraints;
    }

}
