package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeProfile;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeProfile entity.
 */
public interface RecipeProfileRepository extends JpaRepository<RecipeProfile,Long> {

}
