/**
 * Copyright (c) 2010-2015, openHAB.org and others.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package com.alantaya.recipe.connected.device.withings.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Measure {
	public static final Integer TYPE_WEIGHT = 1;
	public static final Integer TYPE_HEIGHT = 4;
	public static final Integer TYPE_FAT_FREE_MASS = 5;
	public static final Integer TYPE_FAT_RATIO = 6;
	public static final Integer TYPE_FAT_WEIGHT = 8;
	public static final Integer TYPE_DIASTOLIC_BLOOD_PRESSURE = 9;
	public static final Integer TYPE_SYSTOLIC_BLOOD_PRESSURE = 10;
	public static final Integer TYPE_HEART_PULSE = 11;
	public static final Integer TYPE_SP02 = 54;

	private Integer type;
	private Integer unit;
	private Integer value;

	public Measure() {}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getUnit() {
		return unit;
	}

	public void setUnit(Integer unit) {
		this.unit = unit;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public Double getActualValue() {
		return (value * Math.pow(10, unit));
	}

	@Override
	public String toString() {
		return "Measure{" +
				"type=" + type +
				", unit=" + unit +
				", value=" + value +
				'}';
	}
}
