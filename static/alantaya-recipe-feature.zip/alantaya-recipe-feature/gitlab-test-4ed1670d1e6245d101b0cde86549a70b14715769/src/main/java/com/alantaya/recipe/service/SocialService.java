package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.enumeration.UserState;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.social.connect.Connection;
import org.springframework.social.connect.ConnectionRepository;
import org.springframework.social.connect.UserProfile;
import org.springframework.social.connect.UsersConnectionRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
public class SocialService {
    private final Logger log = LoggerFactory.getLogger(SocialService.class);

    @Inject private UsersConnectionRepository usersConnectionRepository;
    @Inject private PasswordEncoder passwordEncoder;
    @Inject private UserRepository userRepository;
    @Inject private MailService mailService;

    public void createSocialUser(Connection<?> connection, String partnerCode) {
        if (connection == null) {
            log.error("Cannot create social user because connection is null");
            throw new IllegalArgumentException("Connection cannot be null");
        }
        UserProfile userProfile = connection.fetchUserProfile();
        User user = createUserIfNotExist(userProfile, partnerCode);
        createSocialConnection(user.getEmail(), connection);
        mailService.sendSocialRegistrationValidationEmail(user, connection.getKey().getProviderId());
    }

    private User createUserIfNotExist(UserProfile userProfile, String partnerCode) {
        String email = userProfile.getEmail();
        if (StringUtils.isBlank(email)) {
            log.error("Cannot create social user because email and login are null");
            throw new IllegalArgumentException("Email and login cannot be null");
        }
        Optional<User> user = userRepository.findOneByEmail(email);
        if (user.isPresent()) {
            log.info("User already exist associate the connection to this account");
            return user.get();
        }

        String encryptedPassword = passwordEncoder.encode(RandomStringUtils.random(10));
        Set<Authority> authorities = new HashSet<>(1);
        authorities.add(new Authority(AuthoritiesConstants.PRE_PAYMENT));

        User newUser = new User();
        newUser.setPassword(encryptedPassword);
        newUser.setFirstName(userProfile.getFirstName());
        newUser.setLastName(userProfile.getLastName());
        newUser.setEmail(email);
        newUser.setState(UserState.ACTIVE);
        newUser.setAuthorities(authorities);
        newUser.setLangKey("fr");
        newUser.setPartnerCode(partnerCode);

        return userRepository.save(newUser);
    }

    private void createSocialConnection(String login, Connection<?> connection) {
        ConnectionRepository connectionRepository = usersConnectionRepository.createConnectionRepository(login);
        connectionRepository.addConnection(connection);
    }
}
