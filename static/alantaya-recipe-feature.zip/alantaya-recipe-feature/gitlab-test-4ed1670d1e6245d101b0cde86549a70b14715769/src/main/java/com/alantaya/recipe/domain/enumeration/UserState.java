package com.alantaya.recipe.domain.enumeration;

/**
 * The UserState enumeration.
 */
public enum UserState {
    ACTIVE, PENDING, DELETED
}
