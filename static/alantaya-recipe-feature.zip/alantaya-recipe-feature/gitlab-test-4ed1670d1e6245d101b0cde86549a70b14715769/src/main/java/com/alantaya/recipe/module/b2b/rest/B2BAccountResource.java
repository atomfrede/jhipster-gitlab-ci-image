package com.alantaya.recipe.module.b2b.rest;

import com.alantaya.recipe.module.b2b.rest.dto.UserProfessionalDTO;
import com.alantaya.recipe.module.b2b.service.UserProfessionalService;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.security.SecurityUtils;
import com.codahale.metrics.annotation.Timed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.Valid;

/**
 * REST controller for managing the current user's account.
 */
@RestController
@RequestMapping("/api")
public class B2BAccountResource {
    private final Logger log = LoggerFactory.getLogger(B2BAccountResource.class);

    @Inject private UserProfessionalService userProfessionalService;
    @Inject private UserRepository userRepository;

    /**
     * POST  /b2b-register -> register the professional user.
     */
    @RequestMapping(value = "/b2b-register",
        method = RequestMethod.POST,
        produces = MediaType.TEXT_PLAIN_VALUE)
    @Timed
    @Transactional
    public ResponseEntity<?> registerAccount(@Valid @RequestBody UserProfessionalDTO userProfessionalDTO) {
        return userRepository.findOneByEmail(userProfessionalDTO.getEmail())
            .map(user -> new ResponseEntity<>("e-mail address already in use", HttpStatus.BAD_REQUEST))
            .orElseGet(() -> {
                userProfessionalService.createUserProfessional(
                    userProfessionalDTO.getFirstName(),
                    userProfessionalDTO.getLastName(),
                    userProfessionalDTO.getEmail().toLowerCase(),
                    userProfessionalDTO.getPassword(),
                    userProfessionalDTO.getAddress(),
                    userProfessionalDTO.getCity(),
                    userProfessionalDTO.getPhoneNumber(),
                    userProfessionalDTO.getAdeliNumber(),
                    userProfessionalDTO.getJobType(),
                    userProfessionalDTO.getJobNumber(),
                    userProfessionalDTO.getDiplomaName(),
                    userProfessionalDTO.getDiplomaYear(),
                    userProfessionalDTO.getComment(),
                    userProfessionalDTO.getIsAcceptCGU());
                return new ResponseEntity<>(HttpStatus.CREATED);
            });
    }

    /**
     * POST  /b2b-account -> update the current professional user information.
     */
    @RequestMapping(value = "/b2b-account",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.PRO)
    @Transactional
    public ResponseEntity<?> saveAccount(@RequestBody UserProfessionalDTO userProfessionalDTO) {
        return userRepository.findOneByEmail(userProfessionalDTO.getEmail())
            .filter(user ->  user.getEmail().equals(SecurityUtils.getCurrentEmail()))
            .map(user -> {
                userProfessionalService.updateUserProfessional(
                    userProfessionalDTO.getFirstName(),
                    userProfessionalDTO.getLastName(),
                    userProfessionalDTO.getAddress(),
                    userProfessionalDTO.getCity(),
                    userProfessionalDTO.getPhoneNumber(),
                    userProfessionalDTO.getAdeliNumber(),
                    userProfessionalDTO.getJobType(),
                    userProfessionalDTO.getJobNumber(),
                    userProfessionalDTO.getDiplomaName(),
                    userProfessionalDTO.getDiplomaYear(),
                    userProfessionalDTO.getComment());
                return new ResponseEntity<>(HttpStatus.OK);
            })
            .orElseGet(() -> new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
    }

    /**
     * GET  /b2b-account -> get the current user.
     */
    @RequestMapping(value = "/b2b-account",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.PRO)
    @Transactional(readOnly = true)
    public ResponseEntity<UserProfessionalDTO> getAccount() {
        return userRepository.findOneByEmail(SecurityUtils.getCurrentEmail())
            .filter(user ->  user.getEmail().equals(SecurityUtils.getCurrentEmail()))
            .map(user ->  new ResponseEntity<>(
                    new UserProfessionalDTO(
                        user.getFirstName(),
                        user.getLastName(),
                        user.getUserProfessionalInformation().getAddress(),
                        user.getUserProfessionalInformation().getCity(),
                        user.getUserProfessionalInformation().getPhoneNumber(),
                        user.getUserProfessionalInformation().getAdeliNumber(),
                        user.getUserProfessionalInformation().getJobType(),
                        user.getUserProfessionalInformation().getJobNumber(),
                        user.getUserProfessionalInformation().getDiplomaName(),
                        user.getUserProfessionalInformation().getDiplomaYear(),
                        user.getUserProfessionalInformation().getComment()
                    ),
                    HttpStatus.OK))
            .orElseGet(() -> new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
    }
}
