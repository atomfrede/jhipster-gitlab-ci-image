package com.alantaya.recipe.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;

/**
 * A Criteria.
 */
@Entity
@Table(name = "T_CRITERIA")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class Criteria extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "name", length = 100, nullable = false)
    @JsonView(View.Minimal.class)
    private String name;

    @NotNull
    @Size(max = 100)
    @Column(name = "questionnaire_name", length = 100, nullable = false)
    @JsonView(View.Minimal.class)
    private String questionnaireName;

    @Size(max = 300)
    @Column(name = "description", length = 300)
    @JsonView(View.Summary.class)
    private String description;

    @ManyToOne
    @JsonView(View.Summary.class)
    private CriteriaType type;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_CRITERIA_CRITERIAGROUPS",
               joinColumns = @JoinColumn(name="criteria_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="group_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<CriteriaGroup> groups = new HashSet<>();

    @ManyToOne
    @JsonView(View.Summary.class)
    private CriteriaState state;

    @OneToMany(mappedBy = "criteria", cascade = CascadeType.ALL, orphanRemoval=true)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.Full.class)
    private Set<CriteriaConstraint> constraints = new HashSet<>();


    @OneToMany(mappedBy = "criteria", cascade = CascadeType.ALL, orphanRemoval=true)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.Summary.class)
    private Set<CriteriaProfiling> criteriaProfilings = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuestionnaireName() {
        return questionnaireName;
    }

    public void setQuestionnaireName(String questionnaireName) {
        this.questionnaireName = questionnaireName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CriteriaType getType() {
        return type;
    }

    public void setType(CriteriaType criteriaType) {
        this.type = criteriaType;
    }

    public Set<CriteriaGroup> getGroups() {
        return groups;
    }

    public void setGroups(Set<CriteriaGroup> criteriaGroups) {
        this.groups = criteriaGroups;
    }

    public CriteriaState getState() {
        return state;
    }

    public void setState(CriteriaState criteriaState) {
        this.state = criteriaState;
    }

    public Set<CriteriaConstraint> getConstraints() {
        return constraints;
    }

    public void setConstraints(Set<CriteriaConstraint> constraints) {
        this.constraints = constraints;
    }


    public Set<CriteriaProfiling> getCriteriaProfilings() {
        return criteriaProfilings;
    }

    public void setCriteriaProfilings(Set<CriteriaProfiling> criteriaProfilings) {
        this.criteriaProfilings = criteriaProfilings;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Criteria criteria = (Criteria) o;

        if ( ! Objects.equals(id, criteria.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Criteria{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", description='" + description + "'" +
                '}';
    }
}
