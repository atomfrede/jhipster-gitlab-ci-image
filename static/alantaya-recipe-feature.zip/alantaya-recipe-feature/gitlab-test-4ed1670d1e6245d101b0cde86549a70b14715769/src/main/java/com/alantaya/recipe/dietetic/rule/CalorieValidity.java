package com.alantaya.recipe.dietetic.rule;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.repository.NutrimentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Service
public class CalorieValidity implements DieteticRule {
    private final Logger log = LoggerFactory.getLogger(CalorieValidity.class);

    private static final Double ENERGY_WITHOUT_BREAKFAST = 0.75;

    @Inject
    private NutrimentRepository nutrimentRepository;

    @Override
    public boolean isValid(DieteticStatistic dieteticStatisticToValidate, List<DieteticConstraint> dieteticConstraints) {
        if (dieteticStatisticToValidate instanceof DieteticMenuDay)
        {
            Optional<DieteticConstraint> calorieConstraint = dieteticConstraints.stream()
                 .filter(this::isCalorieConstraint).findFirst();
            if (! calorieConstraint.isPresent()) return true;

            return isInRange(calorieConstraint.get(), dieteticStatisticToValidate);
        }
        return true;
    }

    private boolean isCalorieConstraint(DieteticConstraint dieteticConstraint){
        return (dieteticConstraint.getDieteticElement() instanceof DieteticNutriment)
            && Nutriment.CALORIE_ID.equals(dieteticConstraint.getDieteticElement().getId());
    }

    private boolean isInRange(DieteticConstraint dieteticConstraint, DieteticStatistic dieteticStatisticToValidate) {
        final Double calorieToValidate =  dieteticStatisticToValidate.getQuantityFor(getCalorieNutriment());
        if (!isMinValid(dieteticConstraint, calorieToValidate)) {
            DieteticLogUtil.log(log, dieteticStatisticToValidate, dieteticConstraint, "Under min -> "+calorieToValidate);
            return false;
        }
        if (!isMaxValid(dieteticConstraint, calorieToValidate)) {
            DieteticLogUtil.log(log, dieteticStatisticToValidate, dieteticConstraint, "Above max -> "+calorieToValidate);
            return false;
        }
        return true;

    }

    private static boolean isMinValid(DieteticConstraint dieteticConstraint, Double quantityToValidate) {
        final Double minQuantityReference = dieteticConstraint.getMinQuantity() * ENERGY_WITHOUT_BREAKFAST;
        return (minQuantityReference == null || quantityToValidate >= minQuantityReference);
    }

    private static boolean isMaxValid(DieteticConstraint dieteticConstraint, Double quantityToValidate) {
        final Double maxQuantityReference = dieteticConstraint.getMaxQuantity() * ENERGY_WITHOUT_BREAKFAST;
        return (maxQuantityReference == null || quantityToValidate <= maxQuantityReference);
    }

    private DieteticNutriment getCalorieNutriment() {
        return new DieteticNutriment(nutrimentRepository.findOne(Nutriment.CALORIE_ID));
    }
}
