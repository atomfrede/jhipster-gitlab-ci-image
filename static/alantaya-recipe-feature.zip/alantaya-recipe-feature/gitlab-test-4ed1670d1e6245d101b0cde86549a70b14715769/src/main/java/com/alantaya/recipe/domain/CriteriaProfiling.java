package com.alantaya.recipe.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;

/**
 * A CriteriaProfiling.
 */
@Entity
@Table(name = "CRITERIA_PROFILING")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class CriteriaProfiling implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @Column(name = "min_quantity")
    @JsonView(View.Full.class)
    private Double minQuantity;

    @Column(name = "max_quantity")
    @JsonView(View.Full.class)
    private Double maxQuantity;

    @ManyToOne
    @JsonIgnore
    private Criteria criteria;

    @ManyToOne
    @JsonView(View.Full.class)
    private Biometry biometry;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getMinQuantity() {
        return minQuantity;
    }

    public void setMinQuantity(Double minQuantity) {
        this.minQuantity = minQuantity;
    }

    public Double getMaxQuantity() {
        return maxQuantity;
    }

    public void setMaxQuantity(Double maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    public Criteria getCriteria() {
        return criteria;
    }

    public void setCriteria(Criteria criteria) {
        this.criteria = criteria;
    }

    public Biometry getBiometry() {
        return biometry;
    }
    
    public void setBiometry(Biometry biometry) {
        this.biometry = biometry;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CriteriaProfiling criteriaProfiling = (CriteriaProfiling) o;

        if ( ! Objects.equals(id, criteriaProfiling.id)) return false;
        if ( ! Objects.equals(criteria, criteriaProfiling.criteria)) return false;
        if ( ! Objects.equals(biometry, criteriaProfiling.biometry)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, criteria, biometry);
    }

    @Override
    public String toString() {
        return "CriteriaConstraint{" +
                "id=" + id +
                ", minQuantity='" + minQuantity + "'" +
                ", maxQuantity='" + maxQuantity + "'" +
                '}';
    }
}
