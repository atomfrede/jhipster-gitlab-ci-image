/**
 * Async helpers.
 */
package com.alantaya.recipe.async;
