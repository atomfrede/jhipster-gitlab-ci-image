package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserProfessionalInformation;

import org.springframework.data.jpa.repository.*;

/**
 * Spring Data JPA repository for the UserProfessionalInformation entity.
 */
public interface UserProfessionalInformationRepository extends JpaRepository<UserProfessionalInformation,Long> {

}
