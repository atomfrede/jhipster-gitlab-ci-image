package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.domain.NutrimentPerFood;
import com.alantaya.recipe.domain.Unit;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DieteticNutrimentPerFood extends NutrimentPerFood implements DieteticStatistic {
    private final NutrimentPerFood nutrimentPerFood;
    private final DieteticNutriment dieteticNutriment;

    public DieteticNutrimentPerFood(NutrimentPerFood nutrimentPerFood) {
        this.nutrimentPerFood = nutrimentPerFood;
        this.dieteticNutriment = new DieteticNutriment(nutrimentPerFood.getNutriment());
    }

    @Override
    public String toString() {
        return "DieteticNutrimentPerFood{" +
            "id=" + getId() +
            ", quantity='" + getQuantity() + "'" +
            ", nutrimentName='" + getNutriment().getName() + "'" +
            '}';
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        double quantity = dieteticNutriment.getQuantityFor(dieteticElement) * getQuantity();
        return quantity;
    }

    @Override
    public Long getId() {
        return nutrimentPerFood.getId();
    }

    @Override
    public void setId(Long id) {
        nutrimentPerFood.setId(id);
    }

    @Override
    public Double getQuantity() {
        return nutrimentPerFood.getQuantity();
    }

    @Override
    public void setQuantity(Double quantity) {
        nutrimentPerFood.setQuantity(quantity);
    }

    @Override
    public Food getFood() {
        return nutrimentPerFood.getFood();
    }

    @Override
    public void setFood(Food food) {
        nutrimentPerFood.setFood(food);
    }

    @Override
    public Nutriment getNutriment() {
        return nutrimentPerFood.getNutriment();
    }

    @Override
    public void setNutriment(Nutriment nutriment) {
        nutrimentPerFood.setNutriment(nutriment);
    }

    @Override
    public Unit getUNit() {
        return nutrimentPerFood.getUNit();
    }

    @Override
    public void setUNit(Unit unit) {
        nutrimentPerFood.setUNit(unit);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticNutrimentPerFood dieteticNutrimentPerFood = (DieteticNutrimentPerFood) o;

        return nutrimentPerFood.equals(dieteticNutrimentPerFood.nutrimentPerFood);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), nutrimentPerFood.getId());
    }
}
