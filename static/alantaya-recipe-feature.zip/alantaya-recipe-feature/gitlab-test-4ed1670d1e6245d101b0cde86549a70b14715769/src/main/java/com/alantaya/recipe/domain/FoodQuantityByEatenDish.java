package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A FoodQuantityByEatenDish.
 */
@Entity
@Table(name = "FOOD_QUANTITY_BY_EATEN_DISH")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FoodQuantityByEatenDish implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "amount_in_grams", nullable = false)
    private Integer amountInGrams;

    @ManyToOne
    private Food food;

    @ManyToOne
    @JsonIgnore
    private EatenDish eatenDish;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAmountInGrams() {
        return amountInGrams;
    }

    public void setAmountInGrams(Integer amountInGrams) {
        this.amountInGrams = amountInGrams;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public EatenDish getEatenDish() {
        return eatenDish;
    }

    public void setEatenDish(EatenDish eatenDish) {
        this.eatenDish = eatenDish;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FoodQuantityByEatenDish foodQuantityByEatenDish = (FoodQuantityByEatenDish) o;

        if ( ! Objects.equals(id, foodQuantityByEatenDish.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, food);
    }

    @Override
    public String toString() {
        return "FoodQuantityByEatenDish{" +
                "id=" + id +
                ", amountInGrams='" + amountInGrams + "'" +
                '}';
    }
}
