package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Nutriment;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Nutriment entity.
 */
public interface NutrimentRepository extends JpaRepository<Nutriment,Long> {

}
