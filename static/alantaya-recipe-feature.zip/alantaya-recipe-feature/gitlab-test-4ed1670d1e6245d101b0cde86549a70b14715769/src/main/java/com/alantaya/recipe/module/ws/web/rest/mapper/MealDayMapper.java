package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.module.ws.web.rest.dto.MealDayDTO;
import com.alantaya.recipe.module.ws.web.rest.dto.NutritionalValueDTO;
import com.alantaya.recipe.service.NutritionalService;
import com.alantaya.recipe.service.dto.BasicNutritionalValues;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class MealDayMapper {

    @Inject private NutritionalUserMealMapper nutritionalUserMealMapper;
    @Inject private NutritionalValueMapper nutritionalValueMapper;
    @Inject private NutritionalService nutritionalService;

    public List<MealDayDTO> userMealsToMealDayDTOs(Collection<UserMeal> userMeals) {
        List<MealDayDTO> mealDayDTOs = new ArrayList<>();
            userMeals.stream()
            .collect(Collectors.groupingBy(UserMeal::getDate))
            .forEach((date, meals) -> mealDayDTOs.add(mealsOfSameDayToMealDayDTO(date, meals)));
        return mealDayDTOs;
    }

    private MealDayDTO mealsOfSameDayToMealDayDTO(LocalDate date, List<UserMeal> meals) {
        MealDayDTO mealDayDTO = new MealDayDTO();
        mealDayDTO.setDate(date);
        mealDayDTO.setMeals(
            meals.stream().map(nutritionalUserMealMapper::userMealToMealDayDTO)
                .collect(Collectors.toList())
        );
        mealDayDTO.setNutritionalValue(getNutritionalValuesDTO(meals));
        return mealDayDTO;
    }

    private NutritionalValueDTO getNutritionalValuesDTO(List<UserMeal> meals) {
        List<Long> recipeIds = meals.stream()
            .flatMap(userMeal -> userMeal.getRecipes().stream().map(Recipe::getId))
            .collect(Collectors.toList());

        Optional<BasicNutritionalValues> nutritionalValues = nutritionalService.getRecipesBasicNutritionalValues(recipeIds);

        return nutritionalValueMapper.basicNutritionalValueToNutritionalValueDTO(nutritionalValues.get());
    }

}
