package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.WSUserData;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for the WSUserData entity.
 */
public interface WSUserDataRepository extends JpaRepository<WSUserData,Long> {

}
