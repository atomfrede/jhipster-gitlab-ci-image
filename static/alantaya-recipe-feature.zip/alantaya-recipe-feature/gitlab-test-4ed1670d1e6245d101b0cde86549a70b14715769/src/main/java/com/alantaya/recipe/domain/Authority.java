package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * An authority (a security role) used by Spring Security.
 */
@Entity
@Table(name = "T_AUTHORITY")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Authority implements Serializable {

    public static final String USER_NAME = "ROLE_USER";
    public static final String ADMIN_NAME = "ROLE_ADMIN";
    public static final String PRE_PAYMENT_NAME = "ROLE_PRE_PAYMENT";
    public static final String PRO_NAME = "ROLE_PRO";
    public static final String SUPERVISOR_NAME = "ROLE_SUPERVISOR";
    public static final String WS_NAME = "ROLE_WS";

    public static final Authority USER = new Authority(USER_NAME);
    public static final Authority ADMIN = new Authority(ADMIN_NAME);
    public static final Authority PRE_PAYMENT = new Authority(PRE_PAYMENT_NAME);
    public static final Authority PRO = new Authority(PRO_NAME);
    public static final Authority SUPERVISOR = new Authority(SUPERVISOR_NAME);
    public static final Authority WS = new Authority(WS_NAME);

    @NotNull
    @Size(min = 0, max = 50)
    @Id
    @Column(length = 50)
    private String name;

    public Authority() {
    }

    public Authority(String name) {
        super();
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Authority authority = (Authority) o;

        if (name != null ? !name.equals(authority.name) : authority.name != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return name != null ? name.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Authority{" +
                "name='" + name + '\'' +
                "}";
    }
}
