package com.alantaya.recipe.payment.hipay.domain;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import java.util.*;

@JacksonXmlRootElement(localName = "order")
public class Order {

    private Long userAccountId;
    private String currency;
    private Locale locale;
    private String label;
    private String ageGroup;
    private Long categoryId;
    @JacksonXmlElementWrapper(localName = "items") private List<Item> item = new ArrayList<>();
    @JacksonXmlElementWrapper(localName = "affiliates") private List<Affiliate> affiliate = new ArrayList<>();
    @JacksonXmlCData private String urlAcquital;
    @JacksonXmlCData private String urlOk;
    @JacksonXmlCData private String urlKo;
    @JacksonXmlCData private String urlCancel;
    @JacksonXmlCData private String urlInstall;
    @JacksonXmlCData private String urlLogo;
    private String issuerAccountLogin;
    private String reference;
    private boolean manual_capture;
    private Long shopId;
    private Map<String, Object> data = new HashMap<>();

    public Long getUserAccountId() {
        return userAccountId;
    }

    public void setUserAccountId(Long userAccountId) {
        this.userAccountId = userAccountId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Locale getLocale() {
        return locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public List<Item> getItem() {
        return item;
    }

    public void setItem(List<Item> item) {
        this.item = item;
    }

    public List<Affiliate> getAffiliate() {
        return affiliate;
    }

    public void setAffiliate(List<Affiliate> affiliates) {
        this.affiliate = affiliate;
    }

    public String getUrlAcquital() {
        return urlAcquital;
    }

    public void setUrlAcquital(String urlAcquital) {
        this.urlAcquital = urlAcquital;
    }

    public String getUrlOk() {
        return urlOk;
    }

    public void setUrlOk(String urlOk) {
        this.urlOk = urlOk;
    }

    public String getUrlKo() {
        return urlKo;
    }

    public void setUrlKo(String urlKo) {
        this.urlKo = urlKo;
    }

    public String getUrlCancel() {
        return urlCancel;
    }

    public void setUrlCancel(String urlCancel) {
        this.urlCancel = urlCancel;
    }

    public String getUrlInstall() {
        return urlInstall;
    }

    public void setUrlInstall(String urlInstall) {
        this.urlInstall = urlInstall;
    }

    public String getUrlLogo() {
        return urlLogo;
    }

    public void setUrlLogo(String urlLogo) {
        this.urlLogo = urlLogo;
    }

    public String getIssuerAccountLogin() {
        return issuerAccountLogin;
    }

    public void setIssuerAccountLogin(String issuerAccountLogin) {
        this.issuerAccountLogin = issuerAccountLogin;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public int isManual_capture() {
        return manual_capture ? 1 : 0;
    }

    public void setManual_capture(boolean manual_capture) {
        this.manual_capture = manual_capture;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
