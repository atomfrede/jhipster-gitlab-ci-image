package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserSetting;
import com.alantaya.recipe.repository.UserSettingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class SettingService {
    private final Logger log = LoggerFactory.getLogger(SettingService.class);

    @Inject private UserSettingRepository userSettingRepository;

    public void saveSetting(UserSetting setting, User user) {
        UserSetting existingSetting = userSettingRepository.findBySettingKeyAndUser(setting.getSettingKey(), user);
        if (existingSetting != null) {
            existingSetting.setValue(setting.getValue());
            userSettingRepository.save(existingSetting);
        }
        else {
            setting.setUser(user);
            userSettingRepository.save(setting);
        }
    }

    public UserSetting getUserSetting(UserSettingType type, User user) {
        return userSettingRepository.findBySettingKeyAndUser(type.toString(), user);
    }

    public List<UserSetting> getUserSettings(User user) {
        return userSettingRepository.findByUser(user);
    }
}
