package com.alantaya.recipe.domain.util;

import com.alantaya.recipe.domain.Unit;
import com.alantaya.recipe.domain.UnitType;

import java.math.RoundingMode;
import java.text.NumberFormat;

public class UnitUtil {

    private static final double RATIO_GRAMME_LITRE = 1000D;

    private static NumberFormat numberFormat;
    static {
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setRoundingMode(RoundingMode.UP);
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(1);
        numberFormat.setMinimumIntegerDigits(1);
    }

    public static String formatQuantity(Double weight, Double density, Unit unit, Double averagePieceWeight) {
        if (null != averagePieceWeight && null != weight)
            return String.valueOf((int) Math.ceil(weight / averagePieceWeight));
        return formatValue(weight, density, unit);
    }

    public static String formatValue(Double weight, Double density, Unit unit) {

        if (null == weight) return null;
        if (null == unit) return numberFormat.format(weight);

        if (! UnitType.VOLUME_ID.equals(unit.getType().getId())) {
            return numberFormat.format(weight / unit.getRatioToBaseUnit()) + " " + unit.getShortName();
        }

        if (null == density) {
            return numberFormat.format(weight) + " g";
        }

        double value = weight / (RATIO_GRAMME_LITRE * density) / unit.getRatioToBaseUnit();
        return numberFormat.format(value) + " " + unit.getShortName();
    }

}
