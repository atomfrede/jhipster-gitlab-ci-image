package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.EatenDish;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the EatenDish entity.
 */
public interface EatenDishRepository extends JpaRepository<EatenDish,Long> {

    @Query("select eatenDish from EatenDish eatenDish where eatenDish.user.email = ?#{principal.username}")
    List<EatenDish> findAllForCurrentUser();

}
