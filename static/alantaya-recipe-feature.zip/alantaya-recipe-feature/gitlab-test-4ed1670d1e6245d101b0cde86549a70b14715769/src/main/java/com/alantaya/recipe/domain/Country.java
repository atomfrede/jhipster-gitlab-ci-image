package com.alantaya.recipe.domain;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;

/**
 * A Country.
 */
@Entity
@Table(name = "T_COUNTRY")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Country implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Column(name = "code", nullable = false)
    @JsonView(View.Full.class)
    private Integer code;

    @NotNull
    @Size(max = 2)
    @Column(name = "alpha2", length = 2, nullable = false)
    @JsonView(View.Full.class)
    private String alpha2;

    @NotNull
    @Size(max = 3)
    @Column(name = "alpha3", length = 3, nullable = false)
    @JsonView(View.Full.class)
    private String alpha3;

    @NotNull
    @Column(name = "name_en", nullable = false)
    @JsonView(View.Minimal.class)
    private String nameEn;

    @NotNull
    @Column(name = "name_fr", nullable = false)
    @JsonView(View.Minimal.class)
    private String nameFr;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getAlpha2() {
        return alpha2;
    }

    public void setAlpha2(String alpha2) {
        this.alpha2 = alpha2;
    }

    public String getAlpha3() {
        return alpha3;
    }

    public void setAlpha3(String alpha3) {
        this.alpha3 = alpha3;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameFr() {
        return nameFr;
    }

    public void setNameFr(String nameFr) {
        this.nameFr = nameFr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Country country = (Country) o;

        if ( ! Objects.equals(id, country.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Country{" +
                "id=" + id +
                ", code='" + code + "'" +
                ", alpha2='" + alpha2 + "'" +
                ", alpha3='" + alpha3 + "'" +
                ", nameEn='" + nameEn + "'" +
                ", nameFr='" + nameFr + "'" +
                '}';
    }
}
