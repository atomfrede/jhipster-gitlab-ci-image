package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Photographer;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Photographer entity.
 */
public interface PhotographerRepository extends JpaRepository<Photographer,Long> {

}
