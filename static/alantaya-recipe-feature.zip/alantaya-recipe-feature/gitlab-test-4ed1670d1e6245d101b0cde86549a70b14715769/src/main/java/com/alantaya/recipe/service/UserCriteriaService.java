package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.QuestionnaireQuestion;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserQuestionnaireAnswer;
import com.alantaya.recipe.module.ws.service.WSUserCriteriaService;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.repository.QuestionnaireQuestionRepository;
import com.alantaya.recipe.repository.UserRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserCriteriaService {

    private static final Long NO_CRITERIA_ID = 0L;

    @Inject private UserQuestionnaireService userQuestionnaireService;
    @Inject private CriteriaRepository criteriaRepository;
    @Inject private QuestionnaireQuestionRepository questionnaireQuestionRepository;
    @Inject private UserRepository userRepository;
    @Inject private WSUserCriteriaService wsUserCriteriaService;

    public List<Criteria> getAllCriteria(Long userId){
        List<Criteria> allCriteria = new ArrayList<>();
        allCriteria.addAll(getCriteriaFromUserCriteriaList(userId));
        allCriteria.addAll(getCriteriaFromUserQuestionnaireAnswers(userId));
        return allCriteria;
    }

    private List<Criteria> getCriteriaFromUserQuestionnaireAnswers(Long userId) {

        List<UserQuestionnaireAnswer> answers = userQuestionnaireService.getAnswers(userId);
        if (answers.isEmpty()) return Collections.emptyList();

        List<Criteria> criteria = new ArrayList<>();
        for (UserQuestionnaireAnswer answer : answers) {
            QuestionnaireQuestion question = questionnaireQuestionRepository.findOne(answer.getQuestionId());

            if ("true".equals(answer.getStrAnswer()) && null != question.getCriteriaGroup()) {
                criteria.addAll(question.getCriteriaGroup().getCriterias());
            }

            List<Long> criteriaIds = answer.getCriteriaIds().stream()
                .filter(id -> ! NO_CRITERIA_ID.equals(id))
                .collect(Collectors.toList());

            if (! criteriaIds.isEmpty()) {
                criteria.addAll(criteriaRepository.findByIdInWithEagerRelationships(criteriaIds));
            }
        }
        return criteria;
    }

    private List<Criteria> getCriteriaFromUserCriteriaList(Long userId) {
        User user = userRepository.findOne(userId);
        return criteriaRepository.findAll(wsUserCriteriaService.getUserCriteriaIds(user));
    }
}
