package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.module.ws.web.rest.dto.BiometryDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.BiometryMapper;
import com.alantaya.recipe.repository.BiometryRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/ws/v1")
@Api(value = "/biometry")
public class WSBiometryResource {

    private final Logger log = LoggerFactory.getLogger(WSBiometryResource.class);

    @Inject private BiometryMapper biometryMapper;
    @Inject private BiometryRepository biometryRepository;

    @ApiOperation(value = "", notes = "Get all definitions of a <<Biometry>>.")
    @RequestMapping(value = "/biometrics",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional(readOnly = true)
    public List<BiometryDTO> getAllBiometrics() {
        log.debug("REST request to get all biometrics");
        return biometryMapper.biometricsToWSBiometricsDTOV1(biometryRepository.findAll());
    }

    @ApiOperation(value = "", notes = "Get definition of a <<Biometry>> by id.")
    @RequestMapping(value = "/biometrics/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional(readOnly = true)
    public ResponseEntity<BiometryDTO> getBiometryById(@PathVariable Long id) {
        log.debug("REST request to get biometry : {}", id);
        return Optional.ofNullable(biometryRepository.findOne(id))
            .map(biometryMapper::biometryToWSBiometryDTOV1)
            .map(biometryDTO -> new ResponseEntity<>(biometryDTO, HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

}
