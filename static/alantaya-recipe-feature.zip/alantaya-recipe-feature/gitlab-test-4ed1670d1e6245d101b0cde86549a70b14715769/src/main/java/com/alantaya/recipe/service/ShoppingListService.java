package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.*;
import com.alantaya.recipe.domain.util.UnitUtil;
import com.alantaya.recipe.repository.UserMealRepository;
import com.alantaya.recipe.service.dto.ShoppingListEmailDTO;
import com.alantaya.recipe.web.rest.dto.ShoppingListItem;
import com.alantaya.recipe.web.rest.dto.ShoppingListQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ShoppingListService {
    @Inject private UserMealRepository userMealRepository;
    @Inject private MailService mailService;

    @Transactional(readOnly = true)
    public List<ShoppingListItem> getShoppingListForUser(ShoppingListQuery query, User user) {
        List<UserMeal> mealList = userMealRepository.findByUserAndDateBetween(user, query.getStartDate(), query.getEndDate());

        List<ShoppingListItem> shoppingList = new ArrayList<>();
        mealList.stream()
                .map(UserMeal::getRecipes)
                .flatMap(Set::stream)
                .map(Recipe::getFoodQuantities)
                .flatMap(Set::stream)
                .filter(foodQuantity -> foodQuantity.getAmountInGrams() > 0)
                .filter(foodQuantity -> ! Boolean.TRUE.equals(foodQuantity.getFood().getIsHiddenInShoppingList()))
                .collect(Collectors.groupingBy(FoodQuantityByRecipe::getFood))
                .forEach((food, foodQuantities) -> {
                    ShoppingListItem item = new ShoppingListItem(
                            getItemName(food),
                            food.getFoodSection(),
                            foodQuantities.stream()
                                    .mapToDouble(foodQuantity ->
                                        foodQuantity.getAmountInGrams().doubleValue()
                                            / foodQuantity.getRecipe().getSharesNumber().doubleValue())
                                    .sum(),
                        food.getDensity(),
                            food.getFavoriteUnit(),
                            food.getAveragePieceWeight());
                    shoppingList.add(item);
                });

        return mergeItemsByName(shoppingList);
    }

    private static String getItemName(Food food) {
        if (food.getPieceName() != null) return food.getPieceName();
        return food.getName();
    }

    private static List<ShoppingListItem> mergeItemsByName(List<ShoppingListItem> items) {
        List<ShoppingListItem> mergedItems = new ArrayList<>();
        items.stream().collect(Collectors.groupingBy(ShoppingListItem::getName))
                .forEach((name, itemsToMerge) -> {
                    ShoppingListItem item =  itemsToMerge.get(0);
                    item.setQuantity(itemsToMerge.stream().mapToDouble(ShoppingListItem::getQuantity).sum());
                    mergedItems.add(item);
                });
        return mergedItems;
    }

    @Transactional(readOnly = true)
    public void sendShoppingListByMail(ShoppingListQuery query, User user) {
        final List<ShoppingListItem> shoppingListItems = getShoppingListForUser(query, user);

        final Map<String, List<ShoppingListEmailDTO.FoodDTO>> shoppingListEmail = shoppingListItems.stream()
            .map(item -> this.createFoodDto(item))
            .filter(Objects::nonNull)
            .collect(Collectors.toMap(
                ShoppingListEmailDTO.FoodDTO::getFoodSection,
                Collections::singletonList,
                (List<ShoppingListEmailDTO.FoodDTO> oldList, List<ShoppingListEmailDTO.FoodDTO> newEl) -> {
                    List<ShoppingListEmailDTO.FoodDTO> newList = new ArrayList<>(oldList.size() + 1);
                    newList.addAll(oldList);
                    newList.addAll(newEl);
                    return newList;
                })
            );

        final ShoppingListEmailDTO shoppingListEmailDTO = new ShoppingListEmailDTO(
            query.getStartDate(),
            query.getEndDate(),
            shoppingListEmail
        );
        mailService.sendShoppingList(user, shoppingListEmailDTO);
    }

    private ShoppingListEmailDTO.FoodDTO createFoodDto(ShoppingListItem shoppingListItem) {
        final ShoppingListEmailDTO.FoodDTO shoppingListFood = new ShoppingListEmailDTO.FoodDTO();
        shoppingListFood.setName(shoppingListItem.getName());
        if (null != shoppingListItem.getFoodSection())
            shoppingListFood.setFoodSection(shoppingListItem.getFoodSection().getName());

        shoppingListFood.setQuantity(
            UnitUtil.formatQuantity(
                shoppingListItem.getQuantity(),
                shoppingListItem.getDensity(),
                shoppingListItem.getUnit(),
                shoppingListItem.getAveragePieceWeight()
            )
        );
        return shoppingListFood;
    }
}
