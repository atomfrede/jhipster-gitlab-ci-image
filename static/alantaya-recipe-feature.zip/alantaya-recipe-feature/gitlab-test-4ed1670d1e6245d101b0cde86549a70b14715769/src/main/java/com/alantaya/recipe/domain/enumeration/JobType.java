package com.alantaya.recipe.domain.enumeration;

/**
 * The JobType enumeration.
 */
public enum JobType {
    PRIVATE, LIBERAL
}
