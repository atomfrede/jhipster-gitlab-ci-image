package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A EatenDish.
 */
@Entity
@Table(name = "EATEN_DISH")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EatenDish implements Serializable {

    private final static Long EATEN_DISH_NOTHING_ID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 150)
    @Column(name = "title", length = 150, nullable = false)
    private String title;

    @ManyToOne
    private RecipeType type;

    @ManyToOne
    private User user;

    @OneToMany(mappedBy = "eatenDish", cascade = CascadeType.ALL, orphanRemoval=true)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<FoodQuantityByEatenDish> foodQuantities = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public RecipeType getType() {
        return type;
    }

    public void setType(RecipeType recipeType) {
        this.type = recipeType;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Set<FoodQuantityByEatenDish> getFoodQuantities() {
        return foodQuantities;
    }

    public void setFoodQuantities(Set<FoodQuantityByEatenDish> foodQuantities) {
        this.foodQuantities = foodQuantities;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        EatenDish eatenDish = (EatenDish) o;

        if ( ! Objects.equals(id, eatenDish.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "EatenDish{" +
                "id=" + id +
                ", title='" + title + "'" +
                '}';
    }
}
