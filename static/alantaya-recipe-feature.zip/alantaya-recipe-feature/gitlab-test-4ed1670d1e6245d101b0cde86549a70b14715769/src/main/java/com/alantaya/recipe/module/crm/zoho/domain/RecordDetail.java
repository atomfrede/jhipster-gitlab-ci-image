package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
public class RecordDetail {

    private Field id;

    private Field createdBy;

    private Field modifiedBy;

    private Field createdTime;

    private Field modifiedTime;

    public Field getId() {
        return id;
    }

    @XmlTransient
    public void setId(String id) {
        this.id = new Field("Id");
        this.id.setValue(id);
    }

    public Field getCreatedBy() {
        return createdBy;
    }

    @XmlTransient
    public void setCreatedBy(String createdBy) {
        this.createdBy = new Field("Created By");
        this.createdBy.setValue(createdBy);
    }

    public Field getModifiedBy() {
        return modifiedBy;
    }

    @XmlTransient
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = new Field("Modified By");
        this.modifiedBy.setValue(modifiedBy);
    }

    public Field getCreatedTime() {
        return createdTime;
    }

    @XmlTransient
    public void setCreatedTime(String createdTime) {
        this.createdTime = new Field("Created Time");
        this.createdTime.setValue(createdTime);
    }

    public Field getModifiedTime() {
        return modifiedTime;
    }

    @XmlTransient
    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = new Field("Modified Time");
        this.modifiedTime.setValue(modifiedTime);
    }


}
