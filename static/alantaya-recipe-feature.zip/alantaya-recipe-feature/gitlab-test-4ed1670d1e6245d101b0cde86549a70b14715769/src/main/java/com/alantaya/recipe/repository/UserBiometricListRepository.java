package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserBiometricList;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data JPA repository for the UserBiometricList entity.
 */
public interface UserBiometricListRepository extends JpaRepository<UserBiometricList,Long> {

    UserBiometricList findByUserId(Long userId);

}
