package com.alantaya.recipe.domain;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.joda.ser.DateTimeSerializer;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

public class UserQuestionnaireAnswer {

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = DateTimeSerializer.class)
    private DateTime createdDate = DateTime.now();

    private String strAnswer;

    @NotNull
    private Long questionId;

    private List<Long> criteriaIds = new ArrayList<>();

    public DateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public String getStrAnswer() {
        return strAnswer;
    }

    public void setStrAnswer(String strAnswer) {
        this.strAnswer = strAnswer;
    }

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    public List<Long> getCriteriaIds() {
        return criteriaIds;
    }

    public void setCriteriaIds(List<Long> criteriaIds) {
        this.criteriaIds = criteriaIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserQuestionnaireAnswer that = (UserQuestionnaireAnswer) o;

        if (createdDate != null ? !createdDate.equals(that.createdDate) : that.createdDate != null) return false;
        if (strAnswer != null ? !strAnswer.equals(that.strAnswer) : that.strAnswer != null) return false;
        if (questionId != null ? !questionId.equals(that.questionId) : that.questionId != null) return false;
        return !(criteriaIds != null ? !criteriaIds.equals(that.criteriaIds) : that.criteriaIds != null);

    }

    @Override
    public int hashCode() {
        int result = createdDate != null ? createdDate.hashCode() : 0;
        result = 31 * result + (strAnswer != null ? strAnswer.hashCode() : 0);
        result = 31 * result + (questionId != null ? questionId.hashCode() : 0);
        result = 31 * result + (criteriaIds != null ? criteriaIds.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UserQuestionnaireAnswer{" +
            "createdDate=" + createdDate +
            ", strAnswer='" + strAnswer + '\'' +
            ", questionId=" + questionId +
            ", criteriaIds=" + criteriaIds +
            '}';
    }
}
