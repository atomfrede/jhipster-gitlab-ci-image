package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.domain.NutrimentFamily;
import org.joda.time.DateTime;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DieteticNutriment extends Nutriment implements DieteticElement, DieteticStatistic {
    private final Nutriment nutriment;
    private final DieteticNutrimentFamily dieteticNutrimentFamily;

    public DieteticNutriment(Nutriment nutriment) {
        this.nutriment = nutriment;
        NutrimentFamily nutrimentFamily = nutriment.getNutrimentFamily();
        this.dieteticNutrimentFamily = null != nutrimentFamily ? new DieteticNutrimentFamily(nutrimentFamily) : null;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        double quantity = this.equals(dieteticElement) ? 1D : 0D;
        if (null != dieteticNutrimentFamily)
            quantity += dieteticNutrimentFamily.getQuantityFor(dieteticElement);
        return quantity;
    }

    @Override
    public DieteticElement getMacro() {
        return dieteticNutrimentFamily;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public Long getId() {
        return nutriment.getId();
    }

    @Override
    public void setId(Long id) {
        nutriment.setId(id);
    }

    @Override
    public String getName() {
        return nutriment.getName();
    }

    @Override
    public void setName(String name) {
        nutriment.setName(name);
    }

    @Override
    public NutrimentFamily getNutrimentFamily() {
        return nutriment.getNutrimentFamily();
    }

    @Override
    public void setNutrimentFamily(NutrimentFamily nutrimentFamily) {
        nutriment.setNutrimentFamily(nutrimentFamily);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticNutriment dieteticNutriment = (DieteticNutriment) o;

        return nutriment.equals(dieteticNutriment.nutriment);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), nutriment.getId());
    }

    @Override
    public String getCreatedBy() {
        return nutriment.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        nutriment.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return nutriment.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        nutriment.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return nutriment.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        nutriment.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return nutriment.getLastModifiedDate();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        nutriment.setLastModifiedDate(lastModifiedDate);
    }

    @Override
    public String toString() {
        return "DieteticNutriment{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
