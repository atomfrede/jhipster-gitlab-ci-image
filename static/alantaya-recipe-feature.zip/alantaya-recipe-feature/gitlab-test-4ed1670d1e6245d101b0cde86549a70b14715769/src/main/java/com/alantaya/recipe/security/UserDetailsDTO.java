package com.alantaya.recipe.security;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public class UserDetailsDTO extends org.springframework.security.core.userdetails.User {

    private boolean isOTPAuthenticated;

    public UserDetailsDTO(String email,
                          String password,
                          boolean enabled,
                          Collection<? extends GrantedAuthority> authorities) {
        super(email, password, enabled, true, true, true, authorities);
        isOTPAuthenticated = false;
    }

    public boolean isOTPAuthenticated() {
        return isOTPAuthenticated;
    }

    public void setIsAuthenticated(boolean isAuthenticated) {
        this.isOTPAuthenticated = isAuthenticated;
    }
}
