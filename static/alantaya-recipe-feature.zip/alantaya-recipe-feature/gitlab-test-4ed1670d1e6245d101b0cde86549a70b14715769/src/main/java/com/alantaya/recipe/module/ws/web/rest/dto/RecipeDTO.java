package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(value="Recipe",
    description = "The recipe contains the list of <<Food>> and the <<NutritionalValue>> for one person of the recipe.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"title\": \"Aile de raie au beurre noir\",\n" +
        "    \"summary\": \"\",\n" +
        "    \"sharesNumber\": 4,\n" +
        "    \"quantityUnit\": \"Personnes\",\n" +
        "    \"cookingTime\": 10,\n" +
        "    \"restTime\": 15,\n" +
        "    \"betterPreparedInAdvance\": false,\n" +
        "    \"advice\": \"\",\n" +
        "    \"sourceUrl\": \"\",\n" +
        "    \"type\": \"Dessert\",\n" +
        "    \"categories\": [],\n" +
        "    \"costLevel\": 1,\n" +
        "    \"difficultyLevel\": 2,\n" +
        "    \"seasons\": \"Toute saison\",\n" +
        "    \"originCountry\": \"\",\n" +
        "    \"originRegion\": \"\",\n" +
        "    \"themes\": [\"Fêtes des mères, Fêtes des pères\", \"Week-end à la campagne\"],\n" +
        "    \"profile\": [\"Débutant chic\"],\n" +
        "    \"author\": \"\",\n" +
        "    \"editor\": \"\",\n" +
        "    \"ingredients\": [...],\n" +
        "    \"steps\": [...],\n" +
        "    \"nutritionalValue\": {...}\n" +
        "}\n" +
        "----"
)
public class RecipeDTO {
    @ApiModelProperty(position = 0, required = true)
    private String title;

    @ApiModelProperty(value = "less than 150 words", position = 1, required = false)
    private String summary;

    @ApiModelProperty(value = "number of people or piece @see quantityUnit", position = 2, required = true)
    private Integer sharesNumber;

    @ApiModelProperty(value = "ex: piece or people, use to define sharesNumber", position = 3, required = true)
    private String quantityUnit;

    @ApiModelProperty(value = "in minutes", position = 4, required = true)
    private Integer cookingTime;

    @ApiModelProperty(value = "in minutes", position = 5, required = true)
    private Integer restTime;

    @ApiModelProperty(position = 6, required = true)
    private Boolean betterPreparedInAdvance;

    @ApiModelProperty(position = 7, required = false)
    private String advice;

    @ApiModelProperty(value = "link to the original recipe, if exist", position = 8, required = false)
    private String sourceUrl;

    @ApiModelProperty(value = "ex: starter, desert, beverage...", position = 9, required = true)
    private String type;

    @ApiModelProperty(value = "ex: salad, soup, vegetarian...", position = 10, required = false)
    private List<String> categories;

    @ApiModelProperty(value = "between 1-3, 1 being the cheapest", allowableValues = "range[1, 3]", position = 11, required = true)
    private Integer costLevel;

    @ApiModelProperty(value = "between 1-4, 1 being the easiest", allowableValues = "range[1, 4]", position = 12, required = true)
    private Integer difficultyLevel;

    @ApiModelProperty(allowableValues = "Printemps, Été, Automne, Hiver, Toute saison", position = 12, required = true)
    private String seasons;

    @ApiModelProperty(position = 13, required = false)
    private String originCountry;

    @ApiModelProperty(value = "provided only for french region", position = 14, required = false)
    private String originRegion;

    @ApiModelProperty(value = "ex: brunch, finger food, christmas...", position = 15, required = false)
    private List<String> themes;

    @ApiModelProperty(value = "ex: pressed, single, chic newbie...", position = 16, required = false)
    private List<String> recipeProfiles;

    @ApiModelProperty(position = 17, required = false)
    private String author;

    @ApiModelProperty(position = 18, required = false)
    private String editor;

    @ApiModelProperty(position = 19, required = true)
    private List<FoodDTO> ingredients;

    @ApiModelProperty(position = 20, required = true)
    private List<RecipeStepDTO> steps;

    @ApiModelProperty(value = "nutritional intake on the recipe for one person", position = 21, required = true)
    private NutritionalValueDTO nutritionalValue;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Integer getSharesNumber() {
        return sharesNumber;
    }

    public void setSharesNumber(Integer sharesNumber) {
        this.sharesNumber = sharesNumber;
    }

    public String getQuantityUnit() {
        return quantityUnit;
    }

    public void setQuantityUnit(String quantityUnit) {
        this.quantityUnit = quantityUnit;
    }

    public Integer getCookingTime() {
        return cookingTime;
    }

    public void setCookingTime(Integer cookingTime) {
        this.cookingTime = cookingTime;
    }

    public Integer getRestTime() {
        return restTime;
    }

    public void setRestTime(Integer restTime) {
        this.restTime = restTime;
    }

    public Boolean getBetterPreparedInAdvance() {
        return betterPreparedInAdvance;
    }

    public void setBetterPreparedInAdvance(Boolean betterPreparedInAdvance) {
        this.betterPreparedInAdvance = betterPreparedInAdvance;
    }

    public String getAdvice() {
        return advice;
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        this.categories = categories;
    }

    public Integer getCostLevel() {
        return costLevel;
    }

    public void setCostLevel(Integer costLevel) {
        this.costLevel = costLevel;
    }

    public Integer getDifficultyLevel() {
        return difficultyLevel;
    }

    public void setDifficultyLevel(Integer difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    public String getSeasons() {
        return seasons;
    }

    public void setSeasons(String seasons) {
        this.seasons = seasons;
    }

    public String getOriginCountry() {
        return originCountry;
    }

    public void setOriginCountry(String originCountry) {
        this.originCountry = originCountry;
    }

    public String getOriginRegion() {
        return originRegion;
    }

    public void setOriginRegion(String originRegion) {
        this.originRegion = originRegion;
    }

    public List<String> getThemes() {
        return themes;
    }

    public void setThemes(List<String> themes) {
        this.themes = themes;
    }

    public List<String> getRecipeProfiles() {
        return recipeProfiles;
    }

    public void setRecipeProfiles(List<String> recipeProfiles) {
        this.recipeProfiles = recipeProfiles;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public List<FoodDTO> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<FoodDTO> ingredients) {
        this.ingredients = ingredients;
    }

    public List<RecipeStepDTO> getSteps() {
        return steps;
    }

    public void setSteps(List<RecipeStepDTO> steps) {
        this.steps = steps;
    }

    public NutritionalValueDTO getNutritionalValue() {
        return nutritionalValue;
    }

    public void setNutritionalValue(NutritionalValueDTO nutritionalValue) {
        this.nutritionalValue = nutritionalValue;
    }

    @Override
    public String toString() {
        return "RecipeDTO{" +
            "title='" + title + '\'' +
            ", summary='" + summary + '\'' +
            ", sharesNumber=" + sharesNumber +
            ", quantityUnit='" + quantityUnit + '\'' +
            ", cookingTime=" + cookingTime +
            ", restTime=" + restTime +
            ", betterPreparedInAdvance=" + betterPreparedInAdvance +
            ", advice='" + advice + '\'' +
            ", sourceUrl=" + sourceUrl +
            ", type=" + type +
            ", categories=" + categories +
            ", costLevel=" + costLevel +
            ", difficultyLevel=" + difficultyLevel +
            ", seasons='" + seasons + '\'' +
            ", originCountry='" + originCountry + '\'' +
            ", originRegion='" + originRegion + '\'' +
            ", themes=" + themes +
            ", recipeProfiles=" + recipeProfiles +
            ", author='" + author + '\'' +
            ", editor='" + editor + '\'' +
            ", ingredients=" + ingredients +
            ", steps=" + steps +
            ", nutritionalValue=" + nutritionalValue +
            '}';
    }
}
