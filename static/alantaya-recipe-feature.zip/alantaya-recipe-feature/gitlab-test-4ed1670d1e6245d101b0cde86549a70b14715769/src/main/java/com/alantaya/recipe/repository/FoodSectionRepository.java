package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.FoodSection;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the FoodSection entity.
 */
public interface FoodSectionRepository extends JpaRepository<FoodSection,Long> {

}
