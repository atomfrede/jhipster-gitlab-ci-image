package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@XmlRootElement
public class Contacts {

    @XmlElement(name = "row")
    @XmlJavaTypeAdapter(ContactXMLAdapter.class)
    private List<Contact> contacts = new ArrayList<>();

    public Contacts() {}
    public Contacts(Collection<Contact> contacts) {
        contacts.forEach(this::add);
    }

    public Contacts add(Contact contact) {
        contact.setNo(contacts.size() + 1);
        contacts.add(contact);
        return this;
    }

    public List<Contact> getContacts() {
        return contacts;
    }
  }
