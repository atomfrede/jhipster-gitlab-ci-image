package com.alantaya.recipe.config.oauth;

import java.util.HashMap;
import java.util.Map;

public class InMemoryTokenStore {

    private final static Map<Long, OAuthRequestToken> tokenStore = new HashMap<>();

    public void store(Long providerUserId, OAuthRequestToken requestToken) {
        tokenStore.put(providerUserId, requestToken);
    }

    public OAuthRequestToken retrieveToken(Long providerUserId) {
        return tokenStore.get(providerUserId);
    }

    public void removeRequestToken(Long providerUserId) {
        tokenStore.remove(providerUserId);
    }

}
