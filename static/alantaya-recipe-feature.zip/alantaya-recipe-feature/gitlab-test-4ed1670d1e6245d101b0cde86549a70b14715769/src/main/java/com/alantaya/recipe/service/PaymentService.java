package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.SubscriptionPackage;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserSubscriptionPayment;
import com.alantaya.recipe.payment.hipay.domain.*;
import com.alantaya.recipe.payment.hipay.service.HipayPaymentButtonService;
import com.alantaya.recipe.repository.SubscriptionPackageRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.dto.SubscriptionPackageMailDTO;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Service
public class PaymentService {

    private final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private static final String KEY_PREFIX = "_aKey_";
    private static final String USER_ID = "userId";
    private static final String PACKAGE_ID = "packageId";

    @Inject private UserRepository userRepository;
    @Inject private UserService userService;
    @Inject private UserSubscriptionPaymentService userSubscriptionPaymentService;
    @Inject private SubscriptionPackageRepository subscriptionPackageRepository;
    @Inject private HipayPaymentButtonService hipayPaymentButtonService;
    @Inject private SubscriptionPackageService subscriptionPackageService;
    @Inject private MailService mailService;
    @Inject private Environment env;

    public Optional<PaymentButton> getPaymentButton(Long subscriptionPackageId, User user) {
        if (user == null || subscriptionPackageId == null) {
            log.error("Missing parameters: CurrentUser -> {}, subscriptionPackageId -> {}", user, subscriptionPackageId);
            return Optional.empty();
        }
        final SubscriptionPackage subscriptionPackage = subscriptionPackageRepository.findOne(subscriptionPackageId);
        if (subscriptionPackage == null) {
            log.error("SubscriptionPackage not found: CurrentUser -> {}, subscriptionPackage -> {}", user, subscriptionPackage);
            return Optional.empty();
        }
        return Optional.of(getPaymentButton(subscriptionPackage, user));
    }

    public PaymentButton getPaymentButton(SubscriptionPackage subscriptionPackage, User user) {
        Order order = createOrder(subscriptionPackage, user);
        try {
            return hipayPaymentButtonService.createMD5SignedPaymentButton(order);
        }
        catch (IOException ioe) {
            throw new RuntimeException(ioe);
        }
    }

    @Transactional
    public boolean updateUserToFreeTrySubscription(User user) {
        if (user == null) {
            log.error("Missing parameter: CurrentUser -> {}", user);
            return false;
        }
        if (userSubscriptionPaymentService.hasAlreadyUsedFreeTryPackage(user)) {
            log.error("User has already subscribe to free try package: CurrentUser -> {}", user);
            return false;
        }
        final SubscriptionPackage freeTrySubscriptionPackage = subscriptionPackageRepository.findOne(SubscriptionPackage.FREE_TRY_ID);
        updateUserSubscription(freeTrySubscriptionPackage, user);
        return true;
    }

    public boolean doesNotificationMatchMD5(String xmlNotification, PaymentNotification notification) {
        int resultStart = xmlNotification.indexOf("<result>");
        int resultEnd = xmlNotification.indexOf("</mapi>");
        String result = xmlNotification.substring(resultStart, resultEnd);
        String md5Content = new Md5PasswordEncoder().encodePassword(result, null);
        return md5Content.equals(notification.getMd5content());
    }

    @Transactional
    public void processNotification(PaymentNotification notification) {
        PaymentNotificationResult notifResult = notification.getResult();

        if (isNotificationInvalid(notifResult)) return;
        Long userId = Long.valueOf(notifResult.getMerchantDatas().get(KEY_PREFIX + USER_ID));
        Long packageId = Long.valueOf(notifResult.getMerchantDatas().get(KEY_PREFIX + PACKAGE_ID));

        SubscriptionPackage subscriptionPackage = subscriptionPackageRepository.findOne(packageId);
        if (isSubscriptionPackageInvalid(notifResult, subscriptionPackage)) return;

        User user = userRepository.findOne(userId);
        if (isUserInvalid(notifResult, user)) return;

        updateUserSubscription(subscriptionPackage, user);
    }

    private boolean isNotificationInvalid(PaymentNotificationResult notifResult) {
        if (! "ok".equals(notifResult.getStatus())) {
            log.error("Payment notification KO, transactionId: {}", notifResult.getTransid());
            return true;
        }

        if (! "capture".equals(notifResult.getOperation())) {
            log.warn("Payment notification operation not capture, transactionId: {}", notifResult.getTransid());
            return true;
        }

        if (null == notifResult.getMerchantDatas().get(KEY_PREFIX + USER_ID)) {
            log.warn("Payment notification without userId, transactionId: {}", notifResult.getTransid());
            return true;
        }

        if (null == notifResult.getMerchantDatas().get(KEY_PREFIX + PACKAGE_ID)) {
            log.warn("Payment notification without packageId, transactionId: {}", notifResult.getTransid());
            return true;
        }
        if (! "EUR".equals(notifResult.getOrigCurrency())) {
            log.error("Payment notification currency is not EUR, transactionId: {}", notifResult.getTransid());
            return true;
        }
        return false;
    }

    private boolean isSubscriptionPackageInvalid(PaymentNotificationResult notifResult, SubscriptionPackage subscriptionPackage) {
        if (subscriptionPackageService.isNotValid(subscriptionPackage)) {
            return true;
        }
        if (! subscriptionPackage.getPrice().equals(notifResult.getOrigAmount())) {
            log.error("Payment has not package price, transactionId: {}", notifResult.getTransid());
            return true;
        }
        return false;
    }

    private boolean isUserInvalid(PaymentNotificationResult notifResult, User user) {
        if (!user.isActive()) {
            log.error("Payment from unactivated user, transactionId: {}", notifResult.getTransid());
            return true;
        }
        return false;
    }

    private void updateUserSubscription(SubscriptionPackage subscriptionPackage, User user) {
        user.getAuthorities().remove(new Authority(AuthoritiesConstants.PRE_PAYMENT));
        user.getAuthorities().add(new Authority(AuthoritiesConstants.USER));
        user.setSubscriptionPackage(subscriptionPackage);
        DateTime expirationDate = DateTime.now().plusMonths(subscriptionPackage.getDurationInMonth());
        user.setSubscriptionExpirationDate(expirationDate);
        log.info("user -> {}, subscribe -> {}", user.getId(), subscriptionPackage.getName());
        mailService.sendSubscriptionConfirmation(user, new SubscriptionPackageMailDTO(subscriptionPackage, LocalDate.now()));
        userSubscriptionPaymentService.registerSubscriptionPayment(user, subscriptionPackage);
        userRepository.save(user);
    }


    private Order createOrder(SubscriptionPackage subscriptionPackage, User user) {
        Order order = new Order();
        order.setUserAccountId(env.getProperty("payment.hipay.userAccountId", Long.class));
        order.setCurrency("EUR");
        order.setLabel(env.getProperty("payment.hipay.label"));
        order.setAgeGroup(AgeGroup.ALL);
        order.setCategoryId(env.getProperty("payment.hipay.categoryId", Long.class));
        order.setUrlAcquital(env.getProperty("payment.hipay.urlAcquital"));
        order.setUrlOk(env.getProperty("payment.hipay.urlOk"));
        order.setUrlKo(env.getProperty("payment.hipay.urlKo"));
        order.setUrlCancel(env.getProperty("payment.hipay.urlCancel"));
        order.setUrlInstall(env.getProperty("payment.hipay.urlInstall"));
        order.setUrlLogo(env.getProperty("payment.hipay.urlLogo"));
        order.setIssuerAccountLogin(user.getEmail());

        order.setLocale(Locale.FRANCE);
        order.getData().put(USER_ID, user.getId());
        order.getData().put(PACKAGE_ID, subscriptionPackage.getId());

        Item item = new Item();
        item.setId(1L);
        item.setAmount(subscriptionPackage.getPrice());
        item.setCategoryId(env.getProperty("payment.hipay.categoryId", Long.class));
        item.setInfos(subscriptionPackage.getDescription());
        item.setName(subscriptionPackage.getName());
        item.setQuantity(1L);
        order.getItem().add(item);

        return order;
    }

    @Scheduled(cron="0 1 1 * * ?")
    @Transactional
    public void processSubscriptionExpiredUsers() {
        List<User> expiredUsers
            = userRepository.findBySubscriptionExpirationDateBeforeAndAuthorities(DateTime.now(), Authority.USER);
        expiredUsers.stream()
            .forEach(this::updateSubscriptionExpiredUser);
    }

    private void updateSubscriptionExpiredUser(User user) {
        if (! isSimpleUser(user)) return;
        user.getAuthorities().remove(Authority.USER);
        user.getAuthorities().add(Authority.PRE_PAYMENT);
    }

    @Scheduled(cron="0 1 1 * * ?")
    @Transactional
    public void sendExpirationMailWarning() {
        List<User> userExpiredInNext24Hours
            = userRepository.findBySubscriptionExpirationDateBetweenAndAuthorities(
            DateTime.now().plusDays(1).withTimeAtStartOfDay(),
            DateTime.now().plusDays(2).withTimeAtStartOfDay(),
            Authority.USER
        );

        userExpiredInNext24Hours.forEach(this::sendExpirationMailWarning);

        List<User> userExpiredIn7Days
            = userRepository.findBySubscriptionExpirationDateBetweenAndAuthorities(
            DateTime.now().plusDays(7).withTimeAtStartOfDay(),
            DateTime.now().plusDays(8).withTimeAtStartOfDay(),
            Authority.USER
        );

        userExpiredIn7Days.forEach(this::sendExpirationMailWarning);
    }

    private void sendExpirationMailWarning(User user) {
        if (! isSimpleUser(user)) return;
        UserSubscriptionPayment payment = userSubscriptionPaymentService.getLastSubscriptionPayment(user);
        mailService.sendSubscriptionExpirationWarning(
            user,
            new SubscriptionPackageMailDTO(user.getSubscriptionPackage(), payment.getPaymentDate().toLocalDate())
        );
    }

    private boolean isSimpleUser(User user) {
        return user.getAuthorities().contains(Authority.USER)
            && user.getAuthorities().size() == 1;
    }
}
