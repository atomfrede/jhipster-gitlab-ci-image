package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.module.ws.web.rest.dto.UserBiometricDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {})
public interface UserBiometryMapper {

    UserBiometricDTO userBiometryToUserBiometricDTO(UserBiometricValue biometricValue);
    List<UserBiometricDTO> userBiometricsToUserBiometricDTOs(Collection<UserBiometricValue> biometricValues);

    @Mapping(target = "biometricValueSource", ignore = true)
    UserBiometricValue userBiometricDTOToUserBiometric(UserBiometricDTO biometricValue);
    List<UserBiometricValue> userBiometricDTOsToUserBiometrics(Collection<UserBiometricDTO> biometricValues);
}
