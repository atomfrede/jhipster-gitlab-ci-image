package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticMenuPattern;
import com.alantaya.recipe.dietetic.service.AlgorithmService;
import com.alantaya.recipe.dietetic.service.DieteticConstraintService;
import com.alantaya.recipe.domain.*;
import com.alantaya.recipe.repository.UserMealRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.service.dto.MealPlanning;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class MealPlanningGenerationService {
    private final Logger log = LoggerFactory.getLogger(MealPlanningGenerationService.class);

    @Inject private AlgorithmService algorithmService;
    @Inject private UserService userService;
    @Inject private UserCriteriaService userCriteriaService;
    @Inject private DieteticUtilService dieteticUtilService;
    @Inject private BiometricService biometricService;
    @Inject private DieteticConstraintService dieteticConstraintService;
    @Inject private UserMealService userMealService;

    @Inject private UserMealRepository userMealRepository;
    @Inject private MenuPatternFactory menuPatternFactory;
    @Inject private UserRepository userRepository;

    @Transactional
    @Async(value = "mealGeneration")
    public void generateAndSaveWeeklyMealPlanning(Long userId) {
        User user = userRepository.findOne(userId);
        if (dieteticUtilService.isUserDieteticValid(user)) {
            log.debug("Generation des menus pour l'utilisateur {}", user);
            userService.setUserGenerationInProgress(user, true);
            final Optional<MealPlanning> mealPlanning = generateWeeklyMealPlanning(user);
            mealPlanning.ifPresent(userMealPlanning -> userMealService.save(userMealPlanning.getMeals()));
            userService.setUserGenerationInProgress(user, false);
        }
        else {
            log.debug("Aucune géneration de menu pour l'utilisateur {} car l'utilisateur n'est pas dietetiquement valide", user);
        }
    }

    private Optional<MealPlanning> generateWeeklyMealPlanning(User user) {
        final LocalDate lastDayOfMeal = getLastDayOfMeal(user);

        if (lastDayOfMeal.isAfter(LocalDate.now().plusDays(6))) return Optional.empty();

        final MealPlanning mealPlanning = generateMealPlanning(user,
            lastDayOfMeal,
            LocalDate.now().plusDays(7));
        return Optional.of(mealPlanning);
    }

    public MealPlanning generateMealPlanning(User user,
                                             LocalDate startDate,
                                             LocalDate endDate)
    {
        final List<DieteticConstraint> computedConstraints = getComputedConstraints(user);
        final DieteticMenuPattern menuPattern = menuPatternFactory.getUserMenuPattern(user);

        final MealPlanning mealPlanning = algorithmService.generateMealPlanning(
            computedConstraints,
            menuPattern,
            startDate,
            endDate);

        mealPlanning.getMeals().forEach(meal -> meal.setUser(user));

        return mealPlanning;
    }

    public List<DieteticConstraint> getComputedConstraints(User user) {
        final List<Criteria> criterias = userCriteriaService.getAllCriteria(user.getId());
        final Map<Long, UserBiometricValue> biometricValuesByBiometricId = biometricService.getLatestBiometricValueByBiometricId(user);

        return dieteticConstraintService.getDieteticConstraints(
            criterias,
            biometricValuesByBiometricId,
            user.getDislikedFoods()
        );
    }

    public List<Recipe> getAlternativeRecipeList(User user,
                                                 UserMeal mealToChange,
                                                 Long recipeTypeIdToChange,
                                                 int numberOfAlternativeRecipeAsked) {
        Optional<RecipeType> recipeType = mealToChange.getRecipes().stream()
            .filter(recipe -> recipe.getType().getId().equals(recipeTypeIdToChange))
            .map(Recipe::getType).findFirst();
        if (! recipeType.isPresent()) return Collections.emptyList();

        DieteticMenuPattern menuPattern = new DieteticMenuPattern(
            Collections.singletonList(mealToChange.getMealType().getId()),
            Collections.singletonList(recipeType.get().getId()));
        final List<DieteticConstraint> computedConstraints = getComputedConstraints(user);

        List<UserMeal> actualMeals = userMealRepository.findByUserAndDateBetween(user, mealToChange.getDate(), mealToChange.getDate());

        return algorithmService.getAlternativeRecipeList(
            menuPattern,
            computedConstraints,
            actualMeals,
            mealToChange,
            recipeTypeIdToChange,
            numberOfAlternativeRecipeAsked);
    }

    private LocalDate getLastDayOfMeal(User user) {
        final List<UserMeal> meals = userMealRepository.findByUserAndDateBetween(user, LocalDate.now(), LocalDate.now().plusDays(10));
        return meals.stream()
            .map(UserMeal::getDate)
            .max(LocalDate::compareTo)
            .orElse(LocalDate.now());
    }
}
