package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.FoodState;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the FoodState entity.
 */
public interface FoodStateRepository extends JpaRepository<FoodState,Long> {

}
