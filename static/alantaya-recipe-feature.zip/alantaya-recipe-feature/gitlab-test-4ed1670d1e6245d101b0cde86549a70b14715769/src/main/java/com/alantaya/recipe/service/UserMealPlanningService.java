package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.RecipeType;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.repository.UserMealRepository;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserMealPlanningService {
    private final Logger log = LoggerFactory.getLogger(UserMealPlanningService.class);

    @Inject private UserService userService;
    @Inject private UserMealService userMealService;
    @Inject private MealPlanningGenerationService mealPlanningGenerationService;
    @Inject private UserMealRepository userMealRepository;
    @Inject private RecipeRepository recipeRepository;

    @Transactional(readOnly = true)
    public List<Recipe> getAlternativeToMeal(Long mealId, Long recipeTypeId) {
        User user = userService.getUser();
        UserMeal meal = userMealRepository.getOne(mealId);
        List<Recipe> recipes = mealPlanningGenerationService.getAlternativeRecipeList(user, meal, recipeTypeId, 4);
        if (recipes.isEmpty()) return Collections.emptyList();
        List<Long> recipeIds = recipes.stream().map(Recipe::getId).collect(Collectors.toList());
        return recipeRepository.findByIdInWithEagerRelationships(recipeIds);
    }

    @Transactional
    public void changeRecipeInMeal(Long mealId, Long recipeId) {
        User user = userService.getUser();
        UserMeal meal = userMealRepository.findOne(mealId);
        if (meal == null) {
            log.error("No UserMeal found: mealId -> {}", mealId);
            return;
        }
        else if (!user.equals(meal.getUser())) {
            log.error("User different: currentUser -> {}, meal -> {}", user, meal);
            return;
        }

        Recipe newRecipe = recipeRepository.findOne(recipeId);
        if(newRecipe == null) {
            log.error("No recipe found recipeToFindId -> {}, meal -> {}", recipeId, meal);
            return;
        }

        final Set<Recipe> mealRecipes = meal.getRecipes();
        final Recipe recipeToDelete = findRecipeByType(mealRecipes, newRecipe.getType());
        if (recipeToDelete != null) {
            mealRecipes.remove(recipeToDelete);
            mealRecipes.add(newRecipe);
            userMealRepository.save(meal);
        }
        else {
            log.error("No recipe to change, recipeToChange -> {}, meal -> {}", newRecipe, meal);
        }
    }

    private Recipe findRecipeByType(Set<Recipe> mealRecipes, RecipeType typeToFind) {
        return mealRecipes.stream()
            .filter(recipe -> typeToFind.equals(recipe.getType()))
            .findFirst().orElse(null);
    }

    @Transactional
    public void regenerateMealPlanningFrom(LocalDate startDate) {
        User user = userService.getUser();
        regenerateMealPlanningFrom(user, startDate);
    }

    @Transactional
    public void regenerateMealPlanningFrom(User user, LocalDate startDate) {
        log.info("Regenerate meal planning for user -> {}", user);
        userMealService.deleteByUserAndDateFrom(user, startDate);
        mealPlanningGenerationService.generateAndSaveWeeklyMealPlanning(user.getId());
    }
}
