package com.alantaya.recipe.module.crm.zoho.repository;

import com.alantaya.recipe.module.crm.zoho.config.ZohoProperties;
import com.alantaya.recipe.module.crm.zoho.config.ZohoURIBuilder;
import com.alantaya.recipe.module.crm.zoho.config.ZohoURIBuilderFactory;
import com.alantaya.recipe.module.crm.zoho.domain.Contact;
import com.alantaya.recipe.module.crm.zoho.domain.Contacts;
import com.alantaya.recipe.module.crm.zoho.domain.RecordDetail;
import com.alantaya.recipe.module.crm.zoho.domain.Response;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional(propagation = Propagation.NEVER)
public class ContactRepository {

    private final Logger log = LoggerFactory.getLogger(ContactRepository.class);

    @Inject private ZohoURIBuilderFactory zohoURIBuilderFactory;
    @Inject private Marshaller contactsMarshaller;
    @Inject private Unmarshaller responseUnmarshaller;
    @Inject private ZohoProperties zohoProperties;

    public Optional<Contact> findOneByEmail(String email) throws JAXBException, IOException, URISyntaxException {
        log.info("Request to find contact with email {}", email);
        return getByEmail(email).stream().findFirst();
    }

    private List<Contact> getByEmail(String email) throws IOException, URISyntaxException, JAXBException {
        ZohoURIBuilder uri = zohoURIBuilderFactory.createZohoURIBuilder()
            .setPath(zohoProperties.getUrl().getContacts() + zohoProperties.getUrl().getSearchByPDC())
            .setSearch("email", email);
        return getContactsFromURI(uri);
    }

    public List<Contact> save(List<Contact> contactList) throws JAXBException, IOException, URISyntaxException {
        log.info("Request to save contacts");
        Contacts contacts = new Contacts(contactList);
        StringWriter contactsXml = new StringWriter();
        contactsMarshaller.marshal(contacts, contactsXml);

        ZohoURIBuilder uri = zohoURIBuilderFactory.createZohoURIBuilder()
            .setPath(zohoProperties.getUrl().getContacts() + zohoProperties.getUrl().getInsert())
            .setXmlData(contactsXml.toString());

        List<RecordDetail> recordDetails = getRecordDetailFromURI(uri);

        for(int i =0; i < contactList.size(); i++){
            Contact contact = contactList.get(i);
            RecordDetail recordDetail = recordDetails.get(i);
            contact.setZohoId(recordDetail.getId().getValue());
            contact.setCreatedBy(recordDetail.getCreatedBy().getValue());
            contact.setCreatedTime(recordDetail.getCreatedTime().getValue());
            contact.setModifiedBy(recordDetail.getModifiedBy().getValue());
            contact.setModifiedTime(recordDetail.getModifiedTime().getValue());
        }
        return contactList;
    }

    public void update(List<Contact> contacts) throws JAXBException, IOException, URISyntaxException {
        log.info("Request to update contacts -> {}", contacts);
        Contacts contactsToUpdate = new Contacts(contacts);
        StringWriter contactXml = new StringWriter();
        contactsMarshaller.marshal(contactsToUpdate, contactXml);
        ZohoURIBuilder uri = zohoURIBuilderFactory.createZohoURIBuilderForMultipleInsert()
            .setPath(zohoProperties.getUrl().getContacts() + zohoProperties.getUrl().getUpdate())
            .setXmlData(contactXml.toString());
        sendRequest(uri);
    }

    public void delete(String email) throws JAXBException, IOException, URISyntaxException {
        Optional<Contact> contact = findOneByEmail(email);
        if(contact.isPresent()) {
            ZohoURIBuilder uri = zohoURIBuilderFactory.createZohoURIBuilder()
                .setPath(zohoProperties.getUrl().getContacts() + zohoProperties.getUrl().getDelete())
                .setId(contact.get().getZohoId().getValue());
            sendRequest(uri);
        }
    }

    private List<Contact> getContactsFromURI(ZohoURIBuilder uri) throws IOException, JAXBException, URISyntaxException {
        HttpResponse httpResponse = sendRequest(uri);
        HttpEntity entity = httpResponse.getEntity();
        Response response = (Response) responseUnmarshaller.unmarshal(entity.getContent());
        if(response == null || response.getResult() == null || response.getContacts() == null){
            return Collections.emptyList();
        }
        return response.getContacts().getContacts();
    }

    private List<RecordDetail> getRecordDetailFromURI(ZohoURIBuilder uri) throws IOException, URISyntaxException, JAXBException {
        HttpResponse httpResponse = sendRequest(uri);
        HttpEntity entity = httpResponse.getEntity();
        Response response = (Response) responseUnmarshaller.unmarshal(entity.getContent());
        if(response == null || response.getResult() == null || response.getResult().getRecordDetails() == null){
            return Collections.emptyList();
        }
        return response.getResult().getRecordDetails();
    }

    private HttpResponse sendRequest(ZohoURIBuilder uri) throws URISyntaxException, IOException {
        HttpGet request = new HttpGet(uri.build());
        log.debug("URL : " + request.getURI().toURL().toString());
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpResponse httpResponse = httpClient.execute(request);
        log.debug("HTTP Code : " + httpResponse.getStatusLine().getStatusCode());
        return httpResponse;
    }
}
