package com.alantaya.recipe.dietetic;


import java.util.List;
import java.util.Optional;

public interface DieteticRule {
    boolean isValid(DieteticStatistic dieteticStatistic, List<DieteticConstraint> dieteticConstraints);

    default boolean isValid(Optional<DieteticStatistic> dieteticStatistic, List<DieteticConstraint> dieteticConstraints) {
        if (!dieteticStatistic.isPresent()) return false;
        return isValid(dieteticStatistic.get(), dieteticConstraints);
    }
}
