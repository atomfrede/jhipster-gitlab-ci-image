package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A RecipeType.
 */
@Entity
@Table(name = "T_RECIPE_TYPE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class RecipeType implements Serializable {
    public static final Long ENTREE_ID = 1L;
    public static final Long PLAT_PRINCIPAL_ID = 2L;
    public static final Long DESSERT_ID = 3L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Size(max = 60)
    @Column(name = "label", length = 60, nullable = false)
    @JsonView(View.Minimal.class)
    private String label;

    public RecipeType() {}
    public RecipeType(Long id, String label) {
        this.id = id;
        this.label = label;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RecipeType recipeType = (RecipeType) o;

        if ( ! Objects.equals(id, recipeType.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "RecipeType{" +
                "id=" + id +
                ", label='" + label + "'" +
                '}';
    }
}
