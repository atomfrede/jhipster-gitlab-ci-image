package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeCategory;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeCategory entity.
 */
public interface RecipeCategoryRepository extends JpaRepository<RecipeCategory,Long> {

}
