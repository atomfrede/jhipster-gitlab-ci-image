package com.alantaya.recipe.module.ws.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.enumeration.UserState;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.service.LicenceService;
import com.alantaya.recipe.service.SupervisionService;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Service
public class WSUserService {

    private final Logger log = LoggerFactory.getLogger(WSUserService.class);

    @Inject private UserRepository userRepository;
    @Inject private SupervisionService supervisionService;
    @Inject private LicenceService licenceService;
    @Inject private PasswordEncoder passwordEncoder;

    public User createUser(String firstName,
                           String lastName,
                           String email,
                           String phoneNumber,
                           User wsSupervisor) {
        if (! licenceService.hasAvailableLicence(wsSupervisor)) return null;

        String encryptedPassword = passwordEncoder.encode(RandomStringUtils.random(10));
        User newSupervisedUser = new User();
        newSupervisedUser.setPassword(encryptedPassword);
        newSupervisedUser.setFirstName(firstName);
        newSupervisedUser.setLastName(lastName);
        newSupervisedUser.setEmail(email);
        newSupervisedUser.setPhoneNumber(phoneNumber);
        newSupervisedUser.setState(UserState.ACTIVE);
        User userSupervisedSaved = userRepository.save(newSupervisedUser);

        supervisionService.addUserRelationship(wsSupervisor, userSupervisedSaved);
        return userSupervisedSaved;
    }

    public void updateUser(User supervisedUserToUpdate,
                           String firstName,
                           String lastName,
                           String email,
                           String phoneNumber,
                           User wsSupervisor) {
        if (!supervisionService.isSupervisedBy(supervisedUserToUpdate, wsSupervisor)) {
            log.warn("User cannot be updated: supervisedUserToUpdate -> {}", supervisedUserToUpdate);
            return;
        }

        supervisedUserToUpdate.setFirstName(firstName);
        supervisedUserToUpdate.setLastName(lastName);
        supervisedUserToUpdate.setEmail(email);
        supervisedUserToUpdate.setPhoneNumber(phoneNumber);
        userRepository.save(supervisedUserToUpdate);
    }

    public void deleteUser(Long id, User wsSupervisor) {
        User supervisedUserToDelete = userRepository.findOne(id);
        if(supervisedUserToDelete == null){
            log.warn("User do not exist: id -> {}",id);
            return;
        }
        if (!supervisionService.isSupervisedBy(supervisedUserToDelete, wsSupervisor)) {
            log.warn("User cannot be deleted: id -> {}",id);
            return;
        }
        supervisionService.deleteUserRelationship(wsSupervisor, supervisedUserToDelete);

        supervisedUserToDelete.setState(UserState.DELETED);
        userRepository.save(supervisedUserToDelete);
    }

    @Transactional(readOnly = true)
    public List<User> getAllUsers(User wsUser) {
        return new ArrayList<>(wsUser.getSupervisedUsers());
    }

}
