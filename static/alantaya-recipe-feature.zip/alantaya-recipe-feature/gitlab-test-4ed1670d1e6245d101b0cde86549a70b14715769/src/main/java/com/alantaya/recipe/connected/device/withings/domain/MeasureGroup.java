/**
 * Copyright (c) 2010-2015, openHAB.org and others.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package com.alantaya.recipe.connected.device.withings.domain;

import com.alantaya.recipe.domain.util.UnixEpochToDateTimeDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import org.joda.time.DateTime;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MeasureGroup {
	@JsonProperty("attrib")
	private Integer attribute;

	private Integer category;

	@JsonDeserialize(using =  UnixEpochToDateTimeDeserializer.class)
	private DateTime date;

	@JsonProperty("grpid")
	private Integer groupId;

	private List<Measure> measures = new ArrayList<>();

	public MeasureGroup() {}

	public Integer getAttribute() {
		return attribute;
	}

	public void setAttribute(Integer attribute) {
		this.attribute = attribute;
	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public DateTime getDate() {
		return date;
	}

	public void setDate(DateTime date) {
		this.date = date;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public List<Measure> getMeasures() {
		return measures;
	}

	public void setMeasures(List<Measure> measures) {
		this.measures = measures;
	}

	@Override
	public String toString() {
		return "MeasureGroup{" +
				"attribute=" + attribute +
				", category=" + category +
				", date=" + date +
				", groupId=" + groupId +
				", measures=" + measures +
				'}';
	}
}
