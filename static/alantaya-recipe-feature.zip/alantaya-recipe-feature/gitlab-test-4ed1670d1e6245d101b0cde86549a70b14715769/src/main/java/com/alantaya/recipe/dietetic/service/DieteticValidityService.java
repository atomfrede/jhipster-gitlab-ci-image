package com.alantaya.recipe.dietetic.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticRestaurantDish;
import com.alantaya.recipe.dietetic.DieteticRule;
import com.alantaya.recipe.dietetic.DieteticStatistic;
import com.alantaya.recipe.dietetic.rule.ConstraintValidity;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Service
public class DieteticValidityService {

    @Inject
    private ApplicationContext context;

    public boolean isValidDieteticRestaurantDish(DieteticRestaurantDish dieteticRestaurantDish,
                                                 List<DieteticConstraint> dieteticConstraints) {
        final List<DieteticRule> dieteticRuleBeans = getConstraintValidity();
        return dieteticRuleBeans.stream()
            .allMatch(dieteticRuleBean -> dieteticRuleBean.isValid(dieteticRestaurantDish, dieteticConstraints));
    }

    private List<DieteticRule> getConstraintValidity() {
        return Collections.singletonList(context.getBean(ConstraintValidity.class));
    }

    public boolean isValid(DieteticStatistic dieteticStatistic, List<DieteticConstraint> dieteticConstraints) {
        final List<DieteticRule> dieteticRuleBeans = getAllDieteticRules();
        return dieteticRuleBeans.stream()
            .allMatch(dieteticRuleBean -> dieteticRuleBean.isValid(dieteticStatistic, dieteticConstraints));
    }

    private List<DieteticRule> getAllDieteticRules() {
        String[] dieteticRuleNames =  context.getBeanNamesForType(DieteticRule.class);
        ArrayList<DieteticRule> dieteticRuleBeans = new ArrayList<>(dieteticRuleNames.length);
        for(int i = 0, n = dieteticRuleNames.length; i < n; i++) {
            String beanName = dieteticRuleNames[i];
            DieteticRule dieteticRuleBean = (DieteticRule) context.getBean(beanName);
            dieteticRuleBeans.add(dieteticRuleBean);
        }
        return dieteticRuleBeans;
    }
}
