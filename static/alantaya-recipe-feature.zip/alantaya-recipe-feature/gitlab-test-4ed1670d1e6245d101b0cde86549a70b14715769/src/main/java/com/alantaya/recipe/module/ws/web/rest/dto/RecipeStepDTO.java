package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="RecipeStep",
    description =  "Details of the <<Recipe>> step by step.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "[\n" +
        "    {\n" +
        "        \"stepNumber\": 1,\n" +
        "        \"content\": \"Dans une grand casserole d'eau froide, disposez les raies, le thym, le persil, le laurier et  15g de vinaigre. Salez et amenez à ébullition. Baissez le feu et faites cuire 10 min.\"\n" +
        "    },\n" +
        "    {\n" +
        "        \"stepNumber\": 2,\n" +
        "        \"content\": \"Dans une poêle chaude, mettez un morceau de beurre, le restant de vinaigre, un peu de persil frais haché et les câpres. Assaisonnez.\"\n" +
        "    },\n" +
        "    {\n" +
        "        \"stepNumber\": 3,\n" +
        "        \"content\": \"Dressez 4 grandes assiettes chaudes et disposez dessus les ailes de raie égouttées. Versez la sauce sur chaque raie et gardez-en un peu dans une saucière. Vous pouvez ajouter une rondelle de citron sur chacune des assiettes. Servez avec les pommes de terre vapeur. Salez et poivrez.\"\n" +
        "    }\n" +
        "]\n" +
        "----"
)
public class RecipeStepDTO {
    @ApiModelProperty(value = "step number", position = 0, required = true)
    public Integer stepNumber;

    @ApiModelProperty(position = 1, required = true)
    public String content;

    public Integer getStepNumber() {
        return stepNumber;
    }

    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "RecipeStepDTO{" +
            "stepNumber=" + stepNumber +
            ", content='" + content + '\'' +
            '}';
    }
}
