package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

@ApiModel(value = "Criteria",
    description = "Defines an allergy, pathology or diet. It's used by the engine to generate compatible meals.\n" +
        "\n" +
        "IMPORTANT: Be careful, more a user has criteria more it's complex to generate meals.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"id\": 1,\n" +
        "    \"name\": \"Maladie coeliaque: intolérance permanente au gluten\",\n" +
        "    \"description\": \"\",\n" +
        "    \"type\": \"Pathologie\",\n" +
        "    \"groups\": [\"Pathologies respiratoires\", \"Capital santé\"]\n" +
        "}\n" +
        "----")
public class CriteriaDTO {
    @ApiModelProperty(position = 0, required = true)
    private Long id;

    @ApiModelProperty(position = 1, required = true)
    private String name;

    @ApiModelProperty(position = 2, required = false)
    private String description;

    @ApiModelProperty(value = "ex: pathology, allergy, diet...", position = 3, required = true)
    private String type;

    @ApiModelProperty(value = "ex: vegetable allergy, nutritional disease...", position = 4, required = false)
    private List<String> groups = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getGroups() {
        return groups;
    }

    public void setGroups(List<String> groups) {
        this.groups = groups;
    }

    @Override
    public String toString() {
        return "CriteriaDTO{" +
            "id=" + id +
            ", name='" + name + '\'' +
            ", description='" + description + '\'' +
            ", type='" + type + '\'' +
            ", groups=" + groups +
            '}';
    }
}
