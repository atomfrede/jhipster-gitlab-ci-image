package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A RecipeState.
 */
@Entity
@Table(name = "T_RECIPE_STATE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class RecipeState implements Serializable {
    public static final Long RECORDED_ID = 1L;
    public static final Long VALIDATE_ID = 2L;
    public static final Long DRAFT_ID = 4L;
    public static final Long DELETED_ID = 7L;
    public static final Long READY_FOR_PUBLICATION = 5L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 60)
    @Column(name = "label", length = 60, nullable = false)
    private String label;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RecipeState recipeState = (RecipeState) o;

        if ( ! Objects.equals(id, recipeState.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "RecipeState{" +
                "id=" + id +
                ", label='" + label + "'" +
                '}';
    }
}
