package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.FoodTag;

import java.util.Objects;

public class DieteticFoodTag extends FoodTag implements DieteticElement, DieteticStatistic {
    private final FoodTag foodTag;

    public DieteticFoodTag(FoodTag foodTag) {
        this.foodTag = foodTag;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        return this.equals(dieteticElement) ? 1D : 0D;
    }

    @Override
    public DieteticElement getMacro() {
        return null;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public Long getId() {
        return foodTag.getId();
    }

    @Override
    public void setId(Long id) {
        foodTag.setId(id);
    }

    @Override
    public String getName() {
        return foodTag.getName();
    }

    @Override
    public void setName(String name) {
        foodTag.setName(name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFoodTag dieteticFoodTag = (DieteticFoodTag) o;

        return foodTag.equals(dieteticFoodTag.foodTag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), foodTag.getId());
    }

    @Override
    public String toString() {
        return "DieteticFoodTag{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
