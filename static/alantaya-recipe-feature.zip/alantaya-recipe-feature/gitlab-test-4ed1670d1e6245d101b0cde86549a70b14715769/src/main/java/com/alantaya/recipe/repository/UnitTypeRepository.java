package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UnitType;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the UnitType entity.
 */
public interface UnitTypeRepository extends JpaRepository<UnitType,Long> {

}
