package com.alantaya.recipe.repository.util;

import com.mysema.query.types.Predicate;
import com.mysema.query.types.expr.BooleanExpression;
import com.mysema.query.types.expr.StringExpression;

import java.util.List;

public class QueryDslUtil {

    public static Predicate likeAndLike(StringExpression string, String[] keywords) {
        BooleanExpression expression = string.like("%" + keywords[0] + "%");
        for (int index=1, max=keywords.length; index < max; index++) {
            expression = expression.and(string.like("%" + keywords[index] + "%"));
        }
        return expression;
    }

    public static Predicate likeAndLike(StringExpression string, List<String> keywords) {
        BooleanExpression expression = string.like("%" + keywords.get(0) + "%");
        for (int index=1, max=keywords.size(); index < max; index++) {
            expression = expression.and(string.like("%" + keywords.get(index) + "%"));
        }
        return expression;
    }

}
