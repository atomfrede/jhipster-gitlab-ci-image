/**
 * Spring Framework configuration files.
 */
package com.alantaya.recipe.config;
