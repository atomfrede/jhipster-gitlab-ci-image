package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.DieteticMenu;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.repository.UserMealRepository;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserMealService {
    private final Logger log = LoggerFactory.getLogger(UserMealService.class);

    @Inject private UserMealRepository userMealRepository;

    public void save(UserMeal meal) {
        save(Collections.singletonList(meal));
    }

    public void save(List<UserMeal> meals) {
        if (meals.isEmpty()) return;
        final List<LocalDate> mealDates = getDistinctMealDates(meals);
        final Optional<User> user = getDistinctMealUser(meals);
        if (!user.isPresent()) return;

        List<UserMeal> userMeals = meals.stream()
            .map(this::DieteticMenuToUserMeal)
            .collect(Collectors.toList());

        userMealRepository.deleteByUserAndDateIn(user.get(), mealDates);
        userMealRepository.save(userMeals);
    }

    private UserMeal DieteticMenuToUserMeal(UserMeal userMeal) {
        if (userMeal instanceof DieteticMenu) return ((DieteticMenu)userMeal).getUserMeal();
        return userMeal;
    }

    private List<LocalDate> getDistinctMealDates(List<UserMeal> meals) {
        return meals.stream()
            .map(UserMeal::getDate)
            .distinct()
            .collect(Collectors.toList());
    }

    private Optional<User> getDistinctMealUser(List<UserMeal> meals) {
        final List<User> users = meals.stream()
            .map(UserMeal::getUser)
            .distinct()
            .collect(Collectors.toList());

        if (users.isEmpty()) {
            log.error("Aucun user défini dans les meals");
            return Optional.empty();
        }
        else if (users.size() > 1) {
            log.error("Plusieurs utilisateurs dans les meals, cas non géré");
            return Optional.empty();
        }
        return Optional.ofNullable(users.get(0));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void deleteByUserAndDateFrom(User user, LocalDate fromDate) {
        userMealRepository.deleteByUserAndDateFrom(user, fromDate);
    }
}
