package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

@ApiModel(value = "Meal",
    description = "Defines one meal.\n" +
        "\n" +
        "IMPORTANT: <<NutritionalValue>> displays the values of one person of the meal.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"type\": \"Soir\",\n" +
        "    \"nutritionalValue\": {...},\n" +
        "    \"recipes\": [...]\n" +
        "}\n" +
        "----"
)
public class UserMealDTO {

    @ApiModelProperty(position = 1, required = true, allowableValues = "Midi, Soir")
    public String type;

    @ApiModelProperty(value = "total nutritional value of the day for one person", position = 2, required = true)
    private NutritionalValueDTO nutritionalValue;

    @ApiModelProperty(position = 3, required = true)
    private List<RecipeDTO> recipes = new ArrayList<>(3);

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public NutritionalValueDTO getNutritionalValue() {
        return nutritionalValue;
    }

    public void setNutritionalValue(NutritionalValueDTO nutritionalValue) {
        this.nutritionalValue = nutritionalValue;
    }

    public List<RecipeDTO> getRecipes() {
        return recipes;
    }

    public void setRecipes(List<RecipeDTO> recipes) {
        this.recipes = recipes;
    }

    @Override
    public String toString() {
        return "MealDayDTO{" +
            "type='" + type + '\'' +
            ", nutritionalValue=" + nutritionalValue +
            ", recipes=" + recipes +
            '}';
    }
}
