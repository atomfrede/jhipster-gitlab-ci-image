package com.alantaya.recipe.dietetic.setup.constraint;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticElement;
import com.alantaya.recipe.domain.CriteriaType;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class WeightingFactorToMinMaxConstraints {

    public List<DieteticConstraint> setUp(List<DieteticConstraint> constraintsToCompute) {

        final List<DieteticConstraint> profileConstraints = getProfileConstraints(constraintsToCompute);
        final List<DieteticConstraint> weightFactorConstraints = getWeightingFactorConstraints(constraintsToCompute);
        final List<DieteticConstraint> intervalConstraints = getIntervalConstraints(constraintsToCompute);

        final Map<DieteticElement, Double> weightingFactorByElement = getLowestWeightingFactorByElement(weightFactorConstraints);
        final List<DieteticConstraint> updatedProfileConstraints = applyWeightingFactorOnIntervalConstraints(profileConstraints, weightingFactorByElement);

        return overrideConstraint(updatedProfileConstraints, intervalConstraints);
    }

    private List<DieteticConstraint> getProfileConstraints(List<DieteticConstraint> allConstraints) {
        allConstraints.stream().forEach(this::updateWeightingFactorProfileConstraint);
        return allConstraints.stream()
            .filter(this::isIntervalProfileConstraint)
            .collect(Collectors.toList());
    }

    private boolean isProfileConstraint(DieteticConstraint constraint) {
        return CriteriaType.PROFILE_ID.equals(constraint.getCriteriaTypeId());
    }

    private void updateWeightingFactorProfileConstraint(DieteticConstraint constraint) {
        if (isProfileConstraint(constraint)
            && null == constraint.getMinQuantity() && null == constraint.getMaxQuantity()
            && 0 == constraint.getWeightingFactorRatio()) {
            constraint.setMinQuantity(0D);
            constraint.setMaxQuantity(0D);
        }
    }

    private boolean isIntervalProfileConstraint(DieteticConstraint constraint) {
        return isProfileConstraint(constraint)
            && (null != constraint.getMinQuantity() || null != constraint.getMaxQuantity());
    }

    private List<DieteticConstraint> getIntervalConstraints(List<DieteticConstraint> allConstraints) {
        return allConstraints.stream()
            .filter(this::isIntervalConstraint)
            .collect(Collectors.toList());
    }

    private boolean isIntervalConstraint(DieteticConstraint constraint) {
        return ! CriteriaType.PROFILE_ID.equals(constraint.getCriteriaTypeId())
            && (null != constraint.getMinQuantity() || null != constraint.getMaxQuantity());
    }

    private List<DieteticConstraint> getWeightingFactorConstraints(List<DieteticConstraint> allConstraints) {
        return allConstraints.stream().filter(this::isWeightingFactorConstraint).
            collect(Collectors.toList());
    }

    private boolean isWeightingFactorConstraint(DieteticConstraint constraint) {
        return ! CriteriaType.PROFILE_ID.equals(constraint.getCriteriaTypeId())
            && null != constraint.getWeightingFactorRatio()
            && null == constraint.getMinQuantity() && null == constraint.getMaxQuantity();
    }

    private Map<DieteticElement, Double> getLowestWeightingFactorByElement(List<DieteticConstraint> allConstraints) {
        final List<DieteticConstraint> constraintsWithoutProfile = getAllConstraintsWithoutConstraintProfile(allConstraints);

        // Create a list of lowest weightingFactoring constraint
        final Map<DieteticElement, Double> weightingFactorByElement = new HashMap<>();

        constraintsWithoutProfile.stream()
            .filter(constraint -> constraint.getWeightingFactorRatio() != null)
            .forEach(dieteticConstraint -> {
                DieteticElement element = dieteticConstraint.getDieteticElement();
                Double weightingFactor = dieteticConstraint.getWeightingFactorRatio();
                Double existingWeightingFactor = weightingFactorByElement.get(element);
                if (null == existingWeightingFactor) {
                    weightingFactorByElement.put(element, weightingFactor);
                } else {
                    weightingFactorByElement.put(element, Math.min(weightingFactor, existingWeightingFactor));
                }
            });

        return weightingFactorByElement;
    }

    private List<DieteticConstraint> applyWeightingFactorOnIntervalConstraints(List<DieteticConstraint> constraints,
                                                                               Map<DieteticElement, Double> weightingFactorBtElement) {
        Map<DieteticElement, DieteticConstraint> constraintByElement = new HashMap<>();
        constraints.stream().forEach(constraint -> constraintByElement.put(constraint.getDieteticElement(), constraint));

        List<DieteticConstraint> newConstraints = new ArrayList<>();
        weightingFactorBtElement.forEach((element, weightingFactor) -> {
            DieteticConstraint constraint = constraintByElement.get(element);
            if (null == constraint) {
                constraint = createConstraintFromMacro(element, constraintByElement);
                if (null != constraint) newConstraints.add(constraint);
            }
            if (null != constraint) applyWeightingFactor(weightingFactor, constraint);
            else if (0 == weightingFactor) newConstraints.add(createEliminateConstraint(element));
        });
        newConstraints.addAll(constraintByElement.values());
        return newConstraints;
    }

    private DieteticConstraint createConstraintFromMacro(DieteticElement element, Map<DieteticElement, DieteticConstraint> constraintByElement) {
        DieteticConstraint macroConstraint = null;
        DieteticElement macroElement = element.getMacro();
        if (null == macroElement) return null;

        if (constraintByElement.containsKey(macroElement)) macroConstraint = constraintByElement.get(macroElement);
        else if (null == element.getMacro().getMacro()) return null;

        DieteticElement macroMacroElement = element.getMacro().getMacro();
        if (constraintByElement.containsKey(macroMacroElement)) macroConstraint = constraintByElement.get(macroMacroElement);

        if (null == macroConstraint) return null;
        return new DieteticConstraint(null,
                                      element,
                                      macroConstraint.getCriteria(),
                                      macroConstraint.getMinQuantity(),
                                      macroConstraint.getMaxQuantity(),
                                      null);
    }

    private DieteticConstraint createEliminateConstraint(DieteticElement element) {
        return new DieteticConstraint(null, element,(Long) null, 0D, 0D, null);
    }

    private void applyWeightingFactor(Double weightingFactor, DieteticConstraint constraint) {
        final Double minQuantity = constraint.getMinQuantity();
        if (null != minQuantity) constraint.setMinQuantity(minQuantity * weightingFactor);
        final Double maxQuantity = constraint.getMaxQuantity();
        if (null != maxQuantity) constraint.setMaxQuantity(maxQuantity * weightingFactor);
    }

    private List<DieteticConstraint> getAllConstraintsWithoutConstraintProfile(List<DieteticConstraint> allConstraints) {
        final List<DieteticConstraint> allConstraintWithoutProfile = new ArrayList<>(10000);
        allConstraints.stream()
            .filter(constraint -> !CriteriaType.PROFILE_ID.equals(constraint.getCriteriaTypeId()))
            .forEach(allConstraintWithoutProfile::add);
        return allConstraintWithoutProfile;
    }

    private List<DieteticConstraint> overrideConstraint(List<DieteticConstraint> baseConstraints,
                                                        List<DieteticConstraint> overrideConstraints) {
        Map<DieteticElement, DieteticConstraint> constraintByElement = new HashMap<>();
        baseConstraints.stream().forEach(constraint -> constraintByElement.put(constraint.getDieteticElement(), constraint));
        overrideConstraints.stream().forEach(constraint -> constraintByElement.put(constraint.getDieteticElement(), constraint));

        return new ArrayList<>(constraintByElement.values());
    }

}
