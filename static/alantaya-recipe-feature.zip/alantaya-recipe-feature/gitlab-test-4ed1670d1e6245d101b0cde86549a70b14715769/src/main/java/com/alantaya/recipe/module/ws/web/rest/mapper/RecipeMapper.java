package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.*;
import com.alantaya.recipe.module.ws.web.rest.dto.RecipeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {FoodMapper.class, RecipeStepMapper.class})
public interface RecipeMapper {

    @Mappings({
        @Mapping(source = "quantityUnit.label", target = "quantityUnit"),
        @Mapping(source = "type.label", target = "type"),
        @Mapping(source = "costLevel.id", target = "costLevel"),
        @Mapping(source = "difficultyLevel.id", target = "difficultyLevel"),
        @Mapping(source = "originCountry.nameFr", target = "originCountry"),
        @Mapping(source = "originRegion.name", target = "originRegion"),
        @Mapping(source = "editor.name", target = "editor"),
        @Mapping(source = "season.label", target = "seasons"),
        @Mapping(source = "foodQuantities", target = "ingredients"),
        @Mapping(target = "nutritionalValue", ignore = true)
    })
    RecipeDTO recipeToRecipeDTO(Recipe recipe);
    List<RecipeDTO> recipesToRecipeDTOs(Collection<Recipe> recipes);

    default String recipeCategoryToString(RecipeCategory recipeCategory) {
        return recipeCategory != null ? recipeCategory.getLabel() : null;
    }

    default String recipeThemeToString(RecipeTheme recipeTheme) {
        return recipeTheme != null ? recipeTheme.getLabel() : null;
    }

    default String AuthorToString(Author author) {
        return author != null ? author.getFirstName() + " " + author.getLastName() : null;
    }

    default String recipeProfileToString(RecipeProfile recipeProfile) {
        return recipeProfile != null ? recipeProfile.getLabel() : null;
    }
}
