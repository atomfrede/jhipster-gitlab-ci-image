package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserEvent;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the UserEvent entity.
 */
public interface UserEventRepository extends JpaRepository<UserEvent,Long> {

    @Query("select userEvent from UserEvent userEvent where userEvent.user.email = ?#{principal.username}")
    List<UserEvent> findAllForCurrentUser();

    List<UserEvent> findByUser(User user);
}
