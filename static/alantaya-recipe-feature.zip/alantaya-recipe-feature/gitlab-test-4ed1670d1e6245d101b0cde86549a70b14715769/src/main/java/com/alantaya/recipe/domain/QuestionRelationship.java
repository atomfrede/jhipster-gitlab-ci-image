package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A QuestionRelationship.
 */
@Entity
@Table(name = "QUESTION_RELATIONSHIP")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class QuestionRelationship extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @ManyToOne
    @JsonView(View.Full.class)
    private QuestionnaireQuestion question;

    @ManyToOne
    @JsonView(View.Minimal.class)
    private QuestionnaireQuestion relatedQuestion;

    @ManyToOne
    @JoinColumn(name = "relationType")
    @JsonView(View.Minimal.class)
    private RelationType relationType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public QuestionnaireQuestion getQuestion() {
        return question;
    }

    public void setQuestion(QuestionnaireQuestion questionnaireQuestion) {
        this.question = questionnaireQuestion;
    }

    public QuestionnaireQuestion getRelatedQuestion() {
        return relatedQuestion;
    }

    public void setRelatedQuestion(QuestionnaireQuestion questionnaireQuestion) {
        this.relatedQuestion = questionnaireQuestion;
    }

    public RelationType getRelationType() {
        return relationType;
    }

    public void setRelationType(RelationType relationType) {
        this.relationType = relationType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        QuestionRelationship questionRelationship = (QuestionRelationship) o;

        if ( ! Objects.equals(id, questionRelationship.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "QuestionRelationship{" +
                "id=" + id +
                '}';
    }
}
