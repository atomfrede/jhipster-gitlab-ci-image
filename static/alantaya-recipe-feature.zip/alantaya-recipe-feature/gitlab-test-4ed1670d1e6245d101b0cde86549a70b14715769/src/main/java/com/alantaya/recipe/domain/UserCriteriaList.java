package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.*;
import org.hibernate.annotations.Parameter;
import org.jasypt.hibernate4.type.EncryptedStringType;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserCriteriaList.
 */
@Entity
@Table(name = "USER_CRITERIA_LIST")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@TypeDefs({
        @TypeDef(
                name="encryptedString",
                typeClass=EncryptedStringType.class,
                parameters= {
                        @Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
        })}
)
public class UserCriteriaList implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "criteria_list", nullable = false, columnDefinition = "clob")
    @Type(type = "encryptedString")
    private String criteriaList;

    @OneToOne
    private User user;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCriteriaList() {
        return criteriaList;
    }

    public void setCriteriaList(String criteriaList) {
        this.criteriaList = criteriaList;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserCriteriaList userBiometricList = (UserCriteriaList) o;

        if ( ! Objects.equals(id, userBiometricList.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserBiometricList{" +
                "id=" + id +
                ", criteriaList='" + getCriteriaList() + "'" +
                '}';
    }
}
