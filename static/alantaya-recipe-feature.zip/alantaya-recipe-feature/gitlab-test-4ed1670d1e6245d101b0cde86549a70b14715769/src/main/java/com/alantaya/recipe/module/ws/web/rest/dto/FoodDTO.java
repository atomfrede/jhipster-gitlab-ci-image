package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value="Food",
    description = "Used in <<ShoppingList>> and <<Recipe>>.\n" +
        "\n" +
        "TIP: `section` propertie defines the general section of a super market.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"name\": \"Beurre doux\",\n" +
        "    \"quantity\": 100,\n" +
        "    \"section\": \"Produits laitiers, fromages, crémerie & œufs\"\n" +
        "}\n" +
        "----"
)
public class FoodDTO {
    @ApiModelProperty(position = 0, required = true)
    public String name;

    @ApiModelProperty(value = "defined in grams", position = 1, required = true)
    public Integer quantity;

    @ApiModelProperty(value = "ex: drinks, frozen foods, meat, poultry and sausages...", position = 2, required = true)
    public String section;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    @Override
    public String toString() {
        return "FoodDTO{" +
            "name='" + name + '\'' +
            ", quantity='" + quantity + '\'' +
            ", section='" + section + '\'' +
            '}';
    }
}
