package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A RecipeStep.
 */
@Entity
@Table(name = "T_RECIPE_STEP")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class RecipeStep implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Min(value = 0)
    @Column(name = "step_number", nullable = false)
    private Integer stepNumber;

    @NotNull
    @Size(max = 3000)
    @Column(name = "content", length = 3000, nullable = false)
    private String content;

    @ManyToOne
    @JsonIgnore
    private Recipe recipe;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getStepNumber() {
        return stepNumber;
    }

    public void setStepNumber(Integer stepNumber) {
        this.stepNumber = stepNumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RecipeStep recipeStep = (RecipeStep) o;

        if (  null != id && Objects.equals(id, recipeStep.id)) return true;
        if ( ! Objects.equals(content, recipeStep.content)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, content, stepNumber);
    }

    @Override
    public String toString() {
        return "RecipeStep{" +
                "id=" + id +
                ", stepNumber='" + stepNumber + "'" +
                ", content='" + content + "'" +
                '}';
    }
}
