package com.alantaya.recipe.connected.device.withings.service;

import com.alantaya.recipe.config.oauth.BasicOAuthRequestToken;
import com.alantaya.recipe.config.oauth.InMemoryTokenStore;
import com.alantaya.recipe.config.oauth.OAuthConsumerFactory;
import com.alantaya.recipe.config.oauth.OAuthRequestToken;
import com.alantaya.recipe.connected.device.withings.domain.MeasureResult;
import com.alantaya.recipe.connected.device.withings.domain.util.WithingsConverter;
import com.alantaya.recipe.connected.device.withings.repository.MeasureRepository;
import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.domain.UserOAuthCredentials;
import com.alantaya.recipe.repository.UserOAuthCredentialsRepository;
import com.alantaya.recipe.service.BiometricService;
import com.alantaya.recipe.service.UserService;
import oauth.signpost.OAuthConsumer;
import oauth.signpost.OAuthProvider;
import oauth.signpost.exception.OAuthException;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;

@Service
public class UserConnectedDeviceService {

    private final Logger log = LoggerFactory.getLogger(UserConnectedDeviceService.class);

    @Inject
    @Qualifier(value = "withingsOAuthConsumerFactory")
    private OAuthConsumerFactory withingsOAuthConsumerFactory;

    @Inject
    @Qualifier(value = "withingsOAuthProvider")
    private OAuthProvider withingsOAuthProvider;

    @Inject
    @Qualifier(value = "withingsTokenStore")
    private InMemoryTokenStore tokenStore;

    @Inject
    private UserService userService;

    @Inject
    private UserOAuthCredentialsRepository userOAuthCredentialsRepository;

    @Inject
    private MeasureRepository measureRepository;

    @Inject
    private WithingsConverter withingsConverter;

    @Inject
    private BiometricService biometricService;

    public String getRedirectUrl(String alantayaAuthorizationUrl) {
        Long userId = userService.getUser().getId();
        OAuthConsumer consumer = withingsOAuthConsumerFactory.createOauthConsumer();
        try {
            String redirectUrl = withingsOAuthProvider.retrieveRequestToken(consumer, alantayaAuthorizationUrl);
            tokenStore.store(userId, new BasicOAuthRequestToken(consumer.getToken(), consumer.getTokenSecret()));
            return redirectUrl;
        }
        catch (OAuthException exception) {
            throw new RuntimeException(exception);
        }
    }

    public boolean isUserAuthorized() {
        User user = userService.getUser();
        return null != userOAuthCredentialsRepository.findByUserId(user.getId());
    }

    public void retrieveAccessToken(Long providerUserId, String oauthVerifier) {
        User user = userService.getUser();
        OAuthRequestToken token = tokenStore.retrieveToken(user.getId());
        OAuthConsumer consumer = withingsOAuthConsumerFactory.createOauthConsumerWithToken(token);
        try {
            withingsOAuthProvider.retrieveAccessToken(consumer, oauthVerifier, "userid=" + providerUserId.toString());

            UserOAuthCredentials oAuthCredentials = new UserOAuthCredentials(
                providerUserId,
                consumer.getToken(),
                consumer.getTokenSecret(),
                userService.getUser());

            userOAuthCredentialsRepository.deleteByUserId(user.getId());
            userOAuthCredentialsRepository.save(oAuthCredentials);
            retrieveAndSaveAllUserData();
        }
        catch (OAuthException exception) {
            throw new RuntimeException(exception);
        }
    }

    public void retrieveAndSaveAllUserData() {
        final User user = userService.getUser();
        final UserOAuthCredentials oAuthCredentials = userOAuthCredentialsRepository.findByUserId(user.getId());
        final OAuthConsumer consumer = withingsOAuthConsumerFactory.createOauthConsumerWithToken(oAuthCredentials);

        final MeasureResult measureResult = measureRepository.findAll(consumer, oAuthCredentials.getProviderUserId());

        final List<UserBiometricValue> userBiometricValueList =
            withingsConverter.measureResultToWeightUserBiometricList(measureResult);
        biometricService.addBiometricValues(userBiometricValueList, user);
    }

    @Scheduled(cron="0 1 1 * * ?")
    @Transactional
    public void retrieveAndSaveAllUserLatestData() {
        List<UserOAuthCredentials> oAuthCredentials = userOAuthCredentialsRepository.findAll();
        oAuthCredentials.stream().forEach(
            oAuthCredential -> {
                try {
                    User user = oAuthCredential.getUser();
                    UserBiometricValue biometricWeightValue = biometricService.getBiometricValue(Biometry.WEIGHT_ID, user);
                    retrieveAndSaveUserDataFromDate(user, biometricWeightValue.getCreatedDate().plusSeconds(1));
                } catch (Exception e) {
                    log.error("Error while retrieving user {} data from Withings", oAuthCredential.getUser(), e);
                }
            }
        );
    }

    public void retrieveAndSaveUserDataFromDate(User user, DateTime fromDate) {
        final UserOAuthCredentials oAuthCredentials = userOAuthCredentialsRepository.findByUserId(user.getId());
        final OAuthConsumer consumer = withingsOAuthConsumerFactory.createOauthConsumerWithToken(oAuthCredentials);

        final MeasureResult measureResult = measureRepository.findByDateAfter(
            consumer,
            oAuthCredentials.getProviderUserId(),
            fromDate
        );

        final List<UserBiometricValue> userBiometricValueList =
            withingsConverter.measureResultToWeightUserBiometricList(measureResult);
        biometricService.addBiometricValues(userBiometricValueList, user);
    }
}
