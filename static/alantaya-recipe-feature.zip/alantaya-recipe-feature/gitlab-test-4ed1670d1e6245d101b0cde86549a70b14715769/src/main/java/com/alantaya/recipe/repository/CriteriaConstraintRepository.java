package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.CriteriaConstraint;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the CriteriaConstraint entity.
 */
public interface CriteriaConstraintRepository extends JpaRepository<CriteriaConstraint,Long> {

}
