package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A QuestionnaireAnswerType.
 */
@Entity
@Table(name = "QUESTIONNAIRE_ANSWERTYPE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class QuestionnaireAnswerType implements Serializable {

    public static final QuestionnaireAnswerType RADIO = new QuestionnaireAnswerType("RADIO");
    public static final QuestionnaireAnswerType YESNO = new QuestionnaireAnswerType("YESNO");
    public static final QuestionnaireAnswerType SELECT = new QuestionnaireAnswerType("SELECT");
    public static final QuestionnaireAnswerType TEXT = new QuestionnaireAnswerType("TEXT");

    @Id
    @NotNull
    @Size(max = 20)
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    public QuestionnaireAnswerType() {
    }

    public QuestionnaireAnswerType(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        QuestionnaireAnswerType questionnaireAnswerType = (QuestionnaireAnswerType) o;

        if ( ! Objects.equals(name, questionnaireAnswerType.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public String toString() {
        return "QuestionnaireAnswerType{" +
                "  name='" + name + "'" +
                '}';
    }
}
