package com.alantaya.recipe.dietetic;

import net.karneim.pojobuilder.GeneratePojoBuilder;

import java.util.ArrayList;
import java.util.List;

@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class DieteticMenuPattern {
    private List<Long> mealTypesId = new ArrayList<>();
    private List<Long> recipeTypesId = new ArrayList<>();

    public DieteticMenuPattern() {}
    public DieteticMenuPattern(List<Long> mealTypesId, List<Long> recipeTypesId) {
        this.mealTypesId = mealTypesId;
        this.recipeTypesId = recipeTypesId;
    }

    public List<Long> getMealTypesId() {
        return mealTypesId;
    }

    public List<Long> getRecipeTypesId() {
        return recipeTypesId;
    }

    public void setRecipeTypesId(List<Long> recipeTypesId) {
        this.recipeTypesId = recipeTypesId;
    }

    public void setMealTypesId(List<Long> mealTypesId) {
        this.mealTypesId = mealTypesId;
    }

    @Override
    public String toString() {
        return "DieteticMenuPattern{" +
            "mealTypesId=" + mealTypesId +
            ", recipeTypesId=" + recipeTypesId +
            '}';
    }
}
