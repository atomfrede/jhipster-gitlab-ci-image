package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

@ApiModel(value="User",
    description = "" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"id\": 1,\n" +
        "    \"firstName\": \"Thibaut\",\n" +
        "    \"lastName\": \"Mottet\",\n" +
        "    \"email\": \"thibaut@alantaya.com\",\n" +
        "    \"phoneNumber\": \"0123456789\"\n" +
        "}\n" +
        "----")
public class UserDTO {
    @ApiModelProperty(position = 0, required = false)
    private Long id;

    @ApiModelProperty(value = "first name", position = 1, required = true)
    @NotNull
    private String firstName;

    @ApiModelProperty(value = "last name", position = 2, required = true)
    @NotNull
    private String lastName;

    @ApiModelProperty(value = "Email is unique", position = 3, required = true)
    @NotNull
    private String email;

    @ApiModelProperty(value = "phone number", position = 4, required = false)
    private String phoneNumber;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "UserMapper{" +
            "id=" + id +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", email='" + email + '\'' +
            '}';
    }
}
