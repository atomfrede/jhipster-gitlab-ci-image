package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A NutrimentPerFood.
 */
@Entity
@Table(name = "T_NUTRIMENT_PER_FOOD")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class NutrimentPerFood implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Min(value = 0)
    @Column(name = "quantity", nullable = false)
    private Double quantity;

    @ManyToOne
    @JsonIgnore
    private Food food;

    @ManyToOne
    private Nutriment nutriment;

    @ManyToOne
    private Unit unit;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public Nutriment getNutriment() {
        return nutriment;
    }

    public void setNutriment(Nutriment nutriment) {
        this.nutriment = nutriment;
    }

    public Unit getUNit() {
        return unit;
    }

    public void setUNit(Unit unit) {
        this.unit = unit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        NutrimentPerFood nutrimentPerFood = (NutrimentPerFood) o;

        if ( ! Objects.equals(id, nutrimentPerFood.id)) return false;
        if ( ! Objects.equals(food, nutrimentPerFood.food)) return false;
        if ( ! Objects.equals(nutriment, nutrimentPerFood.nutriment)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, food, nutriment);
    }

    @Override
    public String toString() {
        return "NutrimentPerFood{" +
                "id=" + id +
                ", quantity='" + quantity + "'" +
                '}';
    }
}
