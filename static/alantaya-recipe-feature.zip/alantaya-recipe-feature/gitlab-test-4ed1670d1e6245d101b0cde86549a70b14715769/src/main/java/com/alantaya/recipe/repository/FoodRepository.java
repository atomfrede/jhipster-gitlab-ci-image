package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.BasicFood;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.QFood;
import com.alantaya.recipe.repository.util.QueryDslUtil;
import com.alantaya.recipe.web.rest.dto.FoodSearchDTO;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.types.Predicate;

import java.util.Collection;
import java.util.List;

/**
 * Spring Data JPA repository for the Food entity.
 */
public interface FoodRepository extends JpaRepository<Food,Long>, QueryDslPredicateExecutor<Food> {

    @Query("select food " +
            "from Food food " +
            "left join fetch food.foodFamily " +
            "left join fetch food.foodSection " +
            "left join fetch food.foodState " +
            "left join fetch food.nutrimentQuantitys " +
            "left join fetch food.favoriteUnit " +
            "left join fetch food.tags " +
            "where food.id =:id")
    Food findOneWithEagerRelationships(@Param("id") Long id);

    List<Food> findByBasicFoodIn(Collection<BasicFood> basicFood);

    public default Page<Food> search(FoodSearchDTO query, Pageable page) {
        BooleanBuilder where = new BooleanBuilder();
        if (StringUtils.isNotBlank(query.getKeywords())) {
            String[] keywords = query.getKeywords().toLowerCase().split(" ");
            where.and(RecipePredicates.nameContains(keywords))
                    .or(RecipePredicates.completeNameContains(keywords));
        }

        if (null != query.getStateId())
            where.and(RecipePredicates.stateIdEquals(query.getStateId()));

        if (null != query.getFoodFamilyId())
            where.and(RecipePredicates.foodFamilyIdEquals(query.getFoodFamilyId()));

        if (null != query.getFoodSectionId())
            where.and(RecipePredicates.foodSectionIdEquals(query.getFoodSectionId()));

        if (null != query.getFoodTagId())
            where.and(RecipePredicates.foodTagIdsContains(query.getFoodTagId()));

        return findAll(
                where,
                page
        );
    }

    public class RecipePredicates {

        public static Predicate nameContains(final String... keywords) {
            return QueryDslUtil.likeAndLike(QFood.food.name.toLowerCase(), keywords);
        }

        public static Predicate completeNameContains(final String ... keywords) {
            return QueryDslUtil.likeAndLike(QFood.food.name.toLowerCase(), keywords);
        }

        public static Predicate stateIdEquals(final Long stateId) {
            QFood food = QFood.food;
            if(null == stateId) return food.foodState.isNull();
            return food.foodState.id.eq(stateId);
        }

        public static Predicate foodFamilyIdEquals(final Long foodFamilyId) {
            QFood food = QFood.food;
            if(null == foodFamilyId) return food.foodState.isNull();
            return food.foodFamily.id.eq(foodFamilyId);
        }

        public static Predicate foodSectionIdEquals(final Long foodSectionId) {
            QFood food = QFood.food;
            if(null == foodSectionId) return food.foodState.isNull();
            return food.foodSection.id.eq(foodSectionId);
        }

        public static Predicate foodTagIdsContains(final Long foodTagId) {
            QFood food = QFood.food;
            return food.tags.any().id.eq(foodTagId);
        }
    }

}
