package com.alantaya.recipe.module.ws.web.rest.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.joda.time.LocalDate;

import java.util.List;

@ApiModel(value = "ShoppingList",
    description = "Defines all the <<Food>> you need to make recipes during the specified period." +
        " Identical foods have their quantities aggregated.\n" +
        "\n" +
        "[source,json]\n" +
        "----\n" +
        "{\n" +
        "    \"from\": \"2015-11-18\",\n" +
        "    \"to\": \"2015-11-25\",\n" +
        "    \"foods\": [...]\n" +
        "}\n" +
        "----"
)
public class ShoppingListDTO {
    @ApiModelProperty(value = "from date", position = 0, required = true)
    private LocalDate from;

    @ApiModelProperty(value = "to date", position = 1, required = true)
    private LocalDate to;

    @ApiModelProperty(value = "foods list", position = 2, required = true)
    private List<FoodDTO> foods;

    public LocalDate getFrom() {
        return from;
    }

    public void setFrom(LocalDate from) {
        this.from = from;
    }

    public LocalDate getTo() {
        return to;
    }

    public void setTo(LocalDate to) {
        this.to = to;
    }

    public List<FoodDTO> getFoods() {
        return foods;
    }

    public void setFoods(List<FoodDTO> foods) {
        this.foods = foods;
    }

    @Override
    public String toString() {
        return "ShoppingListDTO{" +
            "from=" + from +
            ", to=" + to +
            ", foods=" + foods +
            '}';
    }
}
