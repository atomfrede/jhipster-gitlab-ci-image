package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.*;
import org.joda.time.DateTime;

import java.util.*;
import java.util.stream.Collectors;

public class DieteticRecipe extends Recipe implements DieteticStatistic {
    private final Recipe recipe;
    private final List<DieteticFoodQuantityByRecipe> dieteticFoodQuantityByRecipes;

    public DieteticRecipe(Recipe recipe) {
        this.recipe = recipe;
        this.dieteticFoodQuantityByRecipes = recipe.getFoodQuantities().stream()
            .map(DieteticFoodQuantityByRecipe::new)
            .collect(Collectors.toList());
    }

    public List<DieteticFoodQuantityByRecipe> getDieteticFoodQuantityByRecipes() {
        return dieteticFoodQuantityByRecipes;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        Double quantity = dieteticFoodQuantityByRecipes.stream()
            .mapToDouble(foodQuantity -> foodQuantity.getQuantityFor(dieteticElement))
            .sum();
        quantity = quantity / recipe.getSharesNumber();
        return quantity;
    }

    public Recipe getRecipe() {
        return recipe;
    }

    @Override
    public Long getId() {
        return recipe.getId();
    }

    @Override
    public void setId(Long id) {
        recipe.setId(id);
    }

    @Override
    public String getTitle() {
        return recipe.getTitle();
    }

    @Override
    public void setTitle(String title) {
        recipe.setTitle(title);
    }

    @Override
    public String getSummary() {
        return recipe.getSummary();
    }

    @Override
    public void setSummary(String summary) {
        recipe.setSummary(summary);
    }

    @Override
    public Integer getSharesNumber() {
        return recipe.getSharesNumber();
    }

    @Override
    public void setSharesNumber(Integer sharesNumber) {
        recipe.setSharesNumber(sharesNumber);
    }

    @Override
    public Integer getPreparationTime() {
        return recipe.getPreparationTime();
    }

    @Override
    public void setPreparationTime(Integer preparationTime) {
        recipe.setPreparationTime(preparationTime);
    }

    @Override
    public Integer getCookingTime() {
        return recipe.getCookingTime();
    }

    @Override
    public void setCookingTime(Integer cookingTime) {
        recipe.setCookingTime(cookingTime);
    }

    @Override
    public Integer getRestTime() {
        return recipe.getRestTime();
    }

    @Override
    public void setRestTime(Integer restTime) {
        recipe.setRestTime(restTime);
    }

    @Override
    public Boolean getBetterPreparedInAdvance() {
        return recipe.getBetterPreparedInAdvance();
    }

    @Override
    public void setBetterPreparedInAdvance(Boolean betterPreparedInAdvance) {
        recipe.setBetterPreparedInAdvance(betterPreparedInAdvance);
    }

    @Override
    public String getAdvice() {
        return recipe.getAdvice();
    }

    @Override
    public void setAdvice(String advice) {
        recipe.setAdvice(advice);
    }

    @Override
    public String getSourceUrl() {
        return recipe.getSourceUrl();
    }

    @Override
    public void setSourceUrl(String sourceUrl) {
        recipe.setSourceUrl(sourceUrl);
    }

    @Override
    public RecipeType getType() {
        return recipe.getType();
    }

    @Override
    public void setType(RecipeType recipeType) {
        recipe.setType(recipeType);
    }

    @Override
    public Set<RecipeCategory> getCategories() {
        return recipe.getCategories();
    }

    @Override
    public void setCategories(Set<RecipeCategory> recipeCategories) {
        recipe.setCategories(recipeCategories);
    }

    @Override
    public CostLevel getCostLevel() {
        return recipe.getCostLevel();
    }

    @Override
    public void setCostLevel(CostLevel costLevel) {
        recipe.setCostLevel(costLevel);
    }

    @Override
    public DifficultyLevel getDifficultyLevel() {
        return recipe.getDifficultyLevel();
    }

    @Override
    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        recipe.setDifficultyLevel(difficultyLevel);
    }

    @Override
    public RecipeQuantityUnit getQuantityUnit() {
        return recipe.getQuantityUnit();
    }

    @Override
    public void setQuantityUnit(RecipeQuantityUnit recipeQuantityUnit) {
        recipe.setQuantityUnit(recipeQuantityUnit);
    }

    @Override
    public Set<FoodQuantityByRecipe> getFoodQuantities() {
        return recipe.getFoodQuantities();
    }

    @Override
    public Set<RecipeStep> getSteps() {
        return recipe.getSteps();
    }

    @Override
    public Set<CookingMode> getCookingModes() {
        return recipe.getCookingModes();
    }

    @Override
    public void setCookingModes(Set<CookingMode> cookingModes) {
        recipe.setCookingModes(cookingModes);
    }

    @Override
    public Set<RecipeDurableLife> getDurableLifes() {
        return recipe.getDurableLifes();
    }

    @Override
    public void setDurableLifes(Set<RecipeDurableLife> recipeDurableLifes) {
        recipe.setDurableLifes(recipeDurableLifes);
    }

    @Override
    public Season getSeason() {
        return recipe.getSeason();
    }

    @Override
    public void setSeason(Season season) {
        recipe.setSeason(season);
    }

    @Override
    public Country getOriginCountry() {
        return recipe.getOriginCountry();
    }

    @Override
    public void setOriginCountry(Country country) {
        recipe.setOriginCountry(country);
    }

    @Override
    public Region getOriginRegion() {
        return recipe.getOriginRegion();
    }

    @Override
    public void setOriginRegion(Region region) {
        recipe.setOriginRegion(region);
    }

    @Override
    public Set<RecipeTheme> getThemes() {
        return recipe.getThemes();
    }

    @Override
    public void setThemes(Set<RecipeTheme> recipeThemes) {
        recipe.setThemes(recipeThemes);
    }

    @Override
    public Set<RecipeProfile> getRecipeProfiles() {
        return recipe.getRecipeProfiles();
    }

    @Override
    public void setRecipeProfiles(Set<RecipeProfile> recipeProfiles) {
        recipe.setRecipeProfiles(recipeProfiles);
    }

    @Override
    public RecipeState getState() {
        return recipe.getState();
    }

    @Override
    public void setState(RecipeState recipeState) {
        recipe.setState(recipeState);
    }

    @Override
    public Image getImage() {
        return recipe.getImage();
    }

    @Override
    public void setImage(Image image) {
        recipe.setImage(image);
    }

    @Override
    public Author getAuthor() {
        return recipe.getAuthor();
    }

    @Override
    public void setAuthor(Author author) {
        recipe.setAuthor(author);
    }

    @Override
    public Editor getEditor() {
        return recipe.getEditor();
    }

    @Override
    public void setEditor(Editor editor) {
        recipe.setEditor(editor);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticRecipe dieteticRecipe = (DieteticRecipe) o;

        return recipe.equals(dieteticRecipe.recipe);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), recipe.getId());
    }

    @Override
    public String toString() {
        return "DieteticRecipe{" +
            "id=" + getId() +
            ", title='" + getTitle() + "'" +
            '}';
    }

    @Override
    public String getCreatedBy() {
        return recipe.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        recipe.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return recipe.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        recipe.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return recipe.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        recipe.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return recipe.getLastModifiedDate();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        recipe.setLastModifiedDate(lastModifiedDate);
    }
}
