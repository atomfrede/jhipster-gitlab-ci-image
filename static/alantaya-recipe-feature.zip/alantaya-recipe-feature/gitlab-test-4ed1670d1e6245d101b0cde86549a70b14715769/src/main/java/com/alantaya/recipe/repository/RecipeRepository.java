package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.QRecipe;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.web.rest.dto.RecipeSearchDTO;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.types.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

/**
 * Spring Data JPA repository for the Recipe entity.
 */
public interface RecipeRepository extends JpaRepository<Recipe,Long>, QueryDslPredicateExecutor<Recipe> {

    @Query("select recipe " +
        "from Recipe recipe " +
        "left join fetch recipe.categories " +
        "left join fetch recipe.cookingModes " +
        "left join fetch recipe.durableLifes " +
        "left join fetch recipe.themes " +
        "left join fetch recipe.season " +
        "left join fetch recipe.difficultyLevel " +
        "left join fetch recipe.costLevel " +
        "left join fetch recipe.recipeProfiles " +
        "left join fetch recipe.steps " +
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.basicFood " +
        "left join fetch recipe.author " +
        "left join fetch recipe.editor " +
        "left join fetch recipe.originCountry " +
        "left join fetch recipe.originRegion " +
        "where recipe.id =:id")
    Recipe findOneWithEagerRelationships(@Param("id") Long id);

    @Query("select distinct recipe " +
        "from Recipe recipe " +
        "left join fetch recipe.categories " +
        "left join fetch recipe.cookingModes " +
        "left join fetch recipe.durableLifes " +
        "left join fetch recipe.themes " +
        "left join fetch recipe.season " +
        "left join fetch recipe.difficultyLevel " +
        "left join fetch recipe.costLevel " +
        "left join fetch recipe.recipeProfiles " +
        "left join fetch recipe.steps " +
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.basicFood " +
        "left join fetch recipe.author " +
        "left join fetch recipe.editor " +
        "left join fetch recipe.originCountry " +
        "left join fetch recipe.originRegion " +
        "where recipe.id in :ids")
    List<Recipe> findByIdInWithEagerRelationships(@Param("ids") List<Long> ids);


    @Query("select distinct recipe " +
        "from Recipe recipe " +
        "left join fetch recipe.state " +
        "left join fetch recipe.quantityUnit "+
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.foodFamily foodFamily " +
        "left join fetch food.foodState " +
        "left join fetch food.tags " +
        "left join fetch food.nutrimentQuantitys nutrimentQuantitys " +
        "left join fetch foodFamily.foodFamilyGroup " +
        "left join fetch nutrimentQuantitys.nutriment nutriment " +
        "left join fetch nutriment.nutrimentFamily " +
        "where recipe.id =:id")
    Recipe findOneForDieteticRecipe(@Param("id") Long id);

    @Query("select distinct recipe " +
        "from Recipe recipe " +
        "left join fetch recipe.state " +
        "left join fetch recipe.quantityUnit "+
        "left join fetch recipe.foodQuantities foodQuantities " +
        "left join fetch foodQuantities.food food " +
        "left join fetch food.foodFamily foodFamily " +
        "left join fetch food.foodState " +
        "left join fetch food.tags " +
        "left join fetch food.nutrimentQuantitys nutrimentQuantitys " +
        "left join fetch foodFamily.foodFamilyGroup " +
        "left join fetch nutrimentQuantitys.nutriment nutriment " +
        "left join fetch nutriment.nutrimentFamily " +
        "where recipe.id in :ids")
    List<Recipe> findByIdInForDieteticRecipe(@Param("ids") Collection<Long> ids);

    default Iterable<Recipe> search(RecipeSearchDTO params) {
        return findAll(getWhere(params));
    }

    default Page<Recipe> search(RecipeSearchDTO params, Pageable page) {
        return findAll(
            getWhere(params),
            page
        );
    }

    default BooleanBuilder getWhere(RecipeSearchDTO params) {
        BooleanBuilder where = new BooleanBuilder();
        if (StringUtils.isNoneBlank(params.getTitleKeyword()))
            where.and(RecipePredicates.titleContains(params.getTitleKeyword()));

        if (null != params.getStateId())
            where.and(RecipePredicates.stateIdEquals(params.getStateId()));

        if (null != params.getTypeId())
            where.and(RecipePredicates.typeEquals(params.getTypeId()));

        if (null != params.getSeasonId())
            where.and(RecipePredicates.seasonEquals(params.getSeasonId()));

        if (null != params.getCountryId())
            where.and(RecipePredicates.countryEquals(params.getCountryId()));

        if (null != params.getRegionId())
            where.and(RecipePredicates.regionEquals(params.getRegionId()));

        if (null != params.getCookingModeId())
            where.and(RecipePredicates.cookingModesContains(params.getCookingModeId()));

        if (null != params.getMinPreparationTime() || null != params.getMaxPreparationTime())
            where.and(RecipePredicates.preparationTimeBetween(
                params.getMinPreparationTime(),
                params.getMaxPreparationTime()
            ));

        if (null != params.getDifficultyLevelId())
            where.and(RecipePredicates.difficultyLevelEquals(params.getDifficultyLevelId()));

        if (null != params.getCostLevelId())
            where.and(RecipePredicates.costLevelEquals(params.getCostLevelId()));

        if (null != params.getContainsBasicFoodIds())
            for (int index = 0, max = params.getContainsBasicFoodIds().size(); index < max; index ++) {
                Long basicFoodId = params.getContainsBasicFoodIds().get(index);
                where.and(RecipePredicates.containsBasicFoodId(basicFoodId));
            }

        if (null != params.getDoesNotContainBasicFoodIds())
            where.and(RecipePredicates.doesNotContainBasicFoodIds(params.getDoesNotContainBasicFoodIds()));

        if (null != params.getMaxFoodsCount())
            where.and(RecipePredicates.maxFoodsQuantityCount(params.getMaxFoodsCount()));

        if (null != params.getLastModifiedBy())
            where.and(RecipePredicates.lastModifiedByEquals(params.getLastModifiedBy()));

        if (params.getLastModifiedDate() != null)
            where.and(RecipePredicates.lastModifiedDateEquals(params.getLastModifiedDate()));

        if (params.hasImage()) {
            where.and(RecipePredicates.imageIsNotNull());
        }

        if (null != params.getAuhorId())
            where.and(RecipePredicates.authorEquals(params.getAuhorId()));

        return where;
    }

    class RecipePredicates {

        public static Predicate stateIdEquals(final Long stateId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == stateId) return recipe.state.isNull();
            return recipe.state.id.eq(stateId);
        }

        public static Predicate titleContains(final String searchedWords) {
            QRecipe recipe = QRecipe.recipe;
            String like = "%" + searchedWords.toLowerCase() + "%";
            return recipe.title.toLowerCase().like(like);
        }

        public static Predicate typeEquals(final Long typeId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == typeId) return recipe.type.isNull();
            return recipe.type.id.eq(typeId);
        }

        public static Predicate seasonEquals(final Long seasonId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == seasonId) return recipe.season.isNull();
            return recipe.season.id.eq(seasonId);
        }

        public static Predicate countryEquals(final Long countryId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == countryId) return recipe.originCountry.isNull();
            return recipe.originCountry.id.eq(countryId);
        }

        public static Predicate regionEquals(final Long regionId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == regionId) return recipe.originRegion.isNull();
            return recipe.originRegion.id.eq(regionId);
        }

        public static Predicate cookingModesContains(final Long cookingModeId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == cookingModeId) return recipe.cookingModes.isEmpty();
            return recipe.cookingModes.any().id.eq(cookingModeId);
        }

        public static Predicate preparationTimeBetween(final Long minTime, final Long maxTime) {
            QRecipe recipe = QRecipe.recipe;
            return recipe.preparationTime.between(minTime, maxTime);
        }

        public static Predicate containsBasicFoodId(final Long ... basicFoodId) {
            QRecipe recipe = QRecipe.recipe;
            return recipe.foodQuantities.any().food.basicFood.id.in(basicFoodId);
        }

        public static Predicate doesNotContainBasicFoodIds(final List<Long> basicFoodIds) {
            QRecipe recipe = QRecipe.recipe;
            return recipe.foodQuantities.any().food.basicFood.id.in(basicFoodIds).not();
        }

        public static Predicate maxFoodsQuantityCount(final Long maxFoodCount) {
            QRecipe recipe = QRecipe.recipe;
            return recipe.foodQuantities.size().loe(maxFoodCount);
        }

        public static Predicate difficultyLevelEquals(final Long difficultyLevelId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == difficultyLevelId) return recipe.difficultyLevel.isNull();
            return recipe.difficultyLevel.id.eq(difficultyLevelId);
        }

        public static Predicate costLevelEquals(final Long costLevelId) {
            QRecipe recipe = QRecipe.recipe;
            if(null == costLevelId) return recipe.costLevel.isNull();
            return recipe.costLevel.id.eq(costLevelId);
        }

        public static Predicate lastModifiedByEquals(final String userEmail) {
            QRecipe recipe = QRecipe.recipe;
            if(null == userEmail) return recipe.lastModifiedBy.isNull();
            return recipe.lastModifiedBy.eq(userEmail);
        }

        public static Predicate lastModifiedDateEquals(final DateTime lastModifiedDate) {
            QRecipe recipe = QRecipe.recipe;
            if(null == lastModifiedDate) return recipe.lastModifiedDate.isNull();
            return recipe.lastModifiedDate.between(
                    lastModifiedDate.withTime(0, 0, 0, 0),
                    lastModifiedDate.withTime(23, 59, 59, 999));
        }

        public static Predicate authorEquals(final Long author) {
            QRecipe recipe = QRecipe.recipe;
            if(null == author) return recipe.author.isNull();
            return recipe.author.id.eq(author);
        }

        public static Predicate createdDateEquals(final DateTime createdDate) {
            QRecipe recipe = QRecipe.recipe;
            if(null == createdDate) return recipe.createdDate.isNull();
            return recipe.createdDate.between(
                    createdDate.withTime(0, 0, 0, 0),
                    createdDate.withTime(23, 59, 59, 999));
        }

        public static Predicate imageIsNotNull() {
            QRecipe recipe = QRecipe.recipe;
            return recipe.image.isNotNull();
        }
    }
}
