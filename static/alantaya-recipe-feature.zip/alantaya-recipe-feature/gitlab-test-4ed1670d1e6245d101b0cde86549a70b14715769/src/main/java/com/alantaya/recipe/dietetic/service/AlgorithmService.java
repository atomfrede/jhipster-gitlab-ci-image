package com.alantaya.recipe.dietetic.service;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.MealType;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.RecipeState;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.repository.MealTypeRepository;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.service.dto.MealPlanning;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class AlgorithmService {
    private final Logger log = LoggerFactory.getLogger(AlgorithmService.class);

    private static final int TRYOUT_NUMBER = 100;

    @Inject private DieteticValidityService dieteticValidityService;
    @Inject private DieteticRecipeService dieteticRecipeService;
    @Inject private RecipeRepository recipeRepository;
    @Inject private MealTypeRepository mealTypeRepository;

    public List<Recipe> getAlternativeRecipeList(DieteticMenuPattern menuPattern,
                                                 List<DieteticConstraint> computedConstraints,
                                                 List<UserMeal> actualMeals,
                                                 UserMeal mealToChange,
                                                 Long recipeTypeIdToChange,
                                                 int numberOfAlternativeRecipeAsked) {

        final List<DieteticRecipe> computedRecipes = getDieteticRecipes(menuPattern, computedConstraints);

        List<DieteticRecipe> recipeToUse = new ArrayList<>(computedRecipes);
        List<Recipe> alternativeRecipes = new ArrayList<>();

        Optional<UserMeal> meal = actualMeals.stream()
            .filter(userMeal -> userMeal.getMealType().equals(mealToChange.getMealType()))
            .findFirst();
        if (! meal.isPresent()) return Collections.emptyList();
        UserMeal mealToUpdate = meal.get();


        int tryoutNumber = 0;
        while (alternativeRecipes.size() < numberOfAlternativeRecipeAsked
               && tryoutNumber < TRYOUT_NUMBER) {

            Optional<DieteticRecipe> alternative = getValidRecipe(recipeToUse, computedConstraints);
            if (! alternative.isPresent()) break;
            recipeToUse.remove(alternative.get());
            Recipe alternativeRecipeToTest = alternative.get();

            mealToUpdate.setRecipes(
                mealToUpdate.getRecipes().stream()
                    .filter(recipe -> !recipe.getType().getId().equals(recipeTypeIdToChange))
                    .collect(Collectors.toSet())
            );
            mealToUpdate.getRecipes().add(alternativeRecipeToTest);

            DieteticMenuDay menuDay = new DieteticMenuDay(actualMeals, mealToChange.getDate());
            if (dieteticValidityService.isValid(menuDay, computedConstraints)) alternativeRecipes.add(alternativeRecipeToTest);

            tryoutNumber++;
        }

        return alternativeRecipes;
    }

    private List<DieteticRecipe> getDieteticRecipes(DieteticMenuPattern menuPattern, List<DieteticConstraint> computedConstraints) {
        List<Recipe> recipes = recipeRepository.findAll();
        return dieteticRecipeService.getComputedRecipe(recipes, computedConstraints, menuPattern);
    }

    /**
     * !!Warning!! This method generate meal planning, but without the definition of the user in meal.user
     * @param constraints constraints
     * @param menuPattern menuPattern
     * @param startDate startDate
     * @param endDate endDate
     * @return MealPlanning without the user definition
     */
    public MealPlanning generateMealPlanning(List<DieteticConstraint> constraints,
                                             DieteticMenuPattern menuPattern,
                                             LocalDate startDate,
                                             LocalDate endDate)
    {
        final List<DieteticRecipe> computedRecipes = getDieteticRecipes(menuPattern, constraints);
        // Generate menu
        final List<DieteticMenuDay> generatedValidMenuDays = generateValidMenuDays(
            menuPattern,
            constraints,
            computedRecipes,
            startDate,
            endDate);
        final List<UserMeal> meals = generatedValidMenuDays.stream()
            .flatMap(menuDay -> menuDay.getMenus().stream())
            .collect(Collectors.toList());
        return new MealPlanning(meals);
    }

    private List<DieteticMenuDay> generateValidMenuDays(DieteticMenuPattern menuPattern,
                                                        List<DieteticConstraint> constraints,
                                                        List<DieteticRecipe> recipes,
                                                        LocalDate startDate,
                                                        LocalDate endDate)
    {
        log.debug(DieteticLogUtil.ALGO, "Entrée algo");
        final List<DieteticRecipe> recipesWithoutUsedRecipe = new ArrayList<>(recipes);
        final List<DieteticMenuDay> generatedValidMenuDays = new ArrayList<>(100);
        LocalDate date = startDate;
        for(int i = 0; date.isBefore(endDate) && i < TRYOUT_NUMBER ; i++) {
            final Optional<DieteticMenuDay> menuDay = getValidMenuDay(recipesWithoutUsedRecipe,
                constraints,
                menuPattern,
                date);
            if (!menuDay.isPresent()) continue;
            generatedValidMenuDays.add(menuDay.get());
            for (DieteticMenu menu : menuDay.get().getMenus()) recipesWithoutUsedRecipe.removeAll(menu.getRecipes());
            date = date.plusDays(1);
        }
        log.debug(DieteticLogUtil.ALGO, "Sortie algo -> "+generatedValidMenuDays.size()+" jours");
        return generatedValidMenuDays;
    }

    private Optional<DieteticMenuDay> getValidMenuDay(List<DieteticRecipe> recipesToUse,
                                                      List<DieteticConstraint> computedConstraints,
                                                      DieteticMenuPattern menuPattern,
                                                      LocalDate date)
    {
        final List<Long> menuTypesId = menuPattern.getMealTypesId();
        for(int i = 0; i < TRYOUT_NUMBER; i++) {
            final List<DieteticRecipe> recipesWithoutUsedRecipe = new ArrayList<>(recipesToUse);
            DieteticMenuDay menuDay = new DieteticMenuDay(date);
            for (Long menuTypeId : menuTypesId) {
                final Optional<DieteticMenu> menu = getValidMenu(recipesWithoutUsedRecipe,
                    computedConstraints,
                    menuPattern,
                    mealTypeRepository.findOne(menuTypeId),
                    date);
                if (!menu.isPresent()) return Optional.empty();
                menuDay.getMenus().add(menu.get());
                recipesWithoutUsedRecipe.removeAll(menu.get().getRecipes());
            }
            if (dieteticValidityService.isValid(menuDay, computedConstraints)) return Optional.of(menuDay);
        }
        return Optional.empty();
    }

    private Optional<DieteticMenu> getValidMenu(List<DieteticRecipe> recipesToUse,
                                                List<DieteticConstraint> computedConstraints,
                                                DieteticMenuPattern menuPattern,
                                                MealType mealType,
                                                LocalDate date)
    {
        final List<Long> recipeTypesId = menuPattern.getRecipeTypesId();
        for(int i = 0; i < TRYOUT_NUMBER; i++) {
            final List<DieteticRecipe> recipesWithoutUsedRecipe = new ArrayList<>(recipesToUse);
            final List<DieteticRecipe> dieteticRecipes = new ArrayList<>();
            for (Long recipeTypeId : recipeTypesId) {
                final List<DieteticRecipe> recipesToUseFilteredByType = dieteticRecipeService.getRecipeFilteredByRecipeTypesId(recipesWithoutUsedRecipe, recipeTypeId);
                final Optional<DieteticRecipe> recipe = getValidRecipe(recipesToUseFilteredByType, computedConstraints);
                if (!recipe.isPresent()) return Optional.empty();
                dieteticRecipes.add(recipe.get());
                recipesWithoutUsedRecipe.remove(recipe.get());
            }
            DieteticMenu dieteticMenu = new DieteticMenu(date, dieteticRecipes, mealType);
            if(dieteticValidityService.isValid(dieteticMenu, computedConstraints)) return Optional.of(dieteticMenu);
        }
        return Optional.empty();
    }

    private Optional<DieteticRecipe> getValidRecipe(List<DieteticRecipe> recipesToUse,
                                                    List<DieteticConstraint> computedConstraints)
    {
        for(int i = 0; i < TRYOUT_NUMBER; i++) {
            final Optional<DieteticRecipe> recipe = getRandomRecipe(recipesToUse);
            if (!recipe.isPresent()) return Optional.empty();
            if (dieteticValidityService.isValid(recipe.get(), computedConstraints)) return Optional.of(recipe.get());
        }
        return Optional.empty();
    }

    private Optional<DieteticRecipe> getRandomRecipe(List<DieteticRecipe> recipesToUse) {
        if (recipesToUse.isEmpty()) return Optional.empty();
        final int index = ThreadLocalRandom.current().nextInt(recipesToUse.size());
        return Optional.of(recipesToUse.get(index));
    }
}
