package com.alantaya.recipe.module.crm.zoho.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix="crm.zoho", ignoreUnknownFields = false)
public class ZohoProperties {

    private final Url url = new Url();
    private String scope;
    private String newFormat;
    private String multipleUpdateVersion;
    private Integer maxPartitionSize;
    private String authtoken;

    public Url getUrl() {
        return url;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getNewFormat() {
        return newFormat;
    }

    public void setNewFormat(String newFormat) {
        this.newFormat = newFormat;
    }

    public String getMultipleUpdateVersion() {
        return multipleUpdateVersion;
    }

    public void setMultipleUpdateVersion(String multipleUpdateVersion) {
        this.multipleUpdateVersion = multipleUpdateVersion;
    }

    public Integer getMaxPartitionSize() {
        return maxPartitionSize;
    }

    public void setMaxPartitionSize(Integer maxPartitionSize) {
        this.maxPartitionSize = maxPartitionSize;
    }

    public String getAuthtoken() {
        return authtoken;
    }

    public void setAuthtoken(String authtoken) {
        this.authtoken = authtoken;
    }

    public static class Url {

        private String base;
        private String contacts;
        private String insert;
        private String update;
        private String delete;
        private String searchByPDC;

        public String getBase() {
            return base;
        }

        public void setBase(String base) {
            this.base = base;
        }

        public String getContacts() {
            return contacts;
        }

        public void setContacts(String contacts) {
            this.contacts = contacts;
        }

        public String getInsert() {
            return insert;
        }

        public void setInsert(String insert) {
            this.insert = insert;
        }

        public String getUpdate() {
            return update;
        }

        public void setUpdate(String update) {
            this.update = update;
        }

        public String getDelete() {
            return delete;
        }

        public void setDelete(String delete) {
            this.delete = delete;
        }

        public String getSearchByPDC() {
            return searchByPDC;
        }

        public void setSearchByPDC(String searchByPDC) {
            this.searchByPDC = searchByPDC;
        }
    }
}



