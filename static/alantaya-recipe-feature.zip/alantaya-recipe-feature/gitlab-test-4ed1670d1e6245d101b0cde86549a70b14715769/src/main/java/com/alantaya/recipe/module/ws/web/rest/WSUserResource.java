package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.ws.service.WSUserService;
import com.alantaya.recipe.module.ws.web.rest.dto.UserDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.UserMapper;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.UserService;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/ws/v1")
@Api(value = "/users", description = "User definition")
public class WSUserResource {

    private final Logger log = LoggerFactory.getLogger(WSUserResource.class);

    @Inject private UserRepository userRepository;
    @Inject private WSUserService wsUserService;
    @Inject private UserMapper userMapper;
    @Inject private UserService userService;

    @ApiOperation(value = "", notes ="Create a <<User>>.\n" +
        "\n" +
        "IMPORTANT: Id must be null.\n" +
        "\n" +
        "IMPORTANT: Email must be unique.\n" +
        "\n" +
        "TIP: See <<Workflow>>.")
    @ApiResponses(value = {
        @ApiResponse(code = 201, message= "A new user is created"),
        @ApiResponse(code = 400, message = "A new user cannot already have an id"),
        @ApiResponse(code = 403, message = "Email address already in use or max licence number reached")
    })
    @RequestMapping(value = "/users",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<Void> createUser(@Valid @RequestBody UserDTO user) throws URISyntaxException {
        log.debug("REST request to save user : {}", user);
        if (user.getId() != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).header("Failure", "A new user cannot already have an ID").body(null);
        }
        if (userRepository.findOneByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).header("Failure", "Email address already in use").body(null);
        }
        User createdUser = wsUserService.createUser(
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber(),
                userService.getUser());
        if (createdUser == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).header("Failure", "Max licence number reached").body(null);
        }

        return ResponseEntity.created(new URI("/ws/v1/users/" + createdUser.getId())).build();
    }

    @ApiOperation(value = "", notes ="Update a <<User>>.\n" +
        "\n" +
        "IMPORTANT: Email must be unique.\n" +
        "\n" +
        "TIP: If id is null it will create a user")
    @ApiResponses(value = {
        @ApiResponse(code = 403, message = "Email address already in use")
    })
    @RequestMapping(value = "/users",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<Void> updateUser(@Valid @RequestBody UserDTO user) throws URISyntaxException {
        log.debug("REST request to update user : {}", user);
        if (user.getId() == null) {
            return createUser(user);
        }
        Optional<User> existingUserFromEmail = userRepository.findOneByEmail(user.getEmail());
        if (existingUserFromEmail.isPresent() && !existingUserFromEmail.get().getId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).header("Failure", "Email address already in use").body(null);
        }
        wsUserService.updateUser(existingUserFromEmail.get(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber(),
                userService.getUser());
        return ResponseEntity.ok().build();
    }

    @ApiOperation(value = "", notes ="Get all <<User>>.")
    @RequestMapping(value = "/users",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public List<UserDTO> getAllUsers() {
        log.debug("REST request to get all users");
        return userMapper.usersToUserDTOs(wsUserService.getAllUsers(userService.getUser()));
    }

    @ApiOperation(value = "", notes ="Get specified <<User>>.")
    @RequestMapping(value = "/users/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<UserDTO> getUser(@PathVariable Long id) {
        log.debug("REST request to get userDTO : {}", id);
        User supervisedUser = userRepository.findOne(id);
        if(supervisedUser == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(userMapper.userToUserDTO(supervisedUser), HttpStatus.OK);
    }

    @ApiOperation(value = "", notes ="Delete specified <<User>>.\n" +
        "\n" +
        "IMPORTANT: Deleting a user is irrevocable.")
    @RequestMapping(value = "/users/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public void deleteUser(@PathVariable Long id) {
        log.debug("REST request to delete user : {}", id);
        wsUserService.deleteUser(id, userService.getUser());
    }
}
