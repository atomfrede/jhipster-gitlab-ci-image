package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A Recipe.
 */
@Entity
@Table(name = "T_RECIPE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Recipe extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Size(max = 150)
    @Column(name = "title", length = 150, nullable = false)
    @JsonView(View.Minimal.class)
    private String title;

    @Size(max = 150)
    @Column(name = "summary", length = 150)
    @JsonView(View.Full.class)
    private String summary;

    @NotNull
    @Min(value = 1)
    @Column(name = "shares_number", nullable = false)
    @JsonView(View.Full.class)
    private Integer sharesNumber;

    @NotNull
    @Min(value = 0)
    @Column(name = "preparation_time", nullable = false)
    @JsonView(View.Full.class)
    private Integer preparationTime;

    @NotNull
    @Min(value = 0)
    @Column(name = "cooking_time", nullable = false)
    @JsonView(View.Full.class)
    private Integer cookingTime;

    @NotNull
    @Min(value = 0)
    @Column(name = "rest_time", nullable = false)
    @JsonView(View.Full.class)
    private Integer restTime;

    @Column(name = "better_prepared_in_advance")
    @JsonView(View.Full.class)
    private Boolean betterPreparedInAdvance;

    @Size(max = 200)
    @Column(name = "advice", length = 200)
    @JsonView(View.Full.class)
    private String advice;

    @Size(max = 2000)
    @Column(name = "source_url", length = 2000)
    @JsonView(View.Full.class)
    private String sourceUrl;

    @ManyToOne
    @JsonView(View.Summary.class)
    private RecipeType type;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_RECIPE_RECIPE_CATEGORIES",
               joinColumns = @JoinColumn(name="recipes_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="categoriess_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<RecipeCategory> categories = new HashSet<>();

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private CostLevel costLevel;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private DifficultyLevel difficultyLevel;

    @ManyToOne
    @JsonView(View.Full.class)
    private RecipeQuantityUnit quantityUnit;

    @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval=true)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.Full.class)
    private Set<FoodQuantityByRecipe> foodQuantities = new HashSet<>();

    @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval=true)
    @OrderBy("stepNumber ASC")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.Full.class)
    private Set<RecipeStep> steps = new HashSet<>();

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_RECIPE_COOKING_MODE",
               joinColumns = @JoinColumn(name="recipes_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="cookingModes_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<CookingMode> cookingModes = new HashSet<>();

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_RECIPE_RECIPE_DURABLE_LIFE",
               joinColumns = @JoinColumn(name="recipes_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="durableLifes_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<RecipeDurableLife> durableLifes = new HashSet<>();

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Season season;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Country originCountry;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Region originRegion;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_RECIPE_RECIPE_THEME",
               joinColumns = @JoinColumn(name="recipes_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="themes_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<RecipeTheme> themes = new HashSet<>();

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "T_RECIPE_RECIPE_PROFILE",
               joinColumns = @JoinColumn(name="recipes_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="recipeProfiles_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<RecipeProfile> recipeProfiles = new HashSet<>();

    @ManyToOne
    @JsonView(View.Summary.class)
    private RecipeState state;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Author author;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Editor editor;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonView(View.Full.class)
    private Image image;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Integer getSharesNumber() {
        return sharesNumber;
    }

    public void setSharesNumber(Integer sharesNumber) {
        this.sharesNumber = sharesNumber;
    }

    public Integer getPreparationTime() {
        return preparationTime;
    }

    public void setPreparationTime(Integer preparationTime) {
        this.preparationTime = preparationTime;
    }

    public Integer getCookingTime() {
        return cookingTime;
    }

    public void setCookingTime(Integer cookingTime) {
        this.cookingTime = cookingTime;
    }

    public Integer getRestTime() {
        return restTime;
    }

    public void setRestTime(Integer restTime) {
        this.restTime = restTime;
    }

    public Boolean getBetterPreparedInAdvance() {
        return betterPreparedInAdvance;
    }

    public void setBetterPreparedInAdvance(Boolean betterPreparedInAdvance) {
        this.betterPreparedInAdvance = betterPreparedInAdvance;
    }

    public String getAdvice() {
        return advice;
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public RecipeType getType() {
        return type;
    }

    public void setType(RecipeType recipeType) {
        this.type = recipeType;
    }

    public Set<RecipeCategory> getCategories() {
        return categories;
    }

    public void setCategories(Set<RecipeCategory> recipeCategories) {
        this.categories = recipeCategories;
    }

    public CostLevel getCostLevel() {
        return costLevel;
    }

    public void setCostLevel(CostLevel costLevel) {
        this.costLevel = costLevel;
    }

    public DifficultyLevel getDifficultyLevel() {
        return difficultyLevel;
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    public RecipeQuantityUnit getQuantityUnit() {
        return quantityUnit;
    }

    public void setQuantityUnit(RecipeQuantityUnit recipeQuantityUnit) {
        this.quantityUnit = recipeQuantityUnit;
    }

    public Set<FoodQuantityByRecipe> getFoodQuantities() {
        return foodQuantities;
    }

    public Set<RecipeStep> getSteps() {
        return steps;
    }

    public Set<CookingMode> getCookingModes() {
        return cookingModes;
    }

    public void setCookingModes(Set<CookingMode> cookingModes) {
        this.cookingModes = cookingModes;
    }

    public Set<RecipeDurableLife> getDurableLifes() {
        return durableLifes;
    }

    public void setDurableLifes(Set<RecipeDurableLife> recipeDurableLifes) {
        this.durableLifes = recipeDurableLifes;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public Country getOriginCountry() {
        return originCountry;
    }

    public void setOriginCountry(Country country) {
        this.originCountry = country;
    }

    public Region getOriginRegion() {
        return originRegion;
    }

    public void setOriginRegion(Region region) {
        this.originRegion = region;
    }

    public Set<RecipeTheme> getThemes() {
        return themes;
    }

    public void setThemes(Set<RecipeTheme> recipeThemes) {
        this.themes = recipeThemes;
    }

    public Set<RecipeProfile> getRecipeProfiles() {
        return recipeProfiles;
    }

    public void setRecipeProfiles(Set<RecipeProfile> recipeProfiles) {
        this.recipeProfiles = recipeProfiles;
    }

    public RecipeState getState() {
        return state;
    }

    public void setState(RecipeState recipeState) {
        this.state = recipeState;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public Editor getEditor() {
        return editor;
    }

    public void setEditor(Editor editor) {
        this.editor = editor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Recipe recipe = (Recipe) o;

        if ( ! Objects.equals(id, recipe.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Recipe{" +
                "id=" + id +
                ", title='" + title + "'" +
                ", summary='" + summary + "'" +
                ", sharesNumber='" + sharesNumber + "'" +
                ", preparationTime='" + preparationTime + "'" +
                ", cookingTime='" + cookingTime + "'" +
                ", restTime='" + restTime + "'" +
                ", betterPreparedInAdvance='" + betterPreparedInAdvance + "'" +
                ", advice='" + advice + "'" +
                ", sourceUrl='" + sourceUrl + "'" +
                '}';
    }
}
