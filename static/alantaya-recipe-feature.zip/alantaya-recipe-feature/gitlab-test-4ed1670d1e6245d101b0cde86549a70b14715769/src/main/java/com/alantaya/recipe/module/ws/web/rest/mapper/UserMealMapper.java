package com.alantaya.recipe.module.ws.web.rest.mapper;


import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.module.ws.web.rest.dto.UserMealDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring", uses = NutritionalRecipeMapper.class)
public interface UserMealMapper {

    @Mappings({
        @Mapping(source = "mealType.name", target = "type"),
        @Mapping(target = "nutritionalValue", ignore = true)
    })
    UserMealDTO userMealsToMealDayDTO(UserMeal meal);

}
