package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.module.ws.web.rest.dto.MealDayDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.MealDayMapper;
import com.alantaya.recipe.repository.UserMealRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.UserMealPlanningService;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import java.util.List;

/**
 * REST controller for managing BiometryDTO.
 */
@RestController
@RequestMapping("/ws/v1")
@Api(value = "/meal-planning")
public class WSMealPlanningResource {

    private final Logger log = LoggerFactory.getLogger(WSMealPlanningResource.class);

    private static final int MEAL_PLANNING_MAX_SIZE = 14;

    @Inject private UserRepository userRepository;
    @Inject private UserMealRepository userMealRepository;
    @Inject private UserMealPlanningService userMealPlanningService;
    @Inject private MealDayMapper mealDayMapper;

    @ApiOperation(value = "",
        notes ="Get meal planning for a specified user between dates.\n" +
            "\n" +
            "WARNING: We can display 14 days maximum")
    @RequestMapping(value = "/meal-planning/{userId}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional(readOnly = true)
    public ResponseEntity<List<MealDayDTO>> getMealPlanning(@ApiParam(value = "user id", required = true)
                                                @PathVariable Long userId,
                                            @ApiParam(value = "from max 14 days. ex: 2015-11-18", required = true)
                                                @RequestParam(value="from", required = true)
                                                @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate from,
                                            @ApiParam(value = "to max 14 days. ex: 2015-11-22", required = true)
                                                @RequestParam(value="to", required = true)
                                                @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate to) {
        log.debug("REST r for user: {}", userId);
        if (Days.daysBetween(from, to).getDays() > MEAL_PLANNING_MAX_SIZE)
            return new ResponseEntity<List<MealDayDTO>>(HttpStatus.BAD_REQUEST);

        User user = userRepository.findOne(userId);
        List<UserMeal> meals = userMealRepository.findByUserAndDateBetween(user, from, to);
        return ResponseEntity.ok(mealDayMapper.userMealsToMealDayDTOs(meals));
    }

    @ApiOperation(value = "",
        notes ="Reset and generate meal planning from now to 7 days, this operation takes some time. It " +
            "should be use when a user change a biometry or a criteria and wants to adapt his planning. You don't " +
            "need to generate each day, there is a scheduler that check every night if each user has a 7 days meals planning.\n" +
            "\n" +
            "IMPORTANT: Reset current meals and invalidate the user's shopping list.\n" +
            "\n" +
            "WARNING: The generation take time, depending of the complexity of the user profile.")
    @RequestMapping(value = "/meal-planning/{userId}/reset",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<Void> resetMealPlanning(@ApiParam(value = "userId", required = true)
                                             @PathVariable Long userId) {
        log.debug("REST request to add user criteria : {}", userId);
        User user = userRepository.findOne(userId);
        userMealPlanningService.regenerateMealPlanningFrom(user, LocalDate.now());
        return ResponseEntity.ok().build();
    }
}
