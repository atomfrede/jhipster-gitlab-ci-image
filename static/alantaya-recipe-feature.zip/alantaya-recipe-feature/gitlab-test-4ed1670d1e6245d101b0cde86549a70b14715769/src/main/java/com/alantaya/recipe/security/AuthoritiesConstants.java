package com.alantaya.recipe.security;

/**
 * Constants for Spring Security authorities.
 */
public final class AuthoritiesConstants {

    private AuthoritiesConstants() {
    }

    public static final String ADMIN = "ROLE_ADMIN";

    public static final String USER = "ROLE_USER";

    public static final String BLOGGER = "ROLE_BLOGGER";

    public static final String RECIPE_ADMIN = "ROLE_RECIPE_ADMIN";

    public static final String DIET_ADMIN = "ROLE_DIET_ADMIN";

    public static final String PRO = "ROLE_PRO";

    public static final String SUPERVISOR = "ROLE_SUPERVISOR";

    public static final String WS = "ROLE_WS";

    public static final String COM_ADMIN = "ROLE_COM_ADMIN";

    public static final String ANONYMOUS = "ROLE_ANONYMOUS";

    public static final String PRE_PAYMENT = "ROLE_PRE_PAYMENT";
}
