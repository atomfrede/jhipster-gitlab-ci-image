package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.lang.reflect.Method;


public class ContactXMLAdapter extends XmlAdapter<RowXML, Contact>{

    @Override
    public Contact unmarshal(RowXML rowXML) throws Exception {
        Contact contact = new Contact();
        contact.setNo(rowXML.getNo());
        rowXML.getFields()
            .stream()
            .forEach(cXML -> {
                switch(cXML.getName()) {
                    case "CONTACTID": contact.setZohoId(cXML.getValue()); break;
                    case "Email": contact.setEmail(cXML.getValue()); break;
                    case "First Name": contact.setFirstName(cXML.getValue()); break;
                    case "Last Name": contact.setLastName(cXML.getValue()); break;
                    case "Contact Owner": contact.setContactOwner(cXML.getValue()); break;
                    case "Account Name": contact.setAccountName(cXML.getValue()); break;
                    case "Created By": contact.setCreatedBy(cXML.getValue()); break;
                    case "Modified By": contact.setModifiedBy(cXML.getValue()); break;
                    case "Created Time": contact.setCreatedTime(cXML.getValue()); break;
                    case "Modified Time": contact.setModifiedTime(cXML.getValue()); break;
                    case "Last Activity Time": contact.setLastActivityTime(cXML.getValue()); break;
                    case "Type de Prospec": contact.setTypeDeProspect(cXML.getValue()); break;
                    case "Bilan diététique": contact.setBilanDietetique(cXML.getValue()); break;
                    case "Télé-conseil": contact.setTeleConseil(cXML.getValue()); break;
                }
            });
        return contact;
    }

    @Override
    public RowXML marshal(Contact contact) throws Exception {
        RowXML rowXML = new RowXML();
        for (Method m : contact.getClass().getMethods()) {
            //Add all the Field in RowXML via getters
            if (m.getName().startsWith("get") && m.getReturnType().equals(Field.class) && m.getParameterTypes().length == 0) {
                final Field field = (Field) m.invoke(contact);
                if(field != null) {
                    rowXML.getFields().add(field);
                }
            }
        }
        rowXML.setNo(contact.getNo());
        return rowXML;
    }
}
