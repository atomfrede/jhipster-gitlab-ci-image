package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.*;
import org.hibernate.annotations.Parameter;
import org.jasypt.hibernate4.type.EncryptedStringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserBiometricList.
 */
@Entity
@Table(name = "USER_BIOMETRIC_LIST")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@TypeDefs({
        @TypeDef(
                name="encryptedString",
                typeClass=EncryptedStringType.class,
                parameters= {
                        @Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
        })}
)
public class UserBiometricList implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "biometric_values", nullable = false, columnDefinition = "clob")
    @Type(type = "encryptedString")
    private String biometricValues;

    @OneToOne
    private User user;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBiometricValues() {
        return biometricValues;
    }

    public void setBiometricValues(String biometricValues) {
        this.biometricValues = biometricValues;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserBiometricList userBiometricList = (UserBiometricList) o;

        if ( ! Objects.equals(id, userBiometricList.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserBiometricList{" +
                "id=" + id +
                ", biometricValues='" + getBiometricValues() + "'" +
                '}';
    }
}
