package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.service.dto.DailyNutritionalValues;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@Service
public class UserNutritionalService {
    @Inject private UserService userService;
    @Inject private NutritionalService nutritionalService;

    @Transactional(readOnly = true)
    public List<DailyNutritionalValues> getMealsBasicNutritionalValuesList(DateTime from, DateTime to) {
        final User user = userService.getUser();
        return nutritionalService.getMealsBasicNutritionalValuesList(user, from, to);
    }

    @Transactional(readOnly = true)
    public Optional<DailyNutritionalValues> getOneDayMealsBasicNutritionalValues(LocalDate date) {
        final User user = userService.getUser();
        return nutritionalService.getOneDayMealsBasicNutritionalValues(user, date);
    }
}
