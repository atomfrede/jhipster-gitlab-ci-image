package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.RecipeType;
import com.alantaya.recipe.domain.Restaurant;
import com.alantaya.recipe.domain.RestaurantDish;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class DieteticRestaurantDish extends RestaurantDish implements DieteticStatistic {

    private RestaurantDish restaurantDish;
    private List<DieteticFood> dieteticFoods;

    public DieteticRestaurantDish(RestaurantDish restaurantDish) {
        this.restaurantDish = restaurantDish;
        dieteticFoods = restaurantDish.getFoods().stream()
            .map(DieteticFood::new)
            .collect(Collectors.toList());
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        return dieteticFoods.stream()
            .mapToDouble(dieteticFood -> dieteticFood.getQuantityFor(dieteticElement))
            .sum();
    }

    @Override
    public Long getId() {
        return restaurantDish.getId();
    }

    @Override
    public void setId(Long id) {
        restaurantDish.setId(id);
    }

    @Override
    public String getName() {
        return restaurantDish.getName();
    }

    @Override
    public void setName(String name) {
        restaurantDish.setName(name);
    }

    @Override
    public String getDescription() {
        return restaurantDish.getDescription();
    }

    @Override
    public void setDescription(String description) {
        restaurantDish.setDescription(description);
    }

    @Override
    public BigDecimal getPrice() {
        return restaurantDish.getPrice();
    }

    @Override
    public void setPrice(BigDecimal price) {
        restaurantDish.setPrice(price);
    }

    @Override
    public Set<Food> getFoods() {
        return restaurantDish.getFoods();
    }

    @Override
    public void setFoods(Set<Food> foods) {
        restaurantDish.setFoods(foods);
    }

    @Override
    public Restaurant getRestaurant() {
        return restaurantDish.getRestaurant();
    }

    @Override
    public void setRestaurant(Restaurant restaurant) {
        restaurantDish.setRestaurant(restaurant);
    }

    @Override
    public RecipeType getType() {
        return restaurantDish.getType();
    }

    @Override
    public void setType(RecipeType RecipeType) {
        restaurantDish.setType(RecipeType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticRestaurantDish dieteticRestaurantDish = (DieteticRestaurantDish) o;

        return restaurantDish.equals(dieteticRestaurantDish.restaurantDish);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), restaurantDish.getId());
    }

    @Override
    public String toString() {
        return "RestaurantDish {" +
            "id=" + restaurantDish.getId() +
            ", name='" + restaurantDish.getName() + "'" +
            ", description='" + restaurantDish.getDescription() + "'" +
            ", price='" + restaurantDish.getPrice() + "'" +
            '}';
    }
}
