package com.alantaya.recipe.module.ws.web.rest.mapper;


import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.module.ws.web.rest.dto.UserMealDTO;
import com.alantaya.recipe.service.NutritionalService;
import com.alantaya.recipe.service.dto.BasicNutritionalValues;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class NutritionalUserMealMapper {

    @Inject private UserMealMapper userMealMapper;
    @Inject private NutritionalValueMapper nutritionalValueMapper;
    @Inject private NutritionalService nutritionalService;

    public UserMealDTO userMealToMealDayDTO(UserMeal meal) {
        if (meal == null) return null;
        UserMealDTO userMealDTO = userMealMapper.userMealsToMealDayDTO(meal);
        List<Long> recipeIds = meal.getRecipes().stream().map(Recipe::getId).collect(Collectors.toList());
        Optional<BasicNutritionalValues> nutritionalValues = nutritionalService.getRecipesBasicNutritionalValues(recipeIds);
        userMealDTO.setNutritionalValue(
            nutritionalValueMapper.basicNutritionalValueToNutritionalValueDTO(nutritionalValues.get())
        );
        return userMealDTO;
    }

}
