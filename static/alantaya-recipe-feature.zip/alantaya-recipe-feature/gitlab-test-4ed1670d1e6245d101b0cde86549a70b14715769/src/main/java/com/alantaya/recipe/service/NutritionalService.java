package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.Nutriment;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserMeal;
import com.alantaya.recipe.repository.NutrimentRepository;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.repository.UserMealRepository;
import com.alantaya.recipe.service.dto.BasicNutritionalValues;
import com.alantaya.recipe.service.dto.DailyNutritionalValues;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.security.InvalidParameterException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class NutritionalService {
    @Inject private RecipeRepository recipeRepository;
    @Inject private UserMealRepository userMealRepository;
    @Inject private NutrimentRepository nutrimentRepository;

    @Transactional(readOnly = true)
    public List<DailyNutritionalValues> getMealsBasicNutritionalValuesList(User user, DateTime from, DateTime to) {
        List<UserMeal> userMeals = userMealRepository.findByUserAndDateBetween(user, from.toLocalDate(), to.toLocalDate());
        return getDailyNutritionalValues(userMeals);
    }

    @Transactional(readOnly = true)
    public Optional<BasicNutritionalValues> getRecipeBasicNutritionalValues(Long recipeId) {
        return getRecipesBasicNutritionalValues(Collections.singletonList(recipeId));
    }

    @Transactional(readOnly = true)
    public Optional<BasicNutritionalValues> getRecipesBasicNutritionalValues(Collection<Long> recipeIds) {
        final List<Recipe> recipes = recipeRepository.findByIdInForDieteticRecipe(recipeIds);
        if (recipes.isEmpty()) return Optional.empty();

        UserMeal meal = new UserMeal();
        meal.setRecipes(new HashSet<>(recipes));

        DieteticMenu menu = new DieteticMenu(meal);

        return Optional.of(createSuggestedBasicNutritionalValues(menu, LocalDate.now()));
    }

    @Transactional(readOnly = true)
    public Optional<DailyNutritionalValues> getOneDayMealsBasicNutritionalValues(User user, LocalDate date) {
        final List<UserMeal> userMeals = userMealRepository.findByUserAndDateBetween(user, date, date);
        if (userMeals.isEmpty()) return Optional.empty();
        if (userMeals.stream().map(UserMeal::getDate).distinct().count() > 1)
            throw new InvalidParameterException("Cannot compute several day, only one day can be computed");
        DieteticMenuDay dieteticMenuDay = new DieteticMenuDay(userMeals, date);
        return Optional.of(createDailyNutritionalValues(dieteticMenuDay));
    }

    private List<DailyNutritionalValues> getDailyNutritionalValues(List<UserMeal> userMeals) {
        final List<DieteticMenuDay> menuDays = new ArrayList<>();
        userMeals.stream()
            .collect(Collectors.groupingBy(UserMeal::getDate))
            .forEach((date, meals) -> menuDays.add(new DieteticMenuDay(meals, date)));

        return menuDays.stream()
            .map(this::createDailyNutritionalValues)
            .collect(Collectors.toList());
    }

    private DailyNutritionalValues createDailyNutritionalValues(DieteticMenuDay dieteticMenuDay) {
        return new DailyNutritionalValues(
            createSuggestedBasicNutritionalValues(dieteticMenuDay, dieteticMenuDay.getDate()),
            createActualBasicNutritionalValues(dieteticMenuDay, dieteticMenuDay.getDate())
        );
    }

    private BasicNutritionalValues createSuggestedBasicNutritionalValues(DieteticStatistic dieteticStatistic, LocalDate createdDate) {
        final DieteticNutriment calories = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.CALORIE_ID));
        final DieteticNutriment lipid = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.LIPIDE_ID));
        final DieteticNutriment protein = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.PROTEINE_ID));
        final DieteticNutriment glucide = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.GLUCIDE_ID));

        final Double kCaloriesValue = dieteticStatistic.getQuantityFor(calories);
        final Double lipidValue = dieteticStatistic.getQuantityFor(lipid);
        final Double proteinValue = dieteticStatistic.getQuantityFor(protein);
        final Double glucideValue = dieteticStatistic.getQuantityFor(glucide);

        return createBasicNutritionalValues(createdDate, kCaloriesValue, lipidValue, proteinValue, glucideValue);
    }

    private BasicNutritionalValues createActualBasicNutritionalValues(DieteticActualStatistic dieteticStatistic, LocalDate createdDate) {
        final DieteticNutriment calories = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.CALORIE_ID));
        final DieteticNutriment lipid = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.LIPIDE_ID));
        final DieteticNutriment protein = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.PROTEINE_ID));
        final DieteticNutriment glucide = new DieteticNutriment(nutrimentRepository.findOne(Nutriment.GLUCIDE_ID));

        final Double kCaloriesValue = dieteticStatistic.getActualQuantityFor(calories);
        final Double lipidValue = dieteticStatistic.getActualQuantityFor(lipid);
        final Double proteinValue = dieteticStatistic.getActualQuantityFor(protein);
        final Double glucideValue = dieteticStatistic.getActualQuantityFor(glucide);

        return createBasicNutritionalValues(createdDate, kCaloriesValue, lipidValue, proteinValue, glucideValue);
    }

    private BasicNutritionalValues createBasicNutritionalValues(LocalDate createdDate,
                                                                Double kCaloriesValue,
                                                                Double lipidValue,
                                                                Double proteinValue,
                                                                Double glucideValue) {
        final Double totalLPG = lipidValue + proteinValue + glucideValue;
        final Double lipidPercentageValue = lipidValue / totalLPG * 100;
        final Double proteinPercentageValue = proteinValue / totalLPG * 100;
        final Double glucidePercentageValue = glucideValue / totalLPG * 100;

        return new BasicNutritionalValues(
            createdDate,
            kCaloriesValue,
            lipidPercentageValue,
            proteinPercentageValue,
            glucidePercentageValue
        );
    }
}
