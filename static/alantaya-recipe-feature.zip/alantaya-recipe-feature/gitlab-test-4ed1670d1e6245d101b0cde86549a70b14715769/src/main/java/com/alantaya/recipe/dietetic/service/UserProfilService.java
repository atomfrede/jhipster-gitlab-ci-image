package com.alantaya.recipe.dietetic.service;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaProfiling;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.service.CriteriaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserProfilService {

    private final Logger log = LoggerFactory.getLogger(UserProfilService.class);

    @Inject
    private CriteriaService criteriaService;

    @Transactional(readOnly = true)
    public Optional<Criteria> getCriteriaFromUserProfile(Map<Long, UserBiometricValue> biometricValuesByBiometricId) {

        List<Criteria> profiles = criteriaService.getValidatedCriteriaProfil();

        if (profiles.isEmpty() || biometricValuesByBiometricId.isEmpty())
            return Optional.empty();

        List<Criteria> matchingProfils = getProfilesMatchingBiometricValues(profiles, biometricValuesByBiometricId);

        if (1 == matchingProfils.size()) {
            log.info("One matching profile : {}", matchingProfils.get(0));
            return Optional.of(matchingProfils.get(0));
        }

        if (matchingProfils.size() > 1) {
            log.warn("Several profiles matching (return first), {}", matchingProfils);
            return Optional.of(matchingProfils.get(0));
        }
        else if (matchingProfils.isEmpty()) log.error("No profile matching");
        return Optional.empty();
    }

    private List<Criteria> getProfilesMatchingBiometricValues(List<Criteria> profileCriterias, Map<Long, UserBiometricValue> biometricValuesByBiometricId) {
        return profileCriterias.stream()
            .filter(profileCriteria -> doesProfileMatchBiometrics(profileCriteria, biometricValuesByBiometricId))
            .collect(Collectors.toList());
    }

    private boolean doesProfileMatchBiometrics(Criteria criteriaProfil, Map<Long, UserBiometricValue> biometricValuesByBiometricId) {
        if (criteriaProfil.getCriteriaProfilings().isEmpty()) return false;
        return criteriaProfil.getCriteriaProfilings()
            .stream()
            .allMatch(criteriaProfiling -> doesBiometricsMatchConstraint(criteriaProfiling, biometricValuesByBiometricId));
    }

    private boolean doesBiometricsMatchConstraint(CriteriaProfiling constraint,
                                                  Map<Long, UserBiometricValue> biometricValuesByBiometricId)
    {
        Long constraintBiometricId = constraint.getBiometry().getId();

        if (Biometry.AGE_ID.equals(constraintBiometricId)) {
            UserBiometricValue birthdayValue = biometricValuesByBiometricId.get(Biometry.BIRTHDATE_ID);

            LocalDate quantity = Instant.ofEpochMilli(birthdayValue.getValue().longValue()).atZone(ZoneId.systemDefault()).toLocalDate();
            double ageValue = (double) LocalDate.now().getYear() - quantity.getYear();

            return doesValueMatchConstraint(ageValue, constraint);
        }
        else if(biometricValuesByBiometricId.containsKey(constraintBiometricId)) {
            UserBiometricValue value = biometricValuesByBiometricId.get(constraintBiometricId);
            return doesValueMatchConstraint(value.getValue(), constraint);
        }

        return true;
    }

    private boolean doesValueMatchConstraint(Double value, CriteriaProfiling constraint) {
        return (null == constraint.getMinQuantity() || value >= constraint.getMinQuantity())
                && (null == constraint.getMaxQuantity() || value <= constraint.getMaxQuantity());
    }
}
