package com.alantaya.recipe.service;

import com.alantaya.recipe.config.Constants;
import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.enumeration.UserState;
import com.alantaya.recipe.repository.AuthorRepository;
import com.alantaya.recipe.repository.CityRepository;
import com.alantaya.recipe.repository.PersistentTokenRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.security.SecurityUtils;
import com.alantaya.recipe.security.UserDetailsService;
import com.alantaya.recipe.service.util.RandomUtil;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Service class for managing users.
 */
@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(UserService.class);

    @Inject private Environment env;
    @Inject private PasswordEncoder passwordEncoder;
    @Inject private MailService mailService;
    @Inject private UserRepository userRepository;
    @Inject private PersistentTokenRepository persistentTokenRepository;
    @Inject private AuthorRepository authorRepository;
    @Inject private CityRepository cityRepository;
    @Inject private UserDetailsService userDetailsService;
    @Inject private SupervisionService supervisionService;
    @Inject private HttpServletRequest httpServletRequest;

    public void sendActivationEmail(String email) {
        if (StringUtils.isBlank(email)) return;
        userRepository.findOneByEmail(email)
            .filter(user -> UserState.PENDING.equals(user.getState()))
            .ifPresent(mailService::sendActivationEmail);
    }

    public void reloadUserAuthorities() {
        final Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        final UserDetails user = userDetailsService.loadUserByUsernameWithAuthorities(getUser().getEmail());

        Authentication newAuth = new UsernamePasswordAuthenticationToken(
            auth.getPrincipal(),
            auth.getCredentials(),
            user.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(newAuth);
    }

    public Optional<User> activateRegistration(String key) {
        log.debug("Activating user for activation key {}", key);
        userRepository.findOneByActivationKey(key)
            .map(user -> {
                // activate given user for the registration key.
                user.setState(UserState.ACTIVE);
                user.setActivationKey(null);
                userRepository.save(user);
                log.debug("Activated user: {}", user);
                return user;
            });
        return Optional.empty();
    }

    public Optional<User> completePasswordReset(String newPassword, String key) {
        log.debug("Reset user password for reset key {}", key);

        return userRepository.findOneByResetKey(key)
            .filter(user -> user.getResetDate().isAfter(DateTime.now().minusHours(24)))
            .map(user -> {
                user.setPassword(passwordEncoder.encode(newPassword));
                user.setResetKey(null);
                user.setResetDate(null);
                userRepository.save(user);
                return user;
            });
    }

    public Optional<User> requestPasswordReset(String mail) {

        return userRepository.findOneByEmail(mail)
            .filter(User::isActive)
            .map(user -> {
                user.setResetKey(RandomUtil.generateResetKey());
                user.setResetDate(DateTime.now());
                userRepository.save(user);
                return user;
            });
    }

    public User createUserInformation(String password, String firstName, String lastName, String email,
                                      String langKey, Long cityId, Authority authority, Long authorId,
                                      String partnerCode) {
        User newUser = new User();
        // new user get the ROLE_USER authority as default
        if (authority == null) authority = new Authority(AuthoritiesConstants.PRE_PAYMENT);
        Set<Authority> authorities = new HashSet<>();
        String encryptedPassword = passwordEncoder.encode(password);
        // new user gets initially a generated password
        newUser.setPassword(encryptedPassword);
        newUser.setFirstName(firstName);
        newUser.setLastName(lastName);
        newUser.setEmail(email);
        newUser.setLangKey(langKey);
        newUser.setCity(null != cityId ? cityRepository.findOne(cityId) : null);
        newUser.setPartnerCode(partnerCode);
        newUser.setAuthor(null != authorId ? authorRepository.findOne(authorId) : null);
        // new user gets registration key
        newUser.setActivationKey(RandomUtil.generateActivationKey());
        newUser.setZohoSynchronized(false);
        authorities.add(authority);
        newUser.setAuthorities(authorities);
        User userSaved = userRepository.save(newUser);

        log.debug("Created Information for User: {}", newUser);
        mailService.sendActivationEmail(userSaved);
        return userSaved;
    }

    public void updateUserInformation(String firstName, String lastName, Long cityId) {
        userRepository.findOneByEmail(SecurityUtils.getCurrentEmail()).ifPresent(u -> {
            u.setFirstName(firstName);
            u.setLastName(lastName);
            u.setCity(cityRepository.findOne(cityId));
            u.setZohoSynchronized(false);
            userRepository.save(u);
            log.debug("Changed Information for User: {}", u);
        });
    }

    public void changePassword(String password) {
        userRepository.findOneByEmail(SecurityUtils.getCurrentEmail()).ifPresent(u -> {
            String encryptedPassword = passwordEncoder.encode(password);
            u.setPassword(encryptedPassword);
            userRepository.save(u);
            log.debug("Changed password for User: {}", u);
        });
    }

    @Transactional
    public void sendNewOneTimePassword() {
        final User user = getUser();
        String digits = user.getOneTimePassword();
        DateTime lastLoginAttempt = user.getLastLoginAttempt();

        if (null == lastLoginAttempt || lastLoginAttempt.plusMinutes(10).isBeforeNow()) {
            digits = env.acceptsProfiles(Constants.SPRING_PROFILE_DEVELOPMENT)
                    ? "000000"
                    :SecurityUtils.generateKey();
            lastLoginAttempt = DateTime.now();
            user.setOneTimePassword(digits);
            user.setLastLoginAttempt(lastLoginAttempt);
            user.setZohoSynchronized(false);
            userRepository.save(user);
        }

        mailService.sendOneTimePassword(user, digits);
    }

    public boolean verifyOneTimePassword(String submitedPassword) {
        User user = getUser();
        if (null == submitedPassword || null == user.getOneTimePassword()) return false;

        DateTime lastLoginAttempt = user.getLastLoginAttempt();
        if (null == lastLoginAttempt || lastLoginAttempt.plusMinutes(10).isBeforeNow()) return false;

        if (! user.getOneTimePassword().equals(submitedPassword)) return false;

        reloadUserAuthorities();
        SecurityUtils.otpAuthenticate();
        return true;
    }

    @Transactional(readOnly = true)
    public User getUserWithAuthorities() {
        User currentUser = getUser();
        currentUser.getAuthorities().size(); // eagerly load the association
        return currentUser;
    }

    @Transactional(readOnly = true)
    public Optional<User> getUserWithAuthoritiesByEmail(String email) {
        return userRepository.findOneByEmail(email).map(u -> {
            u.getAuthorities().size();
            return u;
        });
    }


    @Transactional(readOnly = true)
    public User getUser() {
        User currentUser = userRepository.findOneByEmail(SecurityUtils.getCurrentEmail()).get();
        Optional<User> supervisedUser = supervisionService.getSupervisedUser(httpServletRequest.getCookies(), currentUser);
        if (supervisedUser.isPresent()) return supervisedUser.get();
        return currentUser;
    }

    @Transactional(readOnly = true)
    public List<User> getAllValidUser() {
        return userRepository.findAllByState(UserState.ACTIVE);
    }

    /**
     * Persistent Token are used for providing automatic authentication, they should be automatically deleted after
     * 30 days.
     * <p/>
     * <p>
     * This is scheduled to get fired everyday, at midnight.
     * </p>
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void removeOldPersistentTokens() {
        LocalDate now = new LocalDate();
        persistentTokenRepository.findByTokenDateBefore(now.minusMonths(1)).stream().forEach(token -> {
            log.debug("Deleting token {}", token.getSeries());
            User user = token.getUser();
            user.getPersistentTokens().remove(token);
            persistentTokenRepository.delete(token);
        });
    }

    @Transactional
    @Async
    public void setUserGenerationInProgress(User user, boolean isGenerationInProgress) {
        user.setIsGenerationInProgress(isGenerationInProgress);
        userRepository.save(user);
    }

    /**
     * Not activated users should be automatically deleted after 3 days.
     * <p/>
     * <p>
     * This is scheduled to get fired everyday, at 01:00 (am).
     * </p>
     */
    @Scheduled(cron = "0 0 1 * * ?")
    public void removeNotActivatedUsers() {
        DateTime now = new DateTime();
        List<User> users = userRepository.findAllByStateAndCreatedDateBefore(UserState.PENDING, now.minusDays(3));
        for (User user : users) {
            log.debug("Deleting not activated user {}", user.getEmail());
            user.setState(UserState.DELETED);
            userRepository.save(user);
        }
    }
}
