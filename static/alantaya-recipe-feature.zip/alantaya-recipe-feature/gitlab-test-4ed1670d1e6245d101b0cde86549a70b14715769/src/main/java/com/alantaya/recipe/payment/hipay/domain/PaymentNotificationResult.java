package com.alantaya.recipe.payment.hipay.domain;


import org.joda.time.LocalDate;

import java.util.HashMap;
import java.util.Map;

public class PaymentNotificationResult {
    private String operation;
    private String status;
    private LocalDate date;
    private String time;
    private Double origAmount;
    private String origCurrency;
    private String idForMerchant;
    private String emailClient;
    private String idClient;
    private Map<String, String> merchantDatas = new HashMap<>();
    private String cardCountry;
    private String ipCountry;
    private String transid;
    private String is3ds;
    private String paymentMethod;
    private String subscriptionId;
    private String paymentMeanExpirationDate;
    private String refProduct0;
    private String customerCountry;
    private String returnCode;
    private String returnDescriptionShort;
    private String returnDescriptionLong;

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Double getOrigAmount() {
        return origAmount;
    }

    public void setOrigAmount(Double origAmount) {
        this.origAmount = origAmount;
    }

    public String getOrigCurrency() {
        return origCurrency;
    }

    public void setOrigCurrency(String origCurrency) {
        this.origCurrency = origCurrency;
    }

    public String getIdForMerchant() {
        return idForMerchant;
    }

    public void setIdForMerchant(String idForMerchant) {
        this.idForMerchant = idForMerchant;
    }

    public String getEmailClient() {
        return emailClient;
    }

    public void setEmailClient(String emailClient) {
        this.emailClient = emailClient;
    }

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient;
    }

    public Map<String, String> getMerchantDatas() {
        return merchantDatas;
    }

    public void setMerchantDatas(Map<String, String> merchantDatas) {
        this.merchantDatas = merchantDatas;
    }

    public String getCardCountry() {
        return cardCountry;
    }

    public void setCardCountry(String cardCountry) {
        this.cardCountry = cardCountry;
    }

    public String getIpCountry() {
        return ipCountry;
    }

    public void setIpCountry(String ipCountry) {
        this.ipCountry = ipCountry;
    }

    public String getTransid() {
        return transid;
    }

    public void setTransid(String transid) {
        this.transid = transid;
    }

    public String getIs3ds() {
        return is3ds;
    }

    public void setIs3ds(String is3ds) {
        this.is3ds = is3ds;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getPaymentMeanExpirationDate() {
        return paymentMeanExpirationDate;
    }

    public void setPaymentMeanExpirationDate(String paymentMeanExpirationDate) {
        this.paymentMeanExpirationDate = paymentMeanExpirationDate;
    }

    public String getRefProduct0() {
        return refProduct0;
    }

    public void setRefProduct0(String refProduct0) {
        this.refProduct0 = refProduct0;
    }

    public String getCustomerCountry() {
        return customerCountry;
    }

    public void setCustomerCountry(String customerCountry) {
        this.customerCountry = customerCountry;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnDescriptionShort() {
        return returnDescriptionShort;
    }

    public void setReturnDescriptionShort(String returnDescriptionShort) {
        this.returnDescriptionShort = returnDescriptionShort;
    }

    public String getReturnDescriptionLong() {
        return returnDescriptionLong;
    }

    public void setReturnDescriptionLong(String returnDescriptionLong) {
        this.returnDescriptionLong = returnDescriptionLong;
    }

    @Override
    public String toString() {
        return "PaymentNotificationResult{" +
            "operation='" + operation + '\'' +
            ", status='" + status + '\'' +
            ", date='" + date + '\'' +
            ", time='" + time + '\'' +
            ", origAmount='" + origAmount + '\'' +
            ", origCurrency='" + origCurrency + '\'' +
            ", idForMerchant='" + idForMerchant + '\'' +
            ", emailClient='" + emailClient + '\'' +
            ", idClient='" + idClient + '\'' +
            ", merchantDatas='" + merchantDatas + '\'' +
            ", cardCountry='" + cardCountry + '\'' +
            ", ipCountry='" + ipCountry + '\'' +
            ", transid='" + transid + '\'' +
            ", is3ds='" + is3ds + '\'' +
            ", paymentMethod='" + paymentMethod + '\'' +
            ", subscriptionId='" + subscriptionId + '\'' +
            ", paymentMeanExpirationDate='" + paymentMeanExpirationDate + '\'' +
            ", refProduct='" + refProduct0 + '\'' +
            ", customerCountry='" + customerCountry + '\'' +
            ", returnCode='" + returnCode + '\'' +
            ", returnDescriptionShort='" + returnDescriptionShort + '\'' +
            ", returnDescriptionLong='" + returnDescriptionLong + '\'' +
            '}';
    }
}
