package com.alantaya.recipe.payment.hipay.service;


import com.alantaya.recipe.payment.hipay.domain.ButtonMode;
import com.alantaya.recipe.payment.hipay.domain.Order;
import com.alantaya.recipe.payment.hipay.domain.PaymentButton;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Base64;

@Service
public class HipayPaymentButtonService {

    @Inject
    private Environment env;

    public PaymentButton createMD5SignedPaymentButton(Order order) throws IOException {
        String strXml = getXmlOrder(order);
        String strBase64Xml = encodeXml(strXml);
        String sign = getSignKey(strBase64Xml);
        return createPaymentButton(strBase64Xml, sign);
    }

    private PaymentButton createPaymentButton(String strBase64Xml, String sign) {
        PaymentButton button = new PaymentButton(ButtonMode.B,
            Long.valueOf(env.getProperty("payment.hipay.websiteId")),
            sign,
            strBase64Xml,
            env.getProperty("payment.hipay.urlPost"));
        return button;
    }

    private String getSignKey(String strBase64Xml) {
        String strXmlAndSignKey = strBase64Xml + env.getProperty("payment.hipay.signKey");

        return new Md5PasswordEncoder().encodePassword(strXmlAndSignKey, null);
    }

    private String encodeXml(String strXml) {
        return new String(Base64.getEncoder().encode(strXml.getBytes()));
    }

    private String getXmlOrder(Order order) throws IOException {
        XmlMapper xmlMapper = getXmlMapper();

        StringWriter stringWriter = new StringWriter();
        xmlMapper.writeValue(stringWriter, order);

        return stringWriter.getBuffer().toString();
    }

    private XmlMapper getXmlMapper() {
        JacksonXmlModule module = new JacksonXmlModule();
        module.setXMLTextElementName("xml");
        XmlMapper xmlMapper = new XmlMapper(module);
        xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_1_1, true);
        xmlMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return xmlMapper;
    }

}
