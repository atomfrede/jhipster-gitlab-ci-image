package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.enumeration.JobType;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "user_professional_information")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class UserProfessionalInformation implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 200)
    @Column(name = "address", length = 200, nullable = false)
    private String address;

    @NotNull
    @Size(max = 20)
    @Column(name = "phone_number", length = 20, nullable = false)
    private String phoneNumber;

    @NotNull
    @Size(max = 100)
    @Column(name = "adeli_number", length = 100, nullable = false)
    private String adeliNumber;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "job_type", nullable = false)
    private JobType jobType;

    @NotNull
    @Size(max = 100)
    @Column(name = "job_number", length = 100, nullable = false)
    private String jobNumber;

    @NotNull
    @Size(max = 70)
    @Column(name = "diploma_name", length = 70, nullable = false)
    private String diplomaName;

    @NotNull
    @Column(name = "diploma_year", nullable = false)
    private Integer diplomaYear;

    @Size(max = 500)
    @Column(name = "comment", length = 500)
    private String comment;

    @NotNull
    @Column(name = "is_accept_cgu", nullable = false)
    private Boolean isAcceptCGU;

    @ManyToOne
    private City city;

    public UserProfessionalInformation() {}
    public UserProfessionalInformation(String address,
                                       City city,
                                       String phoneNumber,
                                       String adeliNumber,
                                       JobType jobType,
                                       String jobNumber,
                                       String diplomaName,
                                       Integer diplomaYear,
                                       String comment,
                                       Boolean isAcceptCGU) {
        this.address = address;
        this.city = city;
        this.phoneNumber = phoneNumber;
        this.adeliNumber = adeliNumber;
        this.jobType = jobType;
        this.jobNumber = jobNumber;
        this.diplomaName = diplomaName;
        this.diplomaYear = diplomaYear;
        this.comment = comment;
        this.isAcceptCGU = isAcceptCGU;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAdeliNumber() {
        return adeliNumber;
    }

    public void setAdeliNumber(String adeliNumber) {
        this.adeliNumber = adeliNumber;
    }

    public JobType getJobType() {
        return jobType;
    }

    public void setJobType(JobType jobType) {
        this.jobType = jobType;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getDiplomaName() {
        return diplomaName;
    }

    public void setDiplomaName(String diplomaName) {
        this.diplomaName = diplomaName;
    }

    public Integer getDiplomaYear() {
        return diplomaYear;
    }

    public void setDiplomaYear(Integer diplomaYear) {
        this.diplomaYear = diplomaYear;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getIsAcceptCGU() {
        return isAcceptCGU;
    }

    public void setIsAcceptCGU(Boolean isAcceptCGU) {
        this.isAcceptCGU = isAcceptCGU;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserProfessionalInformation userProfessionalInformation = (UserProfessionalInformation) o;

        if ( ! Objects.equals(id, userProfessionalInformation.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserProfessionalInformation{" +
            "id=" + id +
            ", address='" + address + "'" +
            ", phoneNumber='" + phoneNumber + "'" +
            ", adeliNumber='" + adeliNumber + "'" +
            ", jobType='" + jobType + "'" +
            ", jobNumber='" + jobNumber + "'" +
            ", diplomaName='" + diplomaName + "'" +
            ", diplomaYear='" + diplomaYear + "'" +
            ", comment='" + comment + "'" +
            ", isAcceptCGU='" + isAcceptCGU + "'" +
            '}';
    }
}
