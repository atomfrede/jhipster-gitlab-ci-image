package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.UserBiometricList;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Service
public class BiometricValueListSerializer {

    private final Logger log = LoggerFactory.getLogger(BiometricValueListSerializer.class);

    @Inject
    private ObjectMapper objectMapper;

    public List<UserBiometricValue> deserialize(String json) {
        if (null != json) {
            JavaType userBiometricListType = objectMapper.getTypeFactory().constructCollectionType(List.class, UserBiometricValue.class);
            try {
                return objectMapper.readValue(json, userBiometricListType);
            }
            catch (IOException jpe) {
                log.error("Unable to deserialize UserBiometricList : " + json);
            }
        }
        return new ArrayList<>();
    }

    public String serialize(Collection<UserBiometricValue> userBiometricValues) {
        try {
            return objectMapper.writeValueAsString(userBiometricValues);
        }
        catch (JsonProcessingException jpe) {
            log.error("Unable to serialize UserBiometricList : '" + userBiometricValues.toString() + "'");
        }
        return null;
    }

}
