package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.QuestionRelationship;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the QuestionRelationship entity.
 */
public interface QuestionRelationshipRepository extends JpaRepository<QuestionRelationship,Long> {

}
