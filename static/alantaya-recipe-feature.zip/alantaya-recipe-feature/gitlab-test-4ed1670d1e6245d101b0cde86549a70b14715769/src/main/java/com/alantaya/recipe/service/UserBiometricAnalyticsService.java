package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.service.dto.InvalidUserBiometricAnalytic;
import com.alantaya.recipe.service.dto.UserBiometricAnalytic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserBiometricAnalyticsService {
    private final Logger log = LoggerFactory.getLogger(UserBiometricAnalyticsService.class);

    @Inject private UserBiometricService userBiometricService;

    @Transactional(readOnly =  true)
    public List<UserBiometricAnalytic> getAllDifferenceWithTheBeforeValue() {
        final Map<Long, UserBiometricValue> beforeLastUserBiometricValues = userBiometricService.getAllBeforeLastUserBiometricValue();
        final Map<Long, UserBiometricValue> currentUserBiometricValues = userBiometricService.getLatestBiometricValueByBiometricId();
        return currentUserBiometricValues.values().stream()
            .filter(userBiometricValue -> beforeLastUserBiometricValues.containsKey(userBiometricValue.getBiometryId()))
            .map(currentUserBiometryValue -> getInternalDifferenceWithTheBeforeValue(currentUserBiometryValue, beforeLastUserBiometricValues.get(currentUserBiometryValue.getBiometryId())))
            .collect(Collectors.toList());
    }

    @Transactional(readOnly =  true)
    public UserBiometricAnalytic getDifferenceWithTheBeforeValue(Long biometryId) {
        final UserBiometricValue currentUserBiometricValue = userBiometricService.getBiometricValue(biometryId);
        final UserBiometricValue beforeLastUserBiometricValue = userBiometricService.getBeforeLastUserBiometricValue(biometryId);

        return getInternalDifferenceWithTheBeforeValue(currentUserBiometricValue, beforeLastUserBiometricValue);
    }

    private UserBiometricAnalytic getInternalDifferenceWithTheBeforeValue(UserBiometricValue currentUserBiometricValue,
                                                                          UserBiometricValue beforeLastUserBiometricValue) {
        if (currentUserBiometricValue == null || beforeLastUserBiometricValue == null) {
            return new InvalidUserBiometricAnalytic();
        }

        final Optional<Double> differencePercentage = getDifferencePercentage(
            currentUserBiometricValue.getValue(),
            beforeLastUserBiometricValue.getValue());

        final UserBiometricAnalytic userBiometricAnalytic;
        if (differencePercentage.isPresent()) {
            final Double differencePercentageValue = differencePercentage.get();
            final boolean isUp = differencePercentageValue > 0D;
            userBiometricAnalytic = new UserBiometricAnalytic(
                currentUserBiometricValue.getBiometryId(),
                Math.abs(differencePercentage.get()),
                beforeLastUserBiometricValue.getCreatedDate(),
                isUp,
                true
            );
        }
        else {
            userBiometricAnalytic = new InvalidUserBiometricAnalytic();
        }

        return userBiometricAnalytic;
    }

    private Optional<Double> getDifferencePercentage(Double actualValue, Double beforeValue) {
        if (actualValue == null || beforeValue == null) return Optional.empty();
        return  Optional.of((actualValue - beforeValue) / beforeValue * 100D);
    }
}
