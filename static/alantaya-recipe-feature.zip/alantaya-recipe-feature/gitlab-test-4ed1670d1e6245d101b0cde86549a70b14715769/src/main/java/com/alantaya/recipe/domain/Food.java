package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A Food.
 */
@Entity
@Table(name = "T_FOOD")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Food extends AbstractAuditingEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "name", length = 100, nullable = false)
    @JsonView(View.Minimal.class)
    private String name;

    @NotNull
    @Size(max = 300)
    @Column(name = "complete_name", length = 300, nullable = false)
    @JsonView(View.Minimal.class)
    private String completeName;

    @Size(max = 100)
    @Column(name = "piece_name", length = 100)
    @JsonView(View.Full.class)
    private String pieceName;

    @Column(name = "average_piece_weight")
    @JsonView(View.Full.class)
    private Double averagePieceWeight;

    @Column(name = "density")
    @JsonView(View.Full.class)
    private Double density;

    @NotNull
    @Column(name = "is_repetable_in_a_meal", nullable = false)
    @JsonView(View.Full.class)
    private Boolean isRepetableInAMeal;

    @Column(name = "is_hidden_in_shopping_list")
    @JsonView(View.Full.class)
    private Boolean isHiddenInShoppingList;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonView(View.Minimal.class)
    private FoodFamily foodFamily;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonView(View.Summary.class)
    private FoodSection foodSection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonView(View.Summary.class)
    private FoodState foodState;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "FOOD_FOODTAG",
               joinColumns = @JoinColumn(name="food_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="foodtag_id", referencedColumnName="ID"))
    @JsonView(View.Full.class)
    private Set<FoodTag> tags = new HashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonView(View.Full.class)
    private Unit favoriteUnit;

    @OneToMany(mappedBy = "food", cascade = CascadeType.ALL, orphanRemoval=true)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JsonView(View.Full.class)
    private Set<NutrimentPerFood> nutrimentQuantitys = new HashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonView(View.Summary.class)
    private BasicFood basicFood;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompleteName() {
        return completeName;
    }

    public void setCompleteName(String completeName) {
        this.completeName = completeName;
    }

    public String getPieceName() {
        return pieceName;
    }

    public void setPieceName(String pieceName) {
        this.pieceName = pieceName;
    }

    public Double getAveragePieceWeight() {
        return averagePieceWeight;
    }

    public void setAveragePieceWeight(Double averagePieceWeight) {
        this.averagePieceWeight = averagePieceWeight;
    }

    public Double getDensity() {
        return density;
    }

    public void setDensity(Double density) {
        this.density = density;
    }

    public Boolean getIsRepetableInAMeal() {
        return isRepetableInAMeal;
    }

    public void setIsRepetableInAMeal(Boolean isRepetableInAMeal) {
        this.isRepetableInAMeal = isRepetableInAMeal;
    }

    public Boolean getIsHiddenInShoppingList() {
        return isHiddenInShoppingList;
    }

    public void setIsHiddenInShoppingList(Boolean isHiddenInShoppingList) {
        this.isHiddenInShoppingList = isHiddenInShoppingList;
    }

    public FoodFamily getFoodFamily() {
        return foodFamily;
    }

    public void setFoodFamily(FoodFamily foodFamily) {
        this.foodFamily = foodFamily;
    }

    public FoodSection getFoodSection() {
        return foodSection;
    }

    public void setFoodSection(FoodSection foodSection) {
        this.foodSection = foodSection;
    }

    public FoodState getFoodState() {
        return foodState;
    }

    public void setFoodState(FoodState foodState) {
        this.foodState = foodState;
    }

    public Unit getFavoriteUnit() {
        return favoriteUnit;
    }

    public void setFavoriteUnit(Unit Unit) {
        this.favoriteUnit = Unit;
    }

    public Set<NutrimentPerFood> getNutrimentQuantitys() {
        return nutrimentQuantitys;
    }

    public void setNutrimentQuantitys(Set<NutrimentPerFood> NutrimentPerFoods) {
        this.nutrimentQuantitys = NutrimentPerFoods;
    }

    public BasicFood getBasicFood() {
        return basicFood;
    }

    public void setBasicFood(BasicFood basicFood) {
        this.basicFood = basicFood;
    }

    public Set<FoodTag> getTags() {
        return tags;
    }

    public void setTags(Set<FoodTag> tags) {
        this.tags = tags;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || ! (o instanceof Food)) {
            return false;
        }

        Food food = (Food) o;

        if ( null != id && Objects.equals(id, food.id)) return true;
        if ( ! Objects.equals(name, food.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Food{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", completeName='" + completeName + "'" +
                ", pieceName='" + pieceName + "'" +
                ", averagePieceWeight='" + averagePieceWeight + "'" +
                ", density='" + density + "'" +
                ", isRepetableInAMeal='" + isRepetableInAMeal + "'" +
                ", isHiddenInShoppingList='" + isHiddenInShoppingList + "'" +
                '}';
    }
}
