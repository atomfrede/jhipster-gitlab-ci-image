package com.alantaya.recipe.domain;

import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Nutriment.
 */
@Entity
@Table(name = "T_NUTRIMENT")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class Nutriment extends AbstractAuditingEntity implements Serializable {
    public static final Long LIPIDE_ID = 40000L;
    public static final Long PROTEINE_ID = 25000L;
    public static final Long GLUCIDE_ID = 31000L;
    public static final Long CALORIE_ID = 328L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 30)
    @Column(name = "name", length = 30, nullable = false)
    private String name;

    @ManyToOne
    private NutrimentFamily nutrimentFamily;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public NutrimentFamily getNutrimentFamily() {
        return nutrimentFamily;
    }

    public void setNutrimentFamily(NutrimentFamily nutrimentFamily) {
        this.nutrimentFamily = nutrimentFamily;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || ! (o instanceof Nutriment)) {
            return false;
        }

        Nutriment nutriment = (Nutriment) o;

        if ( ! Objects.equals(id, nutriment.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Nutriment{" +
                "id=" + id +
                ", name='" + name + "'" +
                '}';
    }
}
