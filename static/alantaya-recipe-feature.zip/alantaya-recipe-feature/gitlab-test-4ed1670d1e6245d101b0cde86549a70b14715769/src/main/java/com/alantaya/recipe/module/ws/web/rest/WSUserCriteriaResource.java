package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.ws.service.WSUserCriteriaService;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URISyntaxException;
import java.util.List;

@RestController
@RequestMapping("/ws/v1")
@Api(value = "/users")
public class WSUserCriteriaResource {

    private final Logger log = LoggerFactory.getLogger(WSUserCriteriaResource.class);

    @Inject private UserRepository userRepository;
    @Inject private WSUserCriteriaService wsUserCriteriaService;

    @ApiOperation(value = "", notes ="Add a <<Criteria>> to a specified user.")
    @RequestMapping(value = "/users/{id}/criteria/{criteriaId}",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<Void> addUserCriteria(@ApiParam(value = "User id", required = true)
                                                @PathVariable Long id,
                                                @ApiParam(value = "Criteria id", required = true)
                                                @PathVariable Long criteriaId)
        throws URISyntaxException {
        log.debug("REST request to add user criteria : {}", criteriaId);
        User user = userRepository.findOne(id);
        wsUserCriteriaService.addUserCriteria(criteriaId, user);
        return ResponseEntity.ok().build();

    }

    @ApiOperation(value = "", notes ="Get all the <<Criteria>> of a specified user.")
    @RequestMapping(value = "/users/{id}/criteria",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public List<Long> getAllUserCriteria(@ApiParam(value = "User id", required = true) @PathVariable Long id) {
        log.debug("REST request to get all user biometrics for user: {}", id);
        User user = userRepository.findOne(id);
        return wsUserCriteriaService.getUserCriteriaIds(user);
    }

    @ApiOperation(value = "", notes ="Delete a <<Criteria>> to a specified user.")
    @RequestMapping(value = "/users/{id}/criteria/{criteriaId}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public void deleteUserCriteria(@ApiParam(value = "User id", required = true)
                                   @PathVariable Long id,
                                   @ApiParam(value = "Criteria id", required = true)
                                   @PathVariable Long criteriaId)
        throws URISyntaxException {
        log.debug("REST request to delete user criteria : user -> {}, criteriaId -> {}", id, criteriaId);
        User user = userRepository.findOne(id);
        wsUserCriteriaService.deleteUserCriteria(criteriaId, user);
    }
}
