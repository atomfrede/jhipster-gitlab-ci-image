package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.module.ws.web.rest.dto.FoodDTO;
import com.alantaya.recipe.web.rest.dto.ShoppingListItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring", uses = {})
public abstract class ShoppingListMapper {

    public abstract List<FoodDTO> shoppingListItemsToFoodDTOs(List<ShoppingListItem> shoppingListItems);

    @Mapping(target = "section", source = "foodSection.name")
    public abstract FoodDTO shoppingListItemToFoodDTO(ShoppingListItem shoppingListItem);
}
