package com.alantaya.recipe.dietetic.setup.constraint;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticFood;
import com.alantaya.recipe.domain.CriteriaType;
import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.repository.NutrimentRepository;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DislikedFoodsToConstraints {
    @Inject NutrimentRepository nutrimentRepository;

    public List<DieteticConstraint> setUp(List<DieteticConstraint> constraintsToCompute, List<Food> dislikedFoods) {
        if (dislikedFoods == null || dislikedFoods.isEmpty()) return constraintsToCompute;

        final List<DieteticConstraint> dislikedFoodConstraints = dislikedFoods.stream()
            .map(this::createDislikedFoodConstraint)
            .collect(Collectors.toList());
        constraintsToCompute.addAll(dislikedFoodConstraints);
        return constraintsToCompute;
    }

    private DieteticConstraint createDislikedFoodConstraint(Food food) {
        final DieteticFood dieteticFood = new DieteticFood(food);
        return new DieteticConstraint(
            null,
            dieteticFood,
            CriteriaType.PROFILE_ID,
            null,
            null,
            0D);
    }
}
