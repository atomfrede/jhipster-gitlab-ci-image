package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeTheme;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeTheme entity.
 */
public interface RecipeThemeRepository extends JpaRepository<RecipeTheme,Long> {

}
