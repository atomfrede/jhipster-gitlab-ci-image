package com.alantaya.recipe.payment.hipay.domain;

public class ButtonMode {

    public static final String B = "MODE_B";
    public static final String C = "MODE_C";

}
