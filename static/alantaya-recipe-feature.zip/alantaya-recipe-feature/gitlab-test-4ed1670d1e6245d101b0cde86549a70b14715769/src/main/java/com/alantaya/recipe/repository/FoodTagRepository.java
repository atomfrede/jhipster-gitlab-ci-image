package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.FoodTag;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the FoodTag entity.
 */
public interface FoodTagRepository extends JpaRepository<FoodTag,Long> {

}
