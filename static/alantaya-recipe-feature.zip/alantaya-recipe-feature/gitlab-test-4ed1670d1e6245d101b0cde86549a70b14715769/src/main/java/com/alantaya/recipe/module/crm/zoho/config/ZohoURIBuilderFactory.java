package com.alantaya.recipe.module.crm.zoho.config;

public class ZohoURIBuilderFactory {

    private final String zohoBaseUrl;
    private final String authtoken;
    private final String scope;
    private final String newFormat;
    private final String multipleUpdateVersion;

    public ZohoURIBuilderFactory(String zohoBaseUrl,
                                 String authtoken,
                                 String scope,
                                 String newFormat,
                                 String multipleUpdateVersion) {
        this.zohoBaseUrl = zohoBaseUrl;
        this.authtoken = authtoken;
        this.scope = scope;
        this.newFormat = newFormat;
        this.multipleUpdateVersion = multipleUpdateVersion;
    }

    public ZohoURIBuilder createZohoURIBuilder(){
        return new ZohoURIBuilder(
            this.zohoBaseUrl,
            this.authtoken,
            this.scope,
            this.newFormat
        );
    }

    public ZohoURIBuilder createZohoURIBuilderForMultipleInsert(){
        return new ZohoURIBuilder(
            this.zohoBaseUrl,
            this.authtoken,
            this.scope,
            this.newFormat,
            this.multipleUpdateVersion
        );
    }
}
