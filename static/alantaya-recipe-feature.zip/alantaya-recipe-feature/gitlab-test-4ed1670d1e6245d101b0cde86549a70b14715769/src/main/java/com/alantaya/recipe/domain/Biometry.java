package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Biometry.
 */
@Entity
@Table(name = "BIOMETRY")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Biometry extends AbstractAuditingEntity implements Serializable {

    public final static Long WEIGHT_ID = 1L;
    public final static Long SIZE_ID = 8L;
    public final static Long SEXE_ID = 9L;
    public final static Long BIRTHDATE_ID = 11L;
    public final static Long CALORIES_ID = 12L;
    public final static Long CHOLESTEROL_ID = 13L;
    public final static Long ACTIVITY_ID = 14L;
    public final static Long ENERGY_ID = 15L;
    public final static Long BMI_ID = 16L;
    public final static Long AGE_ID = 17L;
    public final static Long PREGNANTE_ID = 18L;
    public final static Long BREASTFEEDING_ID = 19L;
    public final static Long MENOPAUSE_ID = 20L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 70)
    @Column(name = "name", length = 70, nullable = false)
    private String name;

    @Size(max = 150)
    @Column(name = "description", length = 150)
    private String description;

    @ManyToOne
    private Unit unit;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Unit getUnit() {
        return unit;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Biometry biometry = (Biometry) o;

        if ( ! Objects.equals(id, biometry.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Biometry{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", description='" + description + "'" +
                '}';
    }
}
