package com.alantaya.recipe.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A RelationType.
 */
@Entity
@Table(name = "USER_QUESTIONNAIRE_STATE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class UserQuestionnaireState implements Serializable {

    private final static String STR_TODO = "TODO";
    private final static String STR_PAUSED = "PAUSED";
    private final static String STR_DONE = "DONE";

    public final static UserQuestionnaireState TODO = new UserQuestionnaireState(STR_TODO);
    public final static UserQuestionnaireState PAUSED = new UserQuestionnaireState(STR_PAUSED);
    public final static UserQuestionnaireState DONE = new UserQuestionnaireState(STR_DONE);

    @Id
    @NotNull
    @Size(max = 20)
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    public UserQuestionnaireState() {
    }

    public UserQuestionnaireState(String name) {
        this();
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserQuestionnaireState relationType = (UserQuestionnaireState) o;

        if ( ! Objects.equals(name, relationType.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name);
    }

    @Override
    public String toString() {
        return "UserQuestionnaireState{" +
                "name='" + name + "'" +
                '}';
    }
}
