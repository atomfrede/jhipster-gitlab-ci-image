package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.module.ws.web.rest.dto.RecipeDTO;
import com.alantaya.recipe.service.NutritionalService;
import com.alantaya.recipe.service.dto.BasicNutritionalValues;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class NutritionalRecipeMapper {

    @Inject private RecipeMapper recipeMapper;
    @Inject private NutritionalValueMapper nutritionalValueMapper;
    @Inject private NutritionalService nutritionalService;

    public RecipeDTO recipeToRecipeDTO(Recipe recipe) {
        if (recipe == null) return null;
        RecipeDTO recipeDTO = recipeMapper.recipeToRecipeDTO(recipe);
        Optional<BasicNutritionalValues> basicNutritionalValues = nutritionalService.getRecipeBasicNutritionalValues(recipe.getId());
        recipeDTO.setNutritionalValue(
            nutritionalValueMapper.basicNutritionalValueToNutritionalValueDTO(basicNutritionalValues.get())
        );
        return recipeDTO;
    }

    public List<RecipeDTO> recipesToRecipeDTOs(Collection<Recipe> recipes) {
        if (recipes == null) return null;
        return recipes.stream()
            .map(this::recipeToRecipeDTO)
            .collect(Collectors.toList());
    }

}
