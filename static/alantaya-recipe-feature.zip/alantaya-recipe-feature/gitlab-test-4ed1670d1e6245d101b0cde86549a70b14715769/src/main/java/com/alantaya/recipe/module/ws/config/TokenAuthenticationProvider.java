package com.alantaya.recipe.module.ws.config;

import com.alantaya.recipe.service.UserTokenService;
import com.google.common.base.Optional;
import org.jasypt.exceptions.EncryptionOperationNotPossibleException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

public class TokenAuthenticationProvider implements AuthenticationProvider {

    private UserTokenService userTokenService;

    public TokenAuthenticationProvider(UserTokenService userTokenService) {
        this.userTokenService = userTokenService;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        Optional<String> token = (Optional) authentication.getPrincipal();

        try {
            UserDetails user = userTokenService.retrieve(token.get());

            if (null == user) throw new BadCredentialsException("Invalid token");

            return new UsernamePasswordAuthenticationToken(
                user,
                null,
                user.getAuthorities()
            );

        } catch (EncryptionOperationNotPossibleException | UsernameNotFoundException exception) {
            throw new BadCredentialsException("Invalid token", exception);
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(PreAuthenticatedAuthenticationToken.class);
    }
}
