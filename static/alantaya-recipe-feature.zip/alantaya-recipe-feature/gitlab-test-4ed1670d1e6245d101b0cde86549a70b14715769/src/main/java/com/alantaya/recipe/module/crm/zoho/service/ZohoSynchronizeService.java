package com.alantaya.recipe.module.crm.zoho.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.crm.zoho.config.ZohoProperties;
import com.alantaya.recipe.module.crm.zoho.domain.Contact;
import com.alantaya.recipe.module.crm.zoho.domain.ContactMapper;
import com.alantaya.recipe.module.crm.zoho.repository.ContactRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.service.util.CollectionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service de synchronisation des Users vers Zoho CRM
 */
@Service
public class ZohoSynchronizeService {

    private final Logger log = LoggerFactory.getLogger(ZohoSynchronizeService.class);

    @Inject private ZohoUserService zohoUserService;
    @Inject private UserRepository userRepository;
    @Inject private ContactRepository contactRepository;
    @Inject private ContactMapper contactMapper;
    @Inject private ZohoProperties zohoProperties;

    /**
     * Envoie les nouveaux utilisateurs vers Zoho
     */
    public void synchronizedCreatedUsers() {
        log.debug("Send new users to Zoho");
        List<User> users = userRepository.findByIsZohoSynchronizedFalseAndZohoIdIsNull();
        CollectionUtil.partition(users, zohoProperties.getMaxPartitionSize()).forEach(
            usersPartition -> synchronizedCreatedUsersPartition(usersPartition)
        );
    }

    private void synchronizedCreatedUsersPartition(List<User> users) {
        List<Contact> contacts = contactMapper.usersToContacts(users);
        try {
            List<Contact> savedContacts = contactRepository.save(contacts);
            updateUsersFromContacts(users, savedContacts);
        }
        catch (Exception e) {
            log.error("Error while sending Zoho contact -> {}", e.getMessage());
        }
    }

    private void updateUsersFromContacts(List<User> users, List<Contact> contacts) {
        Map<String, Long> zohoIdByEmail = contacts.stream()
            .collect(Collectors.toMap(contact -> contact.getEmail().getValue(),
                contact -> Long.valueOf(contact.getZohoId().getValue())));
        updateUserZohoIdAndZohoSynchronizedTrue(users, zohoIdByEmail);
    }

    private void updateUserZohoIdAndZohoSynchronizedTrue(List<User> users, Map<String, Long> zohoIdByEmail) {
        zohoUserService.setUserZohoIdAndZohoSynchronizedTrue(zohoIdByEmail);
    }

    /**
     * Envoie les utilisateurs mis à jour vers Zoho
     */
    public void synchronizedUpdatedUsers() {
        log.debug("Send updated users to Zoho");
        List<User> users = userRepository.findByIsZohoSynchronizedFalseAndZohoIdIsNotNull();
        CollectionUtil.partition(users, zohoProperties.getMaxPartitionSize()).forEach(
            usersPartition -> synchronizedUpdatedUsersPartition(usersPartition)
        );
    }

    private void synchronizedUpdatedUsersPartition(List<User> users) {
        List<Contact> contacts = contactMapper.usersToContacts(users);
        try {
            contactRepository.update(contacts);
            zohoUserService.setUserZohoSynchronizedTrue(
                users.stream().map(User::getEmail).collect(Collectors.toList())
            );
        }
        catch (Exception e) {
            log.error("Error while sending Zoho contact -> {}", e.getMessage());
        }
    }

}
