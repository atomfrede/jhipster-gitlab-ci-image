package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.CookingMode;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the CookingMode entity.
 */
public interface CookingModeRepository extends JpaRepository<CookingMode,Long> {

}
