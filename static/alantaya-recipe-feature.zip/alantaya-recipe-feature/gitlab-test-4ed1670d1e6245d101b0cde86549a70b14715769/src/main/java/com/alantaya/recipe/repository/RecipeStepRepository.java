package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeStep;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeStep entity.
 */
public interface RecipeStepRepository extends JpaRepository<RecipeStep,Long> {

}
