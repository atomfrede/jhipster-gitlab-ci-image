package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.adapters.XmlAdapter;


public class RecordDetailXMLAdapter extends XmlAdapter<RowXML, RecordDetail>{

    @Override
    public RecordDetail unmarshal(RowXML rowXML) throws Exception {
        RecordDetail recordDetail = new RecordDetail();
        rowXML.getFields()
            .stream()
            .forEach(cXML -> {
                switch(cXML.getName()) {
                    case "Id": recordDetail.setId(cXML.getValue()); break;
                    case "Created By": recordDetail.setCreatedBy(cXML.getValue()); break;
                    case "Modified By": recordDetail.setModifiedBy(cXML.getValue()); break;
                    case "Created Time": recordDetail.setCreatedTime(cXML.getValue()); break;
                    case "Modified Time": recordDetail.setModifiedTime(cXML.getValue()); break;
                }
            });
        return recordDetail;
    }

    @Override
    public RowXML marshal(RecordDetail v) throws Exception {
        return null;
    }
}
