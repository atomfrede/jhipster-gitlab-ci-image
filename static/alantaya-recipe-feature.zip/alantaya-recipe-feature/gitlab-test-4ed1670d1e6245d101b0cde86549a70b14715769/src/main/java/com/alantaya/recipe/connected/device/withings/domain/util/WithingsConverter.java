package com.alantaya.recipe.connected.device.withings.domain.util;

import com.alantaya.recipe.connected.device.withings.domain.Measure;
import com.alantaya.recipe.connected.device.withings.domain.MeasureGroup;
import com.alantaya.recipe.connected.device.withings.domain.MeasureResult;
import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.UserBiometricValue;
import com.alantaya.recipe.domain.enumeration.BiometricValueSource;
import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class WithingsConverter {

    public List<UserBiometricValue> measureResultToWeightUserBiometricList(MeasureResult measureResult) {
        if (measureResult == null) return Collections.emptyList();

        return measureResult.getMeasureGroups().stream()
                .map(this::measureGroupToWeightUserBiometric)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public UserBiometricValue measureGroupToWeightUserBiometric(MeasureGroup measureGroup) {
        if (measureGroup == null) return null;
        final DateTime createdDate = measureGroup.getDate();

        return measureGroup.getMeasures().stream()
                .filter(this::isWeightType)
                .map(measure -> measureToWeightUserBiometric(measure, createdDate))
                .findFirst().orElse(null);
    }

    public UserBiometricValue measureToWeightUserBiometric(Measure measure, DateTime createdDate) {
        if (measure == null || !isWeightType(measure)) return null;
        if (createdDate == null) createdDate = DateTime.now();

        final UserBiometricValue userWeightBiometricValue = new UserBiometricValue(createdDate,
                Biometry.WEIGHT_ID,
                measure.getActualValue(),
                BiometricValueSource.WITHINGS);

        return userWeightBiometricValue;
    }

    private boolean isWeightType(Measure measure) {
        return Measure.TYPE_WEIGHT.equals(measure.getType());
    }
}
