package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.FoodFamilyGroup;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the FoodFamilyGroup entity.
 */
public interface FoodFamilyGroupRepository extends JpaRepository<FoodFamilyGroup,Long> {

}
