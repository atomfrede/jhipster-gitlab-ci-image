package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.module.ws.web.rest.dto.CriteriaDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.CriteriaMapper;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing BiometryDTO.
 */
@RestController
@RequestMapping("/ws/v1")
@Api(value = "/criteria")
public class WSCriteriaResource {

    @Inject
    private CriteriaMapper criteriaMapper;

    @Inject
    private CriteriaRepository criteriaRepository;

    private final Logger log = LoggerFactory.getLogger(WSCriteriaResource.class);

    @ApiOperation(value = "", notes = "Get all definitions of a <<Criteria>>.")
    @RequestMapping(value = "/criteria",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @Transactional(readOnly = true)
    @RolesAllowed(AuthoritiesConstants.WS)
    public List<CriteriaDTO> getAllCriteria() {
        log.debug("REST request to get all criteria");
        return criteriaMapper.criteriaListToCriteriaDTOList(criteriaRepository.findAll());
    }

    @ApiOperation(value = "", notes = "Get definition of a <<Criteria>> by id.")
    @RequestMapping(value = "/criteria/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @Transactional(readOnly = true)
    @RolesAllowed(AuthoritiesConstants.WS)
    public ResponseEntity<CriteriaDTO> getCriteria(@PathVariable Long id) {
        log.debug("REST request to get criteria : {}", id);
        return Optional.ofNullable(criteriaMapper.criteriaToCriteriaDTO(criteriaRepository.findOne(id)))
                .map(criteria -> new ResponseEntity<>(criteria, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

}
