package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.QuestionnaireQuestion;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the QuestionnaireQuestion entity.
 */
public interface QuestionnaireQuestionRepository extends JpaRepository<QuestionnaireQuestion,Long> {

    @Query("select question " +
            " from QuestionnaireQuestion question " +
            " left outer join fetch question.relations " +
            " left outer join fetch question.criteriaGroup criteriaGroup" +
            " left outer join fetch criteriaGroup.criterias " +
            " where question.page.id = :pageId")
    public List<QuestionnaireQuestion> findByPageIdWithEager(@Param("pageId") Long pageId);

}
