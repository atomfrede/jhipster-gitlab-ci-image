package com.alantaya.recipe.dietetic.mapper;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.CriteriaConstraint;
import com.alantaya.recipe.domain.CriteriaState;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Primary
public class DieteticConstraintDecorator extends DieteticConstraintMapper {

    @Inject
    @Qualifier( "delegate" )
    private DieteticConstraintMapper delegate;

    @Override
    public DieteticConstraint criteriaConstraintToDieteticConstraint(CriteriaConstraint criteriaConstraint) {
        DieteticConstraint dieteticConstraint = delegate.criteriaConstraintToDieteticConstraint(criteriaConstraint);
        dieteticConstraint.setDieteticElement(getDieteticElement(criteriaConstraint));
        return dieteticConstraint;
    }

    @Override
    public List<DieteticConstraint> criteriaConstraintsToDieteticConstraints(Set<CriteriaConstraint> criteriaConstraints) {
        if (criteriaConstraints == null) return Collections.emptyList();
        return criteriaConstraints
            .stream()
            .map(this::criteriaConstraintToDieteticConstraint)
            .collect(Collectors.toList());
    }

    @Override
    public List<DieteticConstraint> criteriaToDieteticConstraints(Criteria criteria) {
        if (criteria == null || !CriteriaState.VALIDATED_ID.equals(criteria.getState().getId())) return Collections.emptyList();
        return criteriaConstraintsToDieteticConstraints(criteria.getConstraints());
    }

    @Override
    public List<DieteticConstraint> criteriasToDieteticConstraints(List<Criteria> criterias) {
        final List<DieteticConstraint> dieteticConstraints = new ArrayList<>(10000);
        criterias.stream().forEach( criteria -> dieteticConstraints.addAll(criteriaToDieteticConstraints(criteria)) );
        return dieteticConstraints;
    }

    private DieteticElement getDieteticElement(CriteriaConstraint criteriaConstraint) {
        final DieteticElement dieteticElement;
        if (criteriaConstraint.getFood() != null) {
            dieteticElement = new DieteticFood(criteriaConstraint.getFood());
        } else if (criteriaConstraint.getFoodFamily() != null) {
            dieteticElement = new DieteticFoodFamily(criteriaConstraint.getFoodFamily());
        } else if (criteriaConstraint.getFoodFamilyGroup() != null) {
            dieteticElement = new DieteticFoodFamilyGroup(criteriaConstraint.getFoodFamilyGroup());
        } else if (criteriaConstraint.getFoodTag() != null) {
            dieteticElement = new DieteticFoodTag(criteriaConstraint.getFoodTag());
        } else if (criteriaConstraint.getNutriment() != null) {
            dieteticElement = new DieteticNutriment(criteriaConstraint.getNutriment());
        } else if (criteriaConstraint.getNutrimentFamily() != null) {
            dieteticElement = new DieteticNutrimentFamily(criteriaConstraint.getNutrimentFamily());
        } else {
            dieteticElement = null;
        }
        return dieteticElement;
    }
}
