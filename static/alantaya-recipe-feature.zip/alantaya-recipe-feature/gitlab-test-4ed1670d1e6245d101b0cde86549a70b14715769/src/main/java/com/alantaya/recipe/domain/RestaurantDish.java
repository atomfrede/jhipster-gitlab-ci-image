package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A RestaurantDish.
 */
@Entity
@Table(name = "RESTAURANT_DISH")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class RestaurantDish implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 20)
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    @Size(max = 50)
    @Column(name = "description", length = 200)
    private String description;

    @NotNull
    @Column(name = "price", precision=10, scale=2, nullable = false)
    private BigDecimal price;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "RESTAURANT_DISH__FOOD",
               joinColumns = @JoinColumn(name="restaurantdishs_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="foods_id", referencedColumnName="ID"))
    private Set<Food> foods = new HashSet<>();

    @ManyToOne
    private Restaurant restaurant;

    @ManyToOne
    private RecipeType type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Set<Food> getFoods() {
        return foods;
    }

    public void setFoods(Set<Food> foods) {
        this.foods = foods;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public RecipeType getType() {
        return type;
    }

    public void setType(RecipeType RecipeType) {
        this.type = RecipeType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RestaurantDish restaurantDish = (RestaurantDish) o;

        if ( ! Objects.equals(id, restaurantDish.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "RestaurantDish{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", description='" + description + "'" +
                ", price='" + price + "'" +
                '}';
    }
}
