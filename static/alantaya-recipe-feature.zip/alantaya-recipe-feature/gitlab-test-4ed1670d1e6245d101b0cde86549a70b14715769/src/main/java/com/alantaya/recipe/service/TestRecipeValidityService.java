package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.DieteticConstraint;
import com.alantaya.recipe.dietetic.DieteticRecipe;
import com.alantaya.recipe.dietetic.service.DieteticConstraintService;
import com.alantaya.recipe.dietetic.service.DieteticValidityService;
import com.alantaya.recipe.domain.Criteria;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.RecipeState;
import com.alantaya.recipe.repository.CriteriaRepository;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.web.rest.dto.TestRecipeValidityQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;

@Service
public class TestRecipeValidityService {
    private final Logger log = LoggerFactory.getLogger(TestRecipeValidityService.class);

    @Inject private DieteticValidityService dieteticValidityService;
    @Inject private DieteticConstraintService dieteticConstraintService;
    @Inject private CriteriaRepository criteriaRepository;
    @Inject private RecipeRepository recipeRepository;

    @Transactional(readOnly = true)
    public boolean isRecipeValid(TestRecipeValidityQuery query) {
        final List<DieteticConstraint> computedConstraints = getDieteticConstraints(query);
        final Recipe recipe = recipeRepository.findOneForDieteticRecipe(query.getRecipeId());
        if (!RecipeState.VALIDATE_ID.equals(recipe.getState().getId())) return false;
        final DieteticRecipe dieteticRecipe = new DieteticRecipe(recipe);
        return dieteticValidityService.isValid(dieteticRecipe, computedConstraints);
    }

    private List<DieteticConstraint> getDieteticConstraints(TestRecipeValidityQuery query) {
        final List<Criteria> criterias = criteriaRepository.findByIdInWithEagerRelationships(query.getCriteriaIds());
        return dieteticConstraintService.getDieteticConstraints(
            criterias,
            Collections.emptyMap(),
            Collections.emptyList()
        );
    }
}
