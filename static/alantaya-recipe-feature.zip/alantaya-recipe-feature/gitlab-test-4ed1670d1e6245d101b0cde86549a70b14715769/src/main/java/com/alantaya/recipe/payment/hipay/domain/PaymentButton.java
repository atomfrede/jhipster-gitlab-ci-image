package com.alantaya.recipe.payment.hipay.domain;

public class PaymentButton {

    private String mode;
    private Long websiteId;
    private String sign;
    private String data;
    private String url;

    public PaymentButton(String mode, Long websiteId, String sign, String data, String url) {
        this.mode = mode;
        this.websiteId = websiteId;
        this.sign = sign;
        this.data = data;
        this.url = url;
    }

    public String getMode() {
        return mode;
    }

    public Long getWebsiteId() {
        return websiteId;
    }

    public String getSign() {
        return sign;
    }

    public String getData() {
        return data;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public String toString() {
        return "PaymentButton{" +
            "mode='" + mode + '\'' +
            ", websiteId=" + websiteId +
            ", sign='" + sign + '\'' +
            ", data='" + data + '\'' +
            ", url='" + url + '\'' +
            '}';
    }
}
