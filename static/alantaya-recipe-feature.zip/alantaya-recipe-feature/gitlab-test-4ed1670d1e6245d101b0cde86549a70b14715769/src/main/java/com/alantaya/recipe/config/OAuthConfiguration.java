package com.alantaya.recipe.config;

import com.alantaya.recipe.config.oauth.InMemoryTokenStore;
import com.alantaya.recipe.config.oauth.OAuthConsumerFactory;
import oauth.signpost.OAuthProvider;
import oauth.signpost.basic.DefaultOAuthProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.inject.Inject;

@Configuration
public class OAuthConfiguration {

    @Inject
    private Environment env;

    @Bean(name = "withingsOAuthProvider")
    public OAuthProvider withingsOAuthProvider() {
        return new DefaultOAuthProvider(
            env.getProperty("oauth.withings.requestTokenUrl"),
            env.getProperty("oauth.withings.accessTokenUrl"),
            env.getProperty("oauth.withings.authorizeUrl")
        );
    }

    @Bean(name = "withingsOAuthConsumerFactory")
    public OAuthConsumerFactory withingsOAuthConsumerFactory() {
        return new OAuthConsumerFactory(
            env.getProperty("oauth.withings.consumerKey"),
            env.getProperty("oauth.withings.consumerSecret")
        );
    }

    @Bean(name = "withingsTokenStore")
    public InMemoryTokenStore withingsInMemoryTokenStore() {
        return new InMemoryTokenStore();
    }

}
