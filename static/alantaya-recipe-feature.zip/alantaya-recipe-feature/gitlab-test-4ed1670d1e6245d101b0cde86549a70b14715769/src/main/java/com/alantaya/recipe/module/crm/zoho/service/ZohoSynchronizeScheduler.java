package com.alantaya.recipe.module.crm.zoho.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

/**
 * Cron de synchronisation des User vers Zoho CRM
 */
@Service
public class ZohoSynchronizeScheduler {

    private final Logger log = LoggerFactory.getLogger(ZohoSynchronizeScheduler.class);

    @Inject
    private ZohoSynchronizeService zohoSynchronizeService;

    @Scheduled(cron="0 */10 * * * ?")
    public void synchronizedUsers() {
        log.debug("Synchronize users with zoho");
        zohoSynchronizeService.synchronizedCreatedUsers();
        zohoSynchronizeService.synchronizedUpdatedUsers();
    }

}
