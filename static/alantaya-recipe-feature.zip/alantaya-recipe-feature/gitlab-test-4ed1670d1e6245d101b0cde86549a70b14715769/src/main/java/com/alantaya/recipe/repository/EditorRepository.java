package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Editor;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Editor entity.
 */
public interface EditorRepository extends JpaRepository<Editor,Long> {

}
