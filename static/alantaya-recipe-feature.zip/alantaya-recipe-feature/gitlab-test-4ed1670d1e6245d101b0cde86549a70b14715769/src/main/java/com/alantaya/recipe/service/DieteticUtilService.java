package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.User;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

@Service
public class DieteticUtilService {
    @Inject private BiometricService biometricService;

    public Double getBMI(Double weight, Double size) {
        return weight / ( Math.pow( size / 100D, 2) );
    }

    public Double getDailyEnergyNeeds(Double sex, Double age, Double sizeInCm, Double weightInKg, Double sportActivityInHour) {
        return getMetabolismeIndice(sex, age, sizeInCm, weightInKg) * getSportActivityIndice(sportActivityInHour);
    }

    private Double getMetabolismeIndice(Double sex, Double age, Double sizeInCm, Double weightInKg) {
        final Double weightAdjustment;
        final Double sizeAdjustment;
        final Double yearAdjustment;
        if (sex == 1) { // is a woman
            weightAdjustment = 655D + (9.6D * weightInKg);
            sizeAdjustment = 1.8D * sizeInCm;
            yearAdjustment = 4.7D * age;
        } else { // is a man
            weightAdjustment = 66D + (13.7D * weightInKg);
            sizeAdjustment = 5D * sizeInCm;
            yearAdjustment = 6.8D * age;
        }
        return (weightAdjustment + sizeAdjustment - yearAdjustment);
    }

    private Double getSportActivityIndice(Double hourlyActivityPerWeek) {
        if (hourlyActivityPerWeek < 1) return 1.25D;          // Sédentaire (larve humaine)
        else if (hourlyActivityPerWeek < 2) return 1.325D;    // Légèrement actif
        else if (hourlyActivityPerWeek < 5) return 1.5D;      // Modérément actif
        else if (hourlyActivityPerWeek < 9) return 1.7D;      // Très actif
        else return 2.0D;                                     // Extremement actif
    }

    public boolean isUserDieteticValid(User userToValidate) {
        return biometricService.getBiometricValue(Biometry.ENERGY_ID, userToValidate) != null;
    }
}
