package com.alantaya.recipe.config.oauth;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.http.HttpParameters;
import oauth.signpost.signature.AuthorizationHeaderSigningStrategy;
import oauth.signpost.signature.HmacSha1MessageSigner;

public class OAuthConsumerFactory {

    private String defaultConsumerKey;
    private String defaultSecretKey;

    public OAuthConsumerFactory(String defaultConsumerKey, String defaultSecretKey) {
        this.defaultConsumerKey = defaultConsumerKey;
        this.defaultSecretKey = defaultSecretKey;
    }

    public OAuthConsumer createOauthConsumer() {
        OAuthConsumer consumer = new DefaultOAuthConsumer(defaultConsumerKey, defaultSecretKey);
        consumer.setSigningStrategy(new AuthorizationHeaderSigningStrategy());
        consumer.setMessageSigner(new HmacSha1MessageSigner());
        consumer.setAdditionalParameters(new HttpParameters());
        return consumer;
    }

    public OAuthConsumer createOauthConsumerWithToken(OAuthRequestToken token) {
        OAuthConsumer consumer = createOauthConsumer();
        consumer.setTokenWithSecret(token.getToken(), token.getSecret());
        return consumer;
    }
}
