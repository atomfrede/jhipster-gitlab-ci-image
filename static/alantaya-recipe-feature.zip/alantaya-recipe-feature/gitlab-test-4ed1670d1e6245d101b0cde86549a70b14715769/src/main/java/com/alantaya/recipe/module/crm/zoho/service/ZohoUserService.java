package com.alantaya.recipe.module.crm.zoho.service;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Service
public class ZohoUserService {

    @Inject private UserRepository userRepository;

    @Transactional
    public void setUserZohoIdAndZohoSynchronizedTrue(Map<String, Long> zohoIdByUserEmail) {
        List<User> users = userRepository.findByEmailIn(zohoIdByUserEmail.keySet());
        users.forEach(
            user -> {
                user.setZohoId(zohoIdByUserEmail.get(user.getEmail()));
                user.setZohoSynchronized(true);
            }
        );
        userRepository.save(users);
    }

    @Transactional
    public void setUserZohoSynchronizedTrue(Collection<String> userEmails) {
        List<User> users = userRepository.findByEmailIn(userEmails);
        users.forEach(
            user -> user.setZohoSynchronized(true)
        );
        userRepository.save(users);
    }

}
