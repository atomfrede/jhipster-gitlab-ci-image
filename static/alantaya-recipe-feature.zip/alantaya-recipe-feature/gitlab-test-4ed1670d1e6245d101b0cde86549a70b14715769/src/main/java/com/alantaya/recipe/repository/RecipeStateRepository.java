package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeState;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeState entity.
 */
public interface RecipeStateRepository extends JpaRepository<RecipeState,Long> {

}
