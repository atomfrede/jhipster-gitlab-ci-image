package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.util.CustomLocalDateSerializer;
import com.alantaya.recipe.domain.util.ISO8601LocalDateDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A SubscriptionPackage.
 */
@Entity
@Table(name = "SUBSCRIPTION_PACKAGE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionPackage implements Serializable {

    public static final Long FREE_TRY_ID = 1L;
    public static final Long STD_FIRST_ID = 2L;
    public static final Long STD_SECOND_ID = 3L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 250)
    @Column(name = "name", length = 250, nullable = false)
    private String name;

    @Size(max = 250)
    @Column(name = "partner_name", length = 250)
    private String partnerName;

    @Size(max = 250)
    @Column(name = "partner_code", length = 250)
    private String partnerCode;

    @NotNull
    @Size(max = 2000)
    @Column(name = "description", length = 2000)
    private String description;

    @Column(name = "licence_number")
    private Integer licenceNumber;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
    @Column(name = "start_date")
    private LocalDate startDate;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
    @Column(name = "end_date")
    private LocalDate endDate;

    @NotNull
    @Min(value = 0)
    @Column(name = "duration_in_month", nullable = false)
    private Integer durationInMonth;

    @NotNull
    @Min(value = 0)
    @Column(name = "price", nullable = false)
    private Double price;

    @ManyToOne
    private SubscriptionPackageState state;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(String partnerCode) {
        this.partnerCode = partnerCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getLicenceNumber() {
        return licenceNumber;
    }

    public void setLicenceNumber(Integer licenceNumber) {
        this.licenceNumber = licenceNumber;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Integer getDurationInMonth() {
        return durationInMonth;
    }

    public void setDurationInMonth(Integer durationInMonth) {
        this.durationInMonth = durationInMonth;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public SubscriptionPackageState getState() {
        return state;
    }

    public void setState(SubscriptionPackageState subscriptionPackageState) {
        this.state = subscriptionPackageState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubscriptionPackage subscriptionPackage = (SubscriptionPackage) o;

        if ( ! Objects.equals(id, subscriptionPackage.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "SubscriptionPackage{" +
                "id=" + id +
                ", name='" + name + "'" +
                ", partnerName='" + partnerName + "'" +
                ", partnerCode='" + partnerCode + "'" +
                ", description='" + description + "'" +
                ", licenceNumber='" + licenceNumber + "'" +
                ", startDate='" + startDate + "'" +
                ", endDate='" + endDate + "'" +
                ", durationInMonth='" + durationInMonth + "'" +
                ", price='" + price + "'" +
                '}';
    }
}
