package com.alantaya.recipe.dietetic;

public interface DieteticStatistic {

    Double getQuantityFor(DieteticElement dieteticElement);

}
