/**
 * Locale specific code.
 */
package com.alantaya.recipe.config.locale;
