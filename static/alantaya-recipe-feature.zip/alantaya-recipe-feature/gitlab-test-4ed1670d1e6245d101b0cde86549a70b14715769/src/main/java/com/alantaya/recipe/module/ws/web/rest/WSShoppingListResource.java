package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.ws.web.rest.dto.FoodDTO;
import com.alantaya.recipe.module.ws.web.rest.dto.ShoppingListDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.ShoppingListMapper;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.ShoppingListService;
import com.alantaya.recipe.web.rest.dto.ShoppingListQuery;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import java.util.List;

/**
 * REST controller for managing BiometryDTO.
 */
@RestController
@RequestMapping("/ws/v1")
@Api(value = "/shopping-list")
public class WSShoppingListResource {

    @Inject
    private ShoppingListService shoppingListService;
    @Inject
    private ShoppingListMapper shoppingListMapper;
    @Inject
    private UserRepository userRepository;

    private final Logger log = LoggerFactory.getLogger(WSShoppingListResource.class);

    @ApiOperation(value = "",
        notes ="Get the <<ShoppingList>> for a specified user between date. The shopping list is an aggregate of all food " +
            "defined in each <<Recipe>>.")
    @RequestMapping(value = "/shopping-list/{userId}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional(readOnly = true)
    public ResponseEntity<ShoppingListDTO> getShoppingList(
                                                 @ApiParam(value = "userId", required = true)
                                                 @PathVariable Long userId,
                                                 @ApiParam(value = "from ex: 2015-11-18", required = true)
                                                 @RequestParam(value="from", required = true)
                                                 @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate from,
                                                 @ApiParam(value = "to ex: 2015-11-22", required = true)
                                                 @RequestParam(value="to", required = true)
                                                 @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate to) {
        log.debug("REST request to get all current user biometrics for user: {}", userId);
        User user = userRepository.findOne(userId);
        List<FoodDTO> foodDTOs = shoppingListMapper.shoppingListItemsToFoodDTOs(
                shoppingListService.getShoppingListForUser(new ShoppingListQuery(from, to), user));
        ShoppingListDTO shoppingListDTO = new ShoppingListDTO();
        shoppingListDTO.setFoods(foodDTOs);
        shoppingListDTO.setFrom(from);
        shoppingListDTO.setTo(to);
        return new ResponseEntity<>(shoppingListDTO, HttpStatus.OK);
    }
}
