package com.alantaya.recipe.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A FoodQuantityByRecipe.
 */
@Entity
@Table(name = "T_FOOD_QUANTITY_BY_RECIPE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class FoodQuantityByRecipe implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "amount_in_grams", nullable = false)
    private Integer amountInGrams;

    @ManyToOne
    private Food food;

    @ManyToOne
    @JsonIgnore
    private Recipe recipe;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAmountInGrams() {
        return amountInGrams;
    }

    public void setAmountInGrams(Integer amountInGrams) {
        this.amountInGrams = amountInGrams;
    }

    public Food getFood() {
        return food;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FoodQuantityByRecipe foodQuantityByRecipe = (FoodQuantityByRecipe) o;

        if ( ! Objects.equals(id, foodQuantityByRecipe.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, food);
    }

    @Override
    public String toString() {
        return "FoodQuantityByRecipe{" +
                "id=" + id +
                ", amountInGrams='" + amountInGrams + "'" +
                '}';
    }
}
