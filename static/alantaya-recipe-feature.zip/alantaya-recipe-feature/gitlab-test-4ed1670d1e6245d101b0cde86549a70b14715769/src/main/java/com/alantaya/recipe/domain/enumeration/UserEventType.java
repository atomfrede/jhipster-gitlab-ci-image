package com.alantaya.recipe.domain.enumeration;

/**
 * The UserEventType enumeration.
 */
public enum UserEventType {

    QUESTIONNAIRE_UPDATE,
    BIOMETRICS_UPDATE

}
