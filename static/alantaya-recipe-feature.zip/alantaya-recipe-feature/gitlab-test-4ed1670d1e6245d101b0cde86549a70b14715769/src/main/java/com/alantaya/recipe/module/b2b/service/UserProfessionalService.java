package com.alantaya.recipe.module.b2b.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.City;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserProfessionalInformation;
import com.alantaya.recipe.domain.enumeration.JobType;
import com.alantaya.recipe.domain.enumeration.UserState;
import com.alantaya.recipe.repository.UserProfessionalInformationRepository;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.MailService;
import com.alantaya.recipe.service.UserService;
import com.alantaya.recipe.service.util.RandomUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.HashSet;
import java.util.Set;

@Service
public class UserProfessionalService {
    private final Logger log = LoggerFactory.getLogger(UserProfessionalService.class);

    @Inject private UserRepository userRepository;
    @Inject private UserProfessionalInformationRepository userProfessionalInformationRepository;
    @Inject private PasswordEncoder passwordEncoder;
    @Inject private UserService userService;
    @Inject private MailService mailService;

    @Transactional
    public void createUserProfessional(String firstName,
                                       String lastName,
                                       String email,
                                       String password,
                                       String address,
                                       City city,
                                       String phoneNumber,
                                       String adeliNumber,
                                       JobType jobType,
                                       String jobNumber,
                                       String diplomaName,
                                       Integer diplomaYear,
                                       String comment,
                                       boolean isAcceptCGU) {
        UserProfessionalInformation userProfessionalInformation = createUserProfessionalInformation(
            address,
            city,
            phoneNumber,
            adeliNumber,
            jobType,
            jobNumber,
            diplomaName,
            diplomaYear,
            comment,
            isAcceptCGU);

        User userSaved = createUserInformation(
            firstName,
            lastName,
            email,
            password,
            userProfessionalInformation);

        log.debug("Created professional user information for: {}", userSaved);
        mailService.sendActivationEmail(userSaved);
    }

    @Transactional
    public void updateUserProfessional(String firstName,
                                       String lastName,
                                       String address,
                                       City city,
                                       String phoneNumber,
                                       String adeliNumber,
                                       JobType jobType,
                                       String jobNumber,
                                       String diplomaName,
                                       Integer diplomaYear,
                                       String comment) {
        User userToUpdate = userService.getUser();

        userToUpdate.setFirstName(firstName);
        userToUpdate.setLastName(lastName);
        UserProfessionalInformation userProfessionalInformationToUpdate = userToUpdate.getUserProfessionalInformation();
        userProfessionalInformationToUpdate.setAddress(address);
        userProfessionalInformationToUpdate.setCity(city);
        userProfessionalInformationToUpdate.setPhoneNumber(phoneNumber);
        userProfessionalInformationToUpdate.setAdeliNumber(adeliNumber);
        userProfessionalInformationToUpdate.setJobType(jobType);
        userProfessionalInformationToUpdate.setJobNumber(jobNumber);
        userProfessionalInformationToUpdate.setDiplomaName(diplomaName);
        userProfessionalInformationToUpdate.setDiplomaYear(diplomaYear);
        userProfessionalInformationToUpdate.setComment(comment);

        userRepository.save(userToUpdate);
    }

    private User createUserInformation(String firstName,
                                       String lastName,
                                       String email,
                                       String password,
                                       UserProfessionalInformation userProfessionalInformation) {
        Set<Authority> authorities = new HashSet<>();
        authorities.add(new Authority(AuthoritiesConstants.PRO));
        authorities.add(new Authority(AuthoritiesConstants.SUPERVISOR));
        String encryptedPassword = passwordEncoder.encode(password);

        User userToSave = new User();
        userToSave.setPassword(encryptedPassword);
        userToSave.setFirstName(firstName);
        userToSave.setLastName(lastName);
        userToSave.setEmail(email);
        userToSave.setLangKey("fr");
        userToSave.setState(UserState.PENDING);
        userToSave.setActivationKey(RandomUtil.generateActivationKey());
        userToSave.setAuthorities(authorities);
        userToSave.setUserProfessionalInformation(userProfessionalInformation);

        return userRepository.save(userToSave);
    }

    private UserProfessionalInformation createUserProfessionalInformation(String address,
                                                                          City city,
                                                                          String phoneNumber,
                                                                          String adeliNumber,
                                                                          JobType jobType,
                                                                          String jobNumber,
                                                                          String diplomaName,
                                                                          Integer diplomaYear,
                                                                          String comment,
                                                                          boolean isAcceptCGU) {
        UserProfessionalInformation userProfessionalInformation = new UserProfessionalInformation(
            address,
            city,
            phoneNumber,
            adeliNumber,
            jobType,
            jobNumber,
            diplomaName,
            diplomaYear,
            comment,
            isAcceptCGU);
        return userProfessionalInformationRepository.save(userProfessionalInformation);
    }
}
