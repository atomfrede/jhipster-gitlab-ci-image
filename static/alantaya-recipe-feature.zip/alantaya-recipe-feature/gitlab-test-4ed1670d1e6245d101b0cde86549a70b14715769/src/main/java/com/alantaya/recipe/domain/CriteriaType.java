package com.alantaya.recipe.domain;

import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A CriteriaType.
 */
@Entity
@Table(name = "T_CRITERIA_TYPE")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class CriteriaType implements Serializable {
    public static final Long PATHOLOGIE_ID = 1L;
    public static final Long PROFILE_ID = 2L;
    public static final Long APPORT_ID = 3L;
    public static final Long UTILISATEUR_ID = 4L;
    public static final Long ALLERGIE_ID = 5L;
    public static final Long ALANTAYA_ID = 6L;
    public static final Long PREVENTION_ID = 7L;
    public static final Long REGIME_ID = 8L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "name", length = 100, nullable = false)
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CriteriaType criteriaType = (CriteriaType) o;

        if ( ! Objects.equals(id, criteriaType.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "CriteriaType{" +
                "id=" + id +
                ", name='" + name + "'" +
                '}';
    }
}
