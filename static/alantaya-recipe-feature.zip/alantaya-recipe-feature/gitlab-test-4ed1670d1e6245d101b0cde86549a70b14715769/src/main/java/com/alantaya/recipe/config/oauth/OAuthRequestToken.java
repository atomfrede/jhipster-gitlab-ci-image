package com.alantaya.recipe.config.oauth;


public interface OAuthRequestToken {
    String getToken();
    String getSecret();
}
