package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.ws.web.rest.dto.UserDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import java.util.List;

@Mapper(componentModel = "spring", uses = {})
public interface UserMapper {

    UserDTO userToUserDTO(User user);
    List<UserDTO> usersToUserDTOs(List<User> users);

    @Mappings({
        @Mapping(target="createdBy", ignore = true),
        @Mapping(target="createdDate", ignore = true),
        @Mapping(target="lastModifiedBy", ignore = true),
        @Mapping(target="lastModifiedDate", ignore = true),
        @Mapping(target="password", ignore = true),
        @Mapping(target="state", ignore = true),
        @Mapping(target="activationKey", ignore = true),
        @Mapping(target="resetKey", ignore = true),
        @Mapping(target="resetDate", ignore = true),
        @Mapping(target="langKey", ignore = true),
        @Mapping(target="authorities", ignore = true),
        @Mapping(target="persistentTokens", ignore = true),
        @Mapping(target="userType", ignore = true),
        @Mapping(target="oneTimePassword", ignore = true),
        @Mapping(target="lastLoginAttempt", ignore = true),
        @Mapping(target="author", ignore = true),
        @Mapping(target="subscriptionPackage", ignore = true),
        @Mapping(target="subscriptionExpirationDate", ignore = true),
        @Mapping(target="currentQuestionnairePage", ignore = true),
        @Mapping(target="questionnaireState", ignore = true),
        @Mapping(target="city", ignore = true),
        @Mapping(target="dislikedFoods", ignore = true),
        @Mapping(target="missingEquipment", ignore = true),
        @Mapping(target="partnerCode", ignore = true),
        @Mapping(target="isGenerationInProgress", ignore = true),
        @Mapping(target="supervisedUsers", ignore = true),
        @Mapping(target="userProfessionalInformation", ignore = true),
        @Mapping(target="wsUserData", ignore = true),
        @Mapping(target="zohoSynchronized", ignore = true),
        @Mapping(target="zohoId", ignore = true)
    })
    User userDTOToUser(UserDTO userDTO);
}
