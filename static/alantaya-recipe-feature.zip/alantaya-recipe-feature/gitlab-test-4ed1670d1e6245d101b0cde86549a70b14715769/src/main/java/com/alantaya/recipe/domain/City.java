package com.alantaya.recipe.domain;

import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonView;
import net.karneim.pojobuilder.GeneratePojoBuilder;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A City.
 */
@Entity
@Table(name = "CITY")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class City implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonView(View.Minimal.class)
    private Long id;

    @NotNull
    @Max(value = 99999)
    @Column(name = "zip_code", nullable = false)
    @JsonView(View.Minimal.class)
    private Integer zipCode;

    @NotNull
    @Size(max = 36)
    @Column(name = "name", length = 36, nullable = false)
    @JsonView(View.Minimal.class)
    private String name;

    @Max(value = 999)
    @Column(name = "region_code")
    @JsonView(View.Summary.class)
    private Integer regionCode;

    @Size(max = 26)
    @Column(name = "region_name", length = 26)
    @JsonView(View.Summary.class)
    private String regionName;

    @Column(name = "dep_code")
    @JsonView(View.Summary.class)
    private String depCode;

    @Size(max = 23)
    @Column(name = "dep_name", length = 23)
    @JsonView(View.Summary.class)
    private String depName;

    @Size(max = 9)
    @Column(name = "longitude", length = 9)
    @JsonView(View.Full.class)
    private String longitude;

    @Size(max = 11)
    @Column(name = "latitude", length = 11)
    @JsonView(View.Full.class)
    private String latitude;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getZipCode() {
        return zipCode;
    }

    public void setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(Integer regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getDepCode() {
        return depCode;
    }

    public void setDepCode(String depCode) {
        this.depCode = depCode;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        City city = (City) o;

        if ( ! Objects.equals(id, city.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "City{" +
                "id=" + id +
                ", zipCode='" + zipCode + "'" +
                ", name='" + name + "'" +
                ", regionCode='" + regionCode + "'" +
                ", regionName='" + regionName + "'" +
                ", depCode='" + depCode + "'" +
                ", depName='" + depName + "'" +
                ", longitude='" + longitude + "'" +
                ", latitude='" + latitude + "'" +
                '}';
    }
}
