package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RecipeDurableLife;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the RecipeDurableLife entity.
 */
public interface RecipeDurableLifeRepository extends JpaRepository<RecipeDurableLife,Long> {

}
