package com.alantaya.recipe.module.ws.web.rest.mapper;

import com.alantaya.recipe.domain.RecipeStep;
import com.alantaya.recipe.module.ws.web.rest.dto.RecipeStepDTO;
import org.mapstruct.Mapper;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface RecipeStepMapper {

    RecipeStepDTO recipeStepToRecipeStepDTO(RecipeStep recipeStep);
    List<RecipeStepDTO> recipeStepsToRecipeStepDTOs(Collection<RecipeStep> recipeStep);

}
