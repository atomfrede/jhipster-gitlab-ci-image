package com.alantaya.recipe.dietetic.rule;

import com.alantaya.recipe.dietetic.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConstraintValidity implements DieteticRule {
    private final Logger log = LoggerFactory.getLogger(ConstraintValidity.class);

    @Override
    public boolean isValid(DieteticStatistic dieteticStatisticToValidate, List<DieteticConstraint> dieteticConstraints) {
        if (dieteticStatisticToValidate instanceof DieteticFoodQuantityByRecipe
            || dieteticStatisticToValidate instanceof DieteticRecipe
            || dieteticStatisticToValidate instanceof DieteticMenu
            || dieteticStatisticToValidate instanceof DieteticMenuDay
            || dieteticStatisticToValidate instanceof DieteticRestaurantDish)
        {
            return dieteticConstraints.stream()
                    .allMatch(constraint -> isConstraintValid(constraint, dieteticStatisticToValidate));
        }
        return true;
    }

    private boolean isConstraintValid(DieteticConstraint dieteticConstraint, DieteticStatistic dieteticStatisticToValidate) {
        if (!isMaxValid(dieteticConstraint, dieteticStatisticToValidate)) {
            DieteticLogUtil.log(log, dieteticStatisticToValidate, dieteticConstraint, "Above max -> "+ dieteticConstraint.getMinQuantity());
            return false;
        }
        return true;
    }

    private boolean isMaxValid(DieteticConstraint dieteticConstraint, DieteticStatistic dieteticStatistic) {
        Double quantity = dieteticStatistic.getQuantityFor(dieteticConstraint.getDieteticElement());
        final Double maxQuantityReference = dieteticConstraint.getMaxQuantity();
        if (maxQuantityReference != null && maxQuantityReference == 0 && quantity > 0) return false;
        return true;
        //return (maxQuantityReference == null || quantity <= maxQuantityReference);
    }
}
