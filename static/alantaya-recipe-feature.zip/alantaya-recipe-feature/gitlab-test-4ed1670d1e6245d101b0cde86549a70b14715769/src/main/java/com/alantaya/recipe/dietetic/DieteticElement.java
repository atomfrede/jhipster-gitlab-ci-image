package com.alantaya.recipe.dietetic;

public interface DieteticElement {

    Long getId();
    String getLogName();
    DieteticElement getMacro();
    int hashCode();
    boolean equals(Object o);

}
