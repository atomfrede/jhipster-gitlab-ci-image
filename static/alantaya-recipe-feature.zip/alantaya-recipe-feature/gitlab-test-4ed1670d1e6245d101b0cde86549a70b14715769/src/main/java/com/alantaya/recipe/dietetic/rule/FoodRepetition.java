package com.alantaya.recipe.dietetic.rule;

import com.alantaya.recipe.dietetic.*;
import com.alantaya.recipe.domain.FoodQuantityByRecipe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class FoodRepetition implements DieteticRule {
    private final Logger log = LoggerFactory.getLogger(FoodRepetition.class);

    @Override
    public boolean isValid(DieteticStatistic dieteticStatistic, List<DieteticConstraint> dieteticConstraints) {
        if (dieteticStatistic instanceof DieteticMenu) {
            final DieteticMenu meal = (DieteticMenu) dieteticStatistic;
            final List<DieteticRecipe> recipes = meal.getDieteticRecipes();
            final HashSet<DieteticFood> foodsToCheck = new HashSet<>();
            for (int i = 0, n = recipes.size(); i < n; i++) {
                final DieteticRecipe recipe = recipes.get(i);
                final Set<DieteticFood> foods = recipe.getDieteticFoodQuantityByRecipes().stream()
                    .map(foodQty -> foodQty.getDieteticFood())
                    .collect(Collectors.toSet());
                for (final DieteticFood food : foods) {
                    if (! food.getIsRepetableInAMeal() && foodsToCheck.contains(food)) {
                        DieteticLogUtil.log(log, dieteticStatistic, null, "["+food.getId()+"] "+food.getName());
                        return false;
                    }
                    foodsToCheck.add(food);
                }
            }
            return true;
        }
        return true;
    }

}
