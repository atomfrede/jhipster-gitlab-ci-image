package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Authority;
import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.RecipeState;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.repository.RecipeStateRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

@Service
public class RecipeService {

    @Inject
    private RecipeRepository recipeRepository;

    @Inject
    private UserService userService;

    @Inject
    private RecipeStateRepository recipeStateRepository;

    private final static List<Long> RECIPE_STATE_IDS_ALLOWED_FOR_BLOGGER = Arrays.asList(RecipeState.DRAFT_ID, RecipeState.RECORDED_ID);

    public Recipe createOrUpdate(Recipe recipe) {
        User user = userService.getUserWithAuthorities();
        if (isBlogger(user)) {
            if (user.getAuthor() == null) return null;
            if (hasStateNotAllowedForBlogger(recipe)) return null;

            if (recipe.getId() != null && ! recipe.getAuthor().equals(user.getAuthor())) {
                return null;
            }
            recipe.setAuthor(user.getAuthor());
        }
        return recipeRepository.save(recipe);
    }

    @Transactional
    public boolean fastRecipeValidation(Long id){
        Recipe recipe = recipeRepository.findOneWithEagerRelationships(id);
        if(recipe.getState() != null && recipe.getState().getId().equals(RecipeState.READY_FOR_PUBLICATION)){
            recipe.setState(recipeStateRepository.findOne(RecipeState.VALIDATE_ID));
            recipeRepository.save(recipe);
            return true;
        }
        return false;
    }

    private boolean hasStateNotAllowedForBlogger (Recipe recipe){
        return ! RECIPE_STATE_IDS_ALLOWED_FOR_BLOGGER.contains(recipe.getState().getId());
    }

    private boolean isBlogger (User user){
        return (user.getAuthorities().contains(new Authority(AuthoritiesConstants.BLOGGER))
        && !user.getAuthorities().contains(new Authority(AuthoritiesConstants.RECIPE_ADMIN))
        && !user.getAuthorities().contains(new Authority(AuthoritiesConstants.ADMIN)));
    }
}
