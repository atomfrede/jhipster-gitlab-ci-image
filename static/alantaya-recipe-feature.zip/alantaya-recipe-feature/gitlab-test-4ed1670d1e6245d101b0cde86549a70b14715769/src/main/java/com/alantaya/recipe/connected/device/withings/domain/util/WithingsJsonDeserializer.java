package com.alantaya.recipe.connected.device.withings.domain.util;

import com.alantaya.recipe.connected.device.withings.domain.MeasureResult;
import com.alantaya.recipe.connected.device.withings.domain.WithingsResponse;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;

@Service
public class WithingsJsonDeserializer {
    private final Logger log = LoggerFactory.getLogger(WithingsJsonDeserializer.class);

    @Inject private ObjectMapper objectMapper;

    public MeasureResult deserializeMeasureResult(String jsonMeasureResult) {
        if (StringUtils.isNotBlank(jsonMeasureResult)) {
            final JavaType jsonObjectType = objectMapper.getTypeFactory().constructType(WithingsResponse.class);
            try {
                final WithingsResponse responseMeasure = objectMapper.readValue(jsonMeasureResult, jsonObjectType);
                final MeasureResult measureResult = responseMeasure.getBody();
                return measureResult == null ? new MeasureResult() : measureResult;
            }
            catch (Exception jpe) {
                log.error("Unable to deserializeMeasureResult jsonMeasureResult : " + jsonMeasureResult);
            }
        }
        return new MeasureResult();
    }
}
