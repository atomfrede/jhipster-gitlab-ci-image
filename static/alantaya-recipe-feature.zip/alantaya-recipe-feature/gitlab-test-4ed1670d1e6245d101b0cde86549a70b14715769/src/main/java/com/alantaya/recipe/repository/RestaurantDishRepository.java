package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.RestaurantDish;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the RestaurantDish entity.
 */
public interface RestaurantDishRepository extends JpaRepository<RestaurantDish,Long> {

    @Query("select restaurantDish from RestaurantDish restaurantDish left join fetch restaurantDish.foods where restaurantDish.id =:id")
    RestaurantDish findOneWithEagerRelationships(@Param("id") Long id);

    /*@Query("select restaurantDish " +
        "from RestaurantDish restaurantDish left join fetch restaurantDish.foods " +
        "where restaurantDish.restaurant.id =:restaurantId")*/
    List<RestaurantDish> findByRestaurantId(@Param("restaurantId") Long restaurantId);

}
