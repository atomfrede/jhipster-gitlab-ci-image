package com.alantaya.recipe.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;

/**
 * Utility class for Spring Security.
 */
public final class SecurityUtils {

    private SecurityUtils() {
    }

    /**
     * Get the Email of the current user.
     */
    public static String getCurrentEmail() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        UserDetailsDTO springSecurityUser = null;
        String userName = null;
        if(authentication != null) {
            if (authentication.getPrincipal() instanceof UserDetailsDTO) {
                springSecurityUser = (UserDetailsDTO) authentication.getPrincipal();
                userName = springSecurityUser.getUsername();
            } else if (authentication.getPrincipal() instanceof String) {
                userName = (String) authentication.getPrincipal();
            }
        }
        return userName;
    }

    /**
     * Check if a user is authenticated.
     *
     * @return true if the user is authenticated, false otherwise
     */
    protected static boolean isPasswordAuthenticated() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Collection<? extends GrantedAuthority> authorities = securityContext.getAuthentication().getAuthorities();
        if (authorities != null) {
            for (GrantedAuthority authority : authorities) {
                if (authority.getAuthority().equals(AuthoritiesConstants.ANONYMOUS)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Check if a user is authenticated.
     *
     * @return true if the user is authenticated, false otherwise
     */
    public static boolean isOtpAuthenticated() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        UserDetailsDTO springSecurityUser = null;

        if(authentication != null) {
            if (authentication.getPrincipal() instanceof UserDetailsDTO) {
                springSecurityUser = (UserDetailsDTO) authentication.getPrincipal();
                return springSecurityUser.isOTPAuthenticated();
            }
        }

        return false;
    }

    public static void otpAuthenticate() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        UserDetailsDTO springSecurityUser = null;

        if(authentication != null) {
            if (authentication.getPrincipal() instanceof UserDetailsDTO) {
                springSecurityUser = (UserDetailsDTO) authentication.getPrincipal();
                springSecurityUser.setIsAuthenticated(true);
            }
        }
    }

    /**
     * If the current user has a specific security role.
     */
    public static boolean isUserInRole(String role) {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if(authentication != null) {
            if (authentication.getPrincipal() instanceof UserDetailsDTO) {
                UserDetailsDTO springSecurityUser = (UserDetailsDTO) authentication.getPrincipal();
                return springSecurityUser.getAuthorities().contains(new SimpleGrantedAuthority(role));
            }
        }
        return false;
    }

    public static String generateKey() {
        int min = 100000;
        int max = 999999;
        int digits = (int) Math.floor(Math.random() * (max - min + 1)) + min;
        return String.valueOf(digits);
    }
}
