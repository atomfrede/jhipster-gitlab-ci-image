package com.alantaya.recipe.service;


import com.alantaya.recipe.domain.SubscriptionPackage;
import com.alantaya.recipe.domain.SubscriptionPackageState;
import com.alantaya.recipe.repository.SubscriptionPackageRepository;
import com.alantaya.recipe.repository.SubscriptionPackageStateRepository;
import com.alantaya.recipe.service.util.Base16;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Optional;

@Service
public class SubscriptionPackageService {

    private final Logger log = LoggerFactory.getLogger(SubscriptionPackageService.class);

    @Inject private SubscriptionPackageRepository subscriptionPackageRepository;
    @Inject private SubscriptionPackageStateRepository subscriptionPackageStateRepository;
    @Inject private UserSubscriptionPaymentService userSubscriptionPaymentService;

    public Optional<SubscriptionPackage> getValidSubscriptionPackageByPartnerCode(String partnerCode) {
        if (StringUtils.isBlank(partnerCode)) {
            log.error("Missing parameter: code partner null or empty");
            return Optional.empty();
        }
        final SubscriptionPackage subscriptionPackage = subscriptionPackageRepository.findOneByPartnerCode(partnerCode);
        if (isNotValid(subscriptionPackage)) {
            return Optional.empty();
        }

        return Optional.of(subscriptionPackage);
    }

    public boolean isNotValid(SubscriptionPackage subscriptionPackage) {
        return !isValid(subscriptionPackage);
    }

    public boolean isValid(SubscriptionPackage subscriptionPackage) {
        if (subscriptionPackage == null) {
            log.error("Subscription package is null");
            return false;
        }
        if (!SubscriptionPackageState.VALIDATED_ID.equals(subscriptionPackage.getState().getId())) {
            log.error("Subscription package is not valid: subscriptionPackage -> {}", subscriptionPackage);
            return false;
        }
        final LocalDate today = LocalDate.now();
        if (null != subscriptionPackage.getStartDate() && today.isBefore(subscriptionPackage.getStartDate())
            || null != subscriptionPackage.getEndDate() && today.isAfter(subscriptionPackage.getEndDate())) {
            log.error("Subscription package date is not valid for today: subscriptionPackage -> {}, today -> {}", subscriptionPackage, today);
            return false;
        }
        final Integer licenceNumber = subscriptionPackage.getLicenceNumber();
        if (licenceNumber != null ) {
            long usedLicenceCount
                = userSubscriptionPaymentService.getSubscriberCountForSubscriptionPackage(subscriptionPackage.getId());
            if (usedLicenceCount > licenceNumber) {
                log.error("Subscription package has no more licence: subscriptionPackage -> {}", subscriptionPackage);
                return false;
            }
        }
        return true;
    }

    public SubscriptionPackage save(SubscriptionPackage subscriptionPackage) {
        if (null == subscriptionPackage.getId()) {
            String code = createPartnerCode();
            subscriptionPackage.setPartnerCode(code);
        }
        return subscriptionPackageRepository.save(subscriptionPackage);
    }

    private String createPartnerCode() {
        String code = Base16.encode(DateTime.now().getMillis() / 1000);
        while (code.startsWith("0")) code = StringUtils.removeStart(code, "0");
        return code;
    }

    public void delete(Long id) {
        SubscriptionPackageState deleted = subscriptionPackageStateRepository.findOne(SubscriptionPackageState.DELETED_ID);
        SubscriptionPackage subscriptionPackage = subscriptionPackageRepository.findOne(id);
        if (null == subscriptionPackage) return;
        subscriptionPackage.setState(deleted);
        subscriptionPackageRepository.save(subscriptionPackage);
    }

}
