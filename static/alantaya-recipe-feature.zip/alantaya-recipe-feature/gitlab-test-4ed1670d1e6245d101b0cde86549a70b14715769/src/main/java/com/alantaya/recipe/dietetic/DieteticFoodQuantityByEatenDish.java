package com.alantaya.recipe.dietetic;


import com.alantaya.recipe.domain.EatenDish;
import com.alantaya.recipe.domain.Food;
import com.alantaya.recipe.domain.FoodQuantityByEatenDish;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class DieteticFoodQuantityByEatenDish extends FoodQuantityByEatenDish implements DieteticStatistic {

    private FoodQuantityByEatenDish foodQuantityByEatenDish;
    private final DieteticFood dieteticFood;

    public DieteticFoodQuantityByEatenDish(FoodQuantityByEatenDish foodQuantityByEatenDish) {
        this.foodQuantityByEatenDish = foodQuantityByEatenDish;
        this.dieteticFood = new DieteticFood(foodQuantityByEatenDish.getFood());
    }

    public DieteticFood getDieteticFood() {
        return dieteticFood;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        Double quantity = dieteticFood.getQuantityFor(dieteticElement) * getAmountInGrams();
        return quantity;
    }

    @Override
    public Long getId() {
        return foodQuantityByEatenDish.getId();
    }

    @Override
    public void setId(Long id) {
        foodQuantityByEatenDish.setId(id);
    }

    @Override
    public Integer getAmountInGrams() {
        return foodQuantityByEatenDish.getAmountInGrams();
    }

    @Override
    public void setAmountInGrams(Integer amountInGrams) {
        foodQuantityByEatenDish.setAmountInGrams(amountInGrams);
    }

    @Override
    public Food getFood() {
        return foodQuantityByEatenDish.getFood();
    }

    @Override
    public void setFood(Food food) {
        foodQuantityByEatenDish.setFood(food);
    }

    @Override
    public EatenDish getEatenDish() {
        return foodQuantityByEatenDish.getEatenDish();
    }

    @Override
    public void setEatenDish(EatenDish eatenDish) {
        foodQuantityByEatenDish.setEatenDish(eatenDish);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFoodQuantityByEatenDish dieteticFoodQuantityByEatenDish = (DieteticFoodQuantityByEatenDish) o;

        return foodQuantityByEatenDish.equals(dieteticFoodQuantityByEatenDish.foodQuantityByEatenDish);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), foodQuantityByEatenDish.getId());
    }

    @Override
    public String toString() {
        return "DieteticFoodQuantityByEatenDish{" +
            "id=" + getId() +
            ", amountInGrams='" + getAmountInGrams() + "'" +
            '}';
    }
}
