package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.CriteriaType;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the CriteriaType entity.
 */
public interface CriteriaTypeRepository extends JpaRepository<CriteriaType,Long> {

}
