package com.alantaya.recipe.dietetic;

public interface DieteticActualStatistic extends DieteticStatistic {

    Double getActualQuantityFor(DieteticElement dieteticElement);

}
