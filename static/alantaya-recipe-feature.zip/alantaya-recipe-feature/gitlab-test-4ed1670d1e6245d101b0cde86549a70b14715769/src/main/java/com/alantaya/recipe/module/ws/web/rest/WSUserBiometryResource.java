package com.alantaya.recipe.module.ws.web.rest;

import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.module.ws.web.rest.dto.UserBiometricDTO;
import com.alantaya.recipe.module.ws.web.rest.mapper.UserBiometryMapper;
import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.BiometricService;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/ws/v1")
@Api(value = "/users")
public class WSUserBiometryResource {

    private final Logger log = LoggerFactory.getLogger(WSUserBiometryResource.class);

    @Inject private BiometricService biometricService;
    @Inject private UserRepository userRepository;
    @Inject private UserBiometryMapper userBiometryMapper;

    @ApiOperation(value = "",
        notes ="You can only add a biometry (not delete it). Each biometry saved is set with the creation date.")
    @RequestMapping(value = "/users/{id}/biometrics",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<Void> addUserBiometry(@PathVariable Long id,
                                                @Valid @RequestBody UserBiometricDTO userBiometryDTO)
        throws URISyntaxException {
        log.debug("REST request to save user biometry : {}", userBiometryDTO);
        User user = userRepository.findOne(id);
        if(user == null) {
            return ResponseEntity.notFound().build();
        }
        biometricService.addBiometricValue(userBiometryMapper.userBiometricDTOToUserBiometric(userBiometryDTO), user);
        return ResponseEntity.ok().build();
    }

    @ApiOperation(value = "",
        notes ="* *Without request parameter:* display only last value saved For each biometry.\n" +
               "* *`from`:* display all biometrics of the user after a specified date.\n" +
               "* *`to`:* display all biometrics of the user before a specified date.\n" +
               "* *Date format is yyyy-MM-dd'T'HH:mm:ss.SSSZ, eg: '2000-10-31T01:30:00.000-05:00'")
    @RequestMapping(value = "/users/{id}/biometrics",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    @RolesAllowed(AuthoritiesConstants.WS)
    @Transactional
    public ResponseEntity<List<UserBiometricDTO>> getAllUserBiometrics(@ApiParam(value = "User id", required = true)
                                                          @PathVariable Long id,
                                                      @ApiParam(value = "display all biometrics after specified date time", required = false)
                                                          @RequestParam(value="from", required = false)
                                                          @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) DateTime from,
                                                      @ApiParam(value = "display all biometrics before specified date time", required = false)
                                                          @RequestParam(value="to", required = false)
                                                          @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) DateTime to) {
        log.debug("REST request to get all current user biometrics for user: {}", id);
        User user = userRepository.findOne(id);
        if(user == null){
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
        }
        if (from == null && to == null) {
            return new ResponseEntity<>(
                userBiometryMapper.userBiometricsToUserBiometricDTOs(
                    biometricService.getLatestBiometricValueByBiometricId(user).values()), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(userBiometryMapper.userBiometricsToUserBiometricDTOs(
            biometricService.getBiometricValuesBetween(user, from, to)), HttpStatus.NOT_FOUND);
    }
}
