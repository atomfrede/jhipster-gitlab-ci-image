package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.util.CustomDateTimeDeserializer;
import com.alantaya.recipe.domain.util.CustomDateTimeSerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserSubscriptionPayment.
 */
@Entity
@Table(name = "USER_SUBSCRIPTION_PAYMENT")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class UserSubscriptionPayment implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "payment_date", nullable = false)
    private DateTime paymentDate;

    @NotNull
    @Min(value = 0)
    @Column(name = "paid_amount", nullable = false)
    private Double paidAmount;

    @NotNull
    @Min(value = 0)
    @Column(name = "duration_in_month", nullable = false)
    private Integer durationInMonth;

    @ManyToOne
    private User user;

    @ManyToOne
    private SubscriptionPackage subscriptionPackage;

    public UserSubscriptionPayment() {
    }

    public UserSubscriptionPayment(User user, SubscriptionPackage subscriptionPackage) {
        super();
        this.paymentDate = DateTime.now();
        this.durationInMonth = subscriptionPackage.getDurationInMonth();
        this.paidAmount = subscriptionPackage.getPrice();
        this.user = user;
        this.subscriptionPackage = subscriptionPackage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public DateTime getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(DateTime paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Integer getDurationInMonth() {
        return durationInMonth;
    }

    public void setDurationInMonth(Integer durationInMonth) {
        this.durationInMonth = durationInMonth;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public SubscriptionPackage getSubscriptionPackage() {
        return subscriptionPackage;
    }

    public void setSubscriptionPackage(SubscriptionPackage subscriptionPackage) {
        this.subscriptionPackage = subscriptionPackage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserSubscriptionPayment userSubscriptionPayment = (UserSubscriptionPayment) o;

        if ( ! Objects.equals(id, userSubscriptionPayment.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserSubscriptionPayment{" +
                "id=" + id +
                ", paymentDate='" + paymentDate + "'" +
                ", paidAmount='" + paidAmount + "'" +
                ", durationInMonth='" + durationInMonth + "'" +
                '}';
    }
}
