package com.alantaya.recipe.module.crm.zoho.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.ArrayList;
import java.util.List;

@XmlRootElement
public class Result {

    @XmlElement(name = "Contacts")
    private Contacts contacts;

    @XmlElement(name = "recorddetail")
    @XmlJavaTypeAdapter(RecordDetailXMLAdapter.class)
    private List<RecordDetail> recordDetails = new ArrayList<>();

    public Result() {}
    public Result(Contacts contacts) {
        this.contacts = contacts;
    }

    public Contacts getContacts() {
        return contacts;
    }

    @XmlTransient
    public void setContacts(Contacts contacts) {
        this.contacts = contacts;
    }

    public List<RecordDetail> getRecordDetails() {
        return recordDetails;
    }

    @XmlTransient
    public void setRecordDetails(List<RecordDetail> recordDetails) {
        this.recordDetails = recordDetails;
    }
}
