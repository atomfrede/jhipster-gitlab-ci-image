package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.FoodFamilyGroup;
import org.joda.time.DateTime;

import java.util.Map;
import java.util.Objects;

public class DieteticFoodFamilyGroup extends FoodFamilyGroup implements DieteticElement, DieteticStatistic {
    private final FoodFamilyGroup foodFamilyGroup;

    public DieteticFoodFamilyGroup(FoodFamilyGroup foodFamilyGroup) {
        this.foodFamilyGroup = foodFamilyGroup;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        return this.equals(dieteticElement) ? 1D : 0D;
    }

    @Override
    public DieteticElement getMacro() {
        return null;
    }

    @Override
    public String getLogName() {
        return getName();
    }

    @Override
    public Long getId() {
        return foodFamilyGroup.getId();
    }

    @Override
    public void setId(Long id) {
        foodFamilyGroup.setId(id);
    }

    @Override
    public String getName() {
        return foodFamilyGroup.getName();
    }

    @Override
    public void setName(String name) {
        foodFamilyGroup.setName(name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticFoodFamilyGroup dieteticFoodFamilyGroup = (DieteticFoodFamilyGroup) o;

        return foodFamilyGroup.equals(dieteticFoodFamilyGroup.foodFamilyGroup);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), foodFamilyGroup.getId());
    }

    @Override
    public String getCreatedBy() {
        return foodFamilyGroup.getCreatedBy();
    }

    @Override
    public void setCreatedBy(String createdBy) {
        foodFamilyGroup.setCreatedBy(createdBy);
    }

    @Override
    public DateTime getCreatedDate() {
        return foodFamilyGroup.getCreatedDate();
    }

    @Override
    public void setCreatedDate(DateTime createdDate) {
        foodFamilyGroup.setCreatedDate(createdDate);
    }

    @Override
    public String getLastModifiedBy() {
        return foodFamilyGroup.getLastModifiedBy();
    }

    @Override
    public void setLastModifiedBy(String lastModifiedBy) {
        foodFamilyGroup.setLastModifiedBy(lastModifiedBy);
    }

    @Override
    public DateTime getLastModifiedDate() {
        return foodFamilyGroup.getLastModifiedDate();
    }

    @Override
    public void setLastModifiedDate(DateTime lastModifiedDate) {
        foodFamilyGroup.setLastModifiedDate(lastModifiedDate);
    }

    @Override
    public String toString() {
        return "DieteticFoodFamilyGroup{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            '}';
    }
}
