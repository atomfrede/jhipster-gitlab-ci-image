package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.Recipe;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.repository.RecipeRepository;
import com.alantaya.recipe.web.rest.dto.RecipeSearchDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Collections;


@Service
public class UserRecipeService {

    @Inject
    private RecipeRepository recipeRepository;

    @Inject
    private UserService userService;


    public Page<Recipe> userRecipeSearch(RecipeSearchDTO params, Pageable page) {

        User user = userService.getUser();
        if (null == user.getAuthor()) return new PageImpl<Recipe>(Collections.<Recipe>emptyList());

        params.setAuthorId(user.getAuthor().getId());
        return recipeRepository.search(params, page);
    }
}
