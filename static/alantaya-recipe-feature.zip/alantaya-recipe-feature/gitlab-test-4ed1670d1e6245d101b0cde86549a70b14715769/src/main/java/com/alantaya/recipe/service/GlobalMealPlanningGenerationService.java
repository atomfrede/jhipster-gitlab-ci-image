package com.alantaya.recipe.service;

import com.alantaya.recipe.domain.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class GlobalMealPlanningGenerationService {

    private final Logger log = LoggerFactory.getLogger(GlobalMealPlanningGenerationService.class);

    @Inject
    private UserService userService;

    @Inject
    private MealPlanningGenerationService mealPlanningGenerationService;

    @Scheduled(cron="0 1 1 * * ?")
    public void generateAndSaveWeeklyMealPlanningForAllUsers() {
        log.debug("Planning generation for all users");
        final List<User> validUsers = userService.getAllValidUser();

        for (final User validUser : validUsers) {
            mealPlanningGenerationService.generateAndSaveWeeklyMealPlanning(validUser.getId());
        }
    }

}
