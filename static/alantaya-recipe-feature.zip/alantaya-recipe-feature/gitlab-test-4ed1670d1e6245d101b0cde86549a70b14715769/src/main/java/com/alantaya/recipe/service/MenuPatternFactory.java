package com.alantaya.recipe.service;

import com.alantaya.recipe.dietetic.DieteticMenuPattern;
import com.alantaya.recipe.domain.MealType;
import com.alantaya.recipe.domain.RecipeType;
import com.alantaya.recipe.domain.User;
import com.alantaya.recipe.domain.UserSetting;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Arrays;
import java.util.List;

@Service
public class MenuPatternFactory {
    public static final List<Long> DEFAULT_MEAL_TYPES = Arrays.asList(MealType.MIDI_ID, MealType.SOIR_ID);
    public static final List<Long> DEFAULT_RECIPE_TYPES = Arrays.asList(RecipeType.ENTREE_ID, RecipeType.PLAT_PRINCIPAL_ID, RecipeType.DESSERT_ID);
    public static final DieteticMenuPattern DEFAULT_DIETETIC_MENU_PATTERN = new DieteticMenuPattern(DEFAULT_MEAL_TYPES, DEFAULT_RECIPE_TYPES);

    @Inject private SettingService settingService;

    public DieteticMenuPattern getUserMenuPattern(User user) {
        final UserSettingType.MENU_COMPOSITION_VALUE menuCompositionValue = getUserSettingMenuComposition(user);
        final List<Long> userSettingRecipesType;
        switch (menuCompositionValue) {
            case STARTER_MAIN_DESERT:
                userSettingRecipesType = Arrays.asList(RecipeType.ENTREE_ID, RecipeType.PLAT_PRINCIPAL_ID, RecipeType.DESSERT_ID);
                break;
            case MAIN_DESERT:
                userSettingRecipesType = Arrays.asList(RecipeType.PLAT_PRINCIPAL_ID, RecipeType.DESSERT_ID);
                break;
            case STARTER_MAIN:
                userSettingRecipesType = Arrays.asList(RecipeType.ENTREE_ID, RecipeType.PLAT_PRINCIPAL_ID);
                break;
            default:
                userSettingRecipesType = DEFAULT_RECIPE_TYPES;
                break;
        }
        return new DieteticMenuPattern(DEFAULT_MEAL_TYPES, userSettingRecipesType);
    }

    private UserSettingType.MENU_COMPOSITION_VALUE getUserSettingMenuComposition(User user) {
        final UserSetting userSetting = settingService.getUserSetting(UserSettingType.MENU_COMPOSITION, user);
        if (userSetting == null || userSetting.getValue() == null ) {
            return UserSettingType.MENU_COMPOSITION_VALUE.STARTER_MAIN_DESERT;
        }
        return UserSettingType.MENU_COMPOSITION_VALUE.valueOf(userSetting.getValue());
    }
}
