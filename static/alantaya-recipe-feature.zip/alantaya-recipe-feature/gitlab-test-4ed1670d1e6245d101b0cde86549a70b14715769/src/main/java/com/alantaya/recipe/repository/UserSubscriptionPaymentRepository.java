package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserSubscriptionPayment;
import org.springframework.data.jpa.repository.*;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for the UserSubscriptionPayment entity.
 */
public interface UserSubscriptionPaymentRepository extends JpaRepository<UserSubscriptionPayment,Long> {

    @Query("select userSubscriptionPayment from UserSubscriptionPayment userSubscriptionPayment " +
        "where userSubscriptionPayment.user.email = ?#{principal.username}")
    List<UserSubscriptionPayment> findAllForCurrentUser();

    UserSubscriptionPayment findFirstByUserIdOrderByPaymentDateDesc(Long userId);
    List<UserSubscriptionPayment> findBySubscriptionPackageId(Long packageId);

    Optional<UserSubscriptionPayment> findByUserIdAndSubscriptionPackageId(Long userId, Long packageId);
}
