package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.UserOAuthCredentials;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the UserOAuthCredentials entity.
 */
public interface UserOAuthCredentialsRepository extends JpaRepository<UserOAuthCredentials,Long> {

    @Query("select userOAuthCredentials from UserOAuthCredentials userOAuthCredentials " +
        "where userOAuthCredentials.user.email = ?#{principal.username}")
    List<UserOAuthCredentials> findAllForCurrentUser();

    void deleteByUserId(Long userId);

    UserOAuthCredentials findByUserId(Long userId);

}
