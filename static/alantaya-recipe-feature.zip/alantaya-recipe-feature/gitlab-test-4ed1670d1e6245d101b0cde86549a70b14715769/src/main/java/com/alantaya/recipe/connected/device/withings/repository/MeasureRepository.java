package com.alantaya.recipe.connected.device.withings.repository;

import com.alantaya.recipe.connected.device.withings.domain.MeasureResult;
import com.alantaya.recipe.connected.device.withings.domain.util.WithingsJsonDeserializer;
import oauth.signpost.OAuthConsumer;
import org.apache.commons.io.IOUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import javax.inject.Inject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@Component
public class MeasureRepository {

    private final Logger log = LoggerFactory.getLogger(MeasureRepository.class);

    private final static String BASE_URL = "https://wbsapi.withings.net/measure?action=getmeas";

    private final static String USER_ID = "userid";
    private final static String START_DATE = "startdate";
    private final static String END_DATE = "enddate";
    private final static String LAST_UPDATE = "lastupdate";
    private final static String MEAS_TYPE = "meastype";
    private final static String CATEGORY = "category";

    private final static String CATEGORY_REAL_MEASURE = "1";
    private final static String MEAS_TYPE_WEIGHT = "1";

    @Inject
    private WithingsJsonDeserializer withingsJsonDeserializer;

    public MeasureResult findAll(OAuthConsumer consumer, Long providerUserId) {
        UriComponentsBuilder uriBuilder = initUrl(providerUserId);
        return getMeasureResult(consumer, uriBuilder.toUriString());
    }

    public MeasureResult findByDateBetween(OAuthConsumer consumer,
                                           Long providerUserId,
                                           DateTime startDate,
                                           DateTime endDate) {
        UriComponentsBuilder uriBuilder = initUrl(providerUserId);
        uriBuilder.queryParam(START_DATE, startDate.getMillis() / 1000);
        uriBuilder.queryParam(END_DATE, endDate.getMillis() / 1000);
        return getMeasureResult(consumer, uriBuilder.toUriString());
    }

    public MeasureResult findByDateAfter(OAuthConsumer consumer, Long providerUserId, DateTime fromDate) {
        UriComponentsBuilder uriBuilder = initUrl(providerUserId);
        uriBuilder.queryParam(LAST_UPDATE, fromDate.getMillis() / 1000);
        return getMeasureResult(consumer, uriBuilder.toUriString());
    }

    private UriComponentsBuilder initUrl(Long providerUserId) {
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(BASE_URL);
        uriBuilder.queryParam(MEAS_TYPE, MEAS_TYPE_WEIGHT);
        uriBuilder.queryParam(CATEGORY, CATEGORY_REAL_MEASURE);
        uriBuilder.queryParam(USER_ID, providerUserId);
        return uriBuilder;
    }

    private MeasureResult getMeasureResult(OAuthConsumer consumer, String url) {
        try {
            url = consumer.sign(url);
            String jsonResponse = executeRequest(url);
            return withingsJsonDeserializer.deserializeMeasureResult(jsonResponse);
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }

    private String executeRequest(String signedUrl) throws Exception {
        log.debug("execute request : {}", signedUrl);

        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(signedUrl).openConnection();
        httpURLConnection.connect();

        int responseCode = httpURLConnection.getResponseCode();

        if (responseCode != HttpURLConnection.HTTP_OK) {
            throw new Exception("Illegal response code: " + responseCode);
        }

        InputStream inputStream = httpURLConnection.getInputStream();
        return IOUtils.toString(inputStream, "UTF-8");
    }

}
