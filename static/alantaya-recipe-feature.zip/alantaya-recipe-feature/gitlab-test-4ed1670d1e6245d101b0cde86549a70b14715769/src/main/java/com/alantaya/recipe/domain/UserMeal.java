package com.alantaya.recipe.domain;

import com.alantaya.recipe.domain.util.CustomLocalDateSerializer;
import com.alantaya.recipe.domain.util.ISO8601LocalDateDeserializer;
import com.alantaya.recipe.web.rest.dto.View;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A UserMeal.
 */
@Entity
@Table(name = "USER_MEAL")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserMeal implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
    @JsonSerialize(using = CustomLocalDateSerializer.class)
    @JsonDeserialize(using = ISO8601LocalDateDeserializer.class)
    @Column(name = "date", nullable = false)
    private LocalDate date;

    @ManyToOne(fetch =  FetchType.LAZY)
    @JsonIgnore
    private User user;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "USER_MEAL__RECIPES",
        joinColumns = @JoinColumn(name="meal_id", referencedColumnName="ID"),
        inverseJoinColumns = @JoinColumn(name="recipe_id", referencedColumnName="ID"))
    @JsonView(View.WithContainedEager.class)
    private Set<Recipe> recipes = new HashSet<>();

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "USER_MEAL__EATEN_DISH",
        joinColumns = @JoinColumn(name="meal_id", referencedColumnName="ID"),
        inverseJoinColumns = @JoinColumn(name="eaten_dish_id", referencedColumnName="ID"))
    @JsonView(View.WithContainedEager.class)
    private Set<EatenDish> eatenDishes = new HashSet<>();

    @ManyToOne
    private MealType mealType;

    public UserMeal() {}
    public UserMeal(LocalDate date,
                    User user,
                    Set<Recipe> recipes,
                    Set<EatenDish> eatenDishes,
                    MealType mealType) {
        this.date = date;
        this.user = user;
        this.recipes = recipes;
        this.eatenDishes = eatenDishes;
        this.mealType = mealType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Set<Recipe> getRecipes() {
        return recipes;
    }

    public void setRecipes(Set<Recipe> recipes) {
        this.recipes = recipes;
    }

    public Set<EatenDish> getEatenDishes() {
        return eatenDishes;
    }

    public void setEatenDishes(Set<EatenDish> eatenDishes) {
        this.eatenDishes = eatenDishes;
    }

    public MealType getMealType() {
        return mealType;
    }

    public void setMealType(MealType mealType) {
        this.mealType = mealType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserMeal meal = (UserMeal) o;

        return Objects.equals(id, meal.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "UserMeal{" +
            "id=" + id +
            ", date=" + date +
            '}';
    }
}
