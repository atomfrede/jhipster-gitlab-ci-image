package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.Biometry;
import com.alantaya.recipe.domain.Food;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Biometry entity.
 */
public interface BiometryRepository extends JpaRepository<Biometry,Long> {

    @Query("select biometry " +
        "from Biometry biometry " +
        "left join fetch biometry.unit ")
    @Override
    List<Biometry> findAll();
}
