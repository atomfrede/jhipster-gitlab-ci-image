/**
 * JPA domain objects.
 */
package com.alantaya.recipe.domain;
