package com.alantaya.recipe.module.ws.config;

import com.alantaya.recipe.repository.UserRepository;
import com.alantaya.recipe.security.AuthoritiesConstants;
import com.alantaya.recipe.service.SupervisionService;
import com.alantaya.recipe.service.UserTokenService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.Http403ForbiddenEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.inject.Inject;

@Configuration
@EnableWebSecurity
@Order(99)
public class WSSecurityConfig extends WebSecurityConfigurerAdapter {

    @Inject private UserTokenService userTokenService;
    @Inject private UserRepository userRepository;
    @Inject private SupervisionService supervisionService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .antMatcher("/ws/**")
            .csrf().disable()
            .authorizeRequests()
                .antMatchers("/ws/v1/**").hasAuthority(AuthoritiesConstants.WS)
            .and()
                .addFilterBefore(new AuthenticationFilter(authenticationManager()), BasicAuthenticationFilter.class)
                .addFilterAfter(new SupervisorRightCheckFilter(userRepository, supervisionService), BasicAuthenticationFilter.class)
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
                .exceptionHandling().authenticationEntryPoint(new Http403ForbiddenEntryPoint());
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(tokenAuthenticationProvider());
    }

    @Bean
    public AuthenticationProvider tokenAuthenticationProvider() {
        return new TokenAuthenticationProvider(userTokenService);
    }
}
