package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.CostLevel;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the CostLevel entity.
 */
public interface CostLevelRepository extends JpaRepository<CostLevel,Long> {

}
