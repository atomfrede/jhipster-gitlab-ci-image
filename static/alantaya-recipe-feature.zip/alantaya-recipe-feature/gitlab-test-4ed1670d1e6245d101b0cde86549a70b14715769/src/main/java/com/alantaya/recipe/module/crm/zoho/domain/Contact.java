package com.alantaya.recipe.module.crm.zoho.domain;

import net.karneim.pojobuilder.GeneratePojoBuilder;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
@GeneratePojoBuilder(intoPackage = "com.alantaya.recipe.util.builder")
public class Contact {
    //When new contact attribute, add it in the unmarshaller of @ContactXMLAdapter

    @XmlAttribute
    private int no = 0;

    private Field zohoId;

    private Field contactOwner;

    private Field firstName;

    private Field lastName;

    private Field accountName;

    private Field email;

    private Field createdBy;

    private Field modifiedBy;

    private Field createdTime;

    private Field modifiedTime;

    private Field lastActivityTime;

    private Field typeDeProspect;

    private Field bilanDietetique;

    private Field teleConseil;

    public int getNo() {
        return no;
    }

    @XmlTransient
    public void setNo(int no) {
        this.no = no;
    }

    public Field getZohoId() {
        return zohoId;
    }

    @XmlTransient
    public void setZohoId(String zohoId) {
        this.zohoId = new Field("Id");
        this.zohoId.setValue(zohoId);
    }

    public Field getEmail() {
        return email;
    }

    @XmlTransient
    public void setEmail(String email) {
        this.email = new Field("Email");
        this.email.setValue(email);
    }

    public Field getFirstName() {
        return firstName;
    }

    @XmlTransient
    public void setFirstName(String firstName) {
        this.firstName= new Field("First Name");
        this.firstName.setValue(firstName);
    }

    public Field getLastName() {
        return lastName;
    }

    @XmlTransient
    public void setLastName(String lastName) {
        this.lastName = new Field("Last Name");
        this.lastName.setValue(lastName);
    }

    public Field getContactOwner() {
        return contactOwner;
    }

    @XmlTransient
    public void setContactOwner(String contactOwner) {
        this.contactOwner = new Field("Contact Owner");
        this.contactOwner.setValue(contactOwner);
    }

    public Field getAccountName() {
        return accountName;
    }

    @XmlTransient
    public void setAccountName(String accountName) {
        this.accountName = new Field("Account Name");
        this.accountName.setValue(accountName);
    }

    public Field getCreatedBy() {
        return createdBy;
    }

    @XmlTransient
    public void setCreatedBy(String createdBy) {
        this.createdBy = new Field("Created By");
        this.createdBy.setValue(createdBy);
    }

    public Field getModifiedBy() {
        return modifiedBy;
    }

    @XmlTransient
    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = new Field("Modified By");
        this.modifiedBy.setValue(modifiedBy);
    }

    public Field getCreatedTime() {
        return createdTime;
    }

    @XmlTransient
    public void setCreatedTime(String createdTime) {
        this.createdTime = new Field("Created Time");
        this.createdTime.setValue(createdTime);
    }

    public Field getModifiedTime() {
        return modifiedTime;
    }

    @XmlTransient
    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = new Field("Modified Time");
        this.modifiedTime.setValue(modifiedTime);
    }

    public Field getLastActivityTime() {
        return lastActivityTime;
    }

    @XmlTransient
    public void setLastActivityTime(String lastActivityTime) {
        this.lastActivityTime = new Field("Last Activity Time");
        this.lastActivityTime.setValue(lastActivityTime);
    }

    public Field getTypeDeProspect() {
        return typeDeProspect;
    }

    @XmlTransient
    public void setTypeDeProspect(String typeDeProspect) {
        this.typeDeProspect = new Field("Type de Prospect");
        this.typeDeProspect.setValue(typeDeProspect);
    }

    public Field getBilanDietetique() {
        return bilanDietetique;
    }

    @XmlTransient
    public void setBilanDietetique(String bilanDietetique) {
        this.bilanDietetique = new Field("Bilan diététique");
        this.bilanDietetique.setValue(bilanDietetique);
    }

    public Field getTeleConseil() {
        return teleConseil;
    }

    @XmlTransient
    public void setTeleConseil(String teleConseil) {
        this.teleConseil = new Field("Télé-conseil");
        this.teleConseil.setValue(teleConseil);
    }

    @Override
    public String toString() {
        return "Contact{" +
            "no=" + no +
            ", zohoId=" + zohoId +
            ", contactOwner=" + contactOwner +
            ", firstName=" + firstName +
            ", lastName=" + lastName +
            ", accountName=" + accountName +
            ", email=" + email +
            ", createdBy=" + createdBy +
            ", modifiedBy=" + modifiedBy +
            ", createdTime=" + createdTime +
            ", modifiedTime=" + modifiedTime +
            ", lastActivityTime=" + lastActivityTime +
            ", typeDeProspect=" + typeDeProspect +
            ", bilanDietetique=" + bilanDietetique +
            ", teleConseil=" + teleConseil +
            '}';
    }
}
