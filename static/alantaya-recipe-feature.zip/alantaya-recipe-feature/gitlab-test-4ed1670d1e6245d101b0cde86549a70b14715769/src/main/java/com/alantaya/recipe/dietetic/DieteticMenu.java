package com.alantaya.recipe.dietetic;

import com.alantaya.recipe.domain.*;
import org.joda.time.LocalDate;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class DieteticMenu extends UserMeal implements DieteticStatistic, DieteticActualStatistic {
    private final UserMeal meal;
    private final List<DieteticRecipe> dieteticRecipes;
    private final List<DieteticEatenDish> dieteticEatenDishes;
    private final HashMap<DieteticElement, Double> quantityByDieteticElement;
    private final HashMap<DieteticElement, Double> actualQuantityByDieteticElement;

    public DieteticMenu(LocalDate date, List<DieteticRecipe> dieteticRecipes, MealType type) {
        this(new UserMeal());
        setDate(date);
        setMealType(type);
        getRecipes().addAll(
            dieteticRecipes.stream()
                .map(DieteticRecipe::getRecipe)
                .collect(Collectors.toList())
        );
        this.dieteticRecipes.addAll(dieteticRecipes);
    }

    public DieteticMenu(UserMeal meal) {
        this.meal = meal;
        this.dieteticRecipes = meal.getRecipes().stream()
            .map(DieteticRecipe::new)
            .collect(Collectors.toList());
        this.dieteticEatenDishes = meal.getEatenDishes().stream()
            .map(DieteticEatenDish::new)
            .collect(Collectors.toList());
        this.quantityByDieteticElement = new HashMap<>();
        this.actualQuantityByDieteticElement = new HashMap<>();
    }

    public List<DieteticRecipe> getDieteticRecipes() {
        return dieteticRecipes;
    }

    public List<DieteticEatenDish> getDieteticEatenDishes() {
        return dieteticEatenDishes;
    }

    @Override
    public Double getQuantityFor(DieteticElement dieteticElement) {
        if (! quantityByDieteticElement.containsKey(dieteticElement)) {
            Double quantity = dieteticRecipes.stream()
                .mapToDouble(recipe -> recipe.getQuantityFor(dieteticElement))
                .sum();
            quantityByDieteticElement.put(dieteticElement, quantity);
        }
        return quantityByDieteticElement.get(dieteticElement);
    }

    @Override
    public Double getActualQuantityFor(DieteticElement dieteticElement) {
        if (dieteticEatenDishes.isEmpty()) return getQuantityFor(dieteticElement);
        if (! actualQuantityByDieteticElement.containsKey(dieteticElement)) {
            Double quantity = dieteticEatenDishes.stream()
                .mapToDouble(eatenDish -> eatenDish.getQuantityFor(dieteticElement))
                .sum();
            actualQuantityByDieteticElement.put(dieteticElement, quantity);
        }
        return actualQuantityByDieteticElement.get(dieteticElement);
    }

    public UserMeal getUserMeal() {
        return meal;
    }

    @Override
    public Long getId() {
        return meal.getId();
    }

    @Override
    public void setId(Long id) {
        meal.setId(id);
    }

    @Override
    public LocalDate getDate() {
        return meal.getDate();
    }

    @Override
    public void setDate(LocalDate date) {
        meal.setDate(date);
    }

    @Override
    public User getUser() {
        return meal.getUser();
    }

    @Override
    public void setUser(User user) {
        meal.setUser(user);
    }

    @Override
    public Set<Recipe> getRecipes() {
        return meal.getRecipes();
    }

    @Override
    public void setRecipes(Set<Recipe> recipes) {
        meal.setRecipes(recipes);
    }

    @Override
    public Set<EatenDish> getEatenDishes() {
        return meal.getEatenDishes();
    }

    @Override
    public void setEatenDishes(Set<EatenDish> eatenDishes) {
        meal.setEatenDishes(eatenDishes);
    }

    @Override
    public MealType getMealType() {
        return meal.getMealType();
    }

    @Override
    public void setMealType(MealType mealType) {
        meal.setMealType(mealType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DieteticMenu dieteticMenu = (DieteticMenu) o;

        return meal.equals(dieteticMenu.meal);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getClass().getCanonicalName(), meal.getId());
    }

    @Override
    public String toString() {
        return "DieteticUserMeal{" +
            "id=" + getId() +
            ", date=" + getDate() +
            '}';
    }
}
