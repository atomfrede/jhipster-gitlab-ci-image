package com.alantaya.recipe.repository;

import com.alantaya.recipe.domain.FoodQuantityByRecipe;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the FoodQuantityByRecipe entity.
 */
public interface FoodQuantityByRecipeRepository extends JpaRepository<FoodQuantityByRecipe,Long> {

}
