package com.alantaya.recipe.payment.hipay.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "mapi")
@XmlAccessorType(XmlAccessType.FIELD)
public class PaymentNotification {

    private String mapiversion;
    private String md5content;
    private PaymentNotificationResult result;

    public String getMapiversion() {
        return mapiversion;
    }

    public void setmapiversion(String mapiversion) {
        this.mapiversion = mapiversion;
    }

    public String getMd5content() {
        return md5content;
    }

    public void setMd5content(String md5content) {
        this.md5content = md5content;
    }

    public PaymentNotificationResult getResult() {
        return result;
    }

    public void setResult(PaymentNotificationResult result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "PspNotification{" +
                "mapiversion='" + mapiversion + '\'' +
                ", md5content='" + md5content + '\'' +
                ", result=" + result +
                '}';
    }

}
