'use strict';

var app = angular.module('recipeApp', ['LocalStorageModule', 'tmh.dynamicLocale',
    'ngResource', 'ui.router', 'ngCookies', 'pascalprecht.translate',
    'ngCacheBuster', 'infinite-scroll', 'monospaced.elastic', 'flow',
    'ui.select', 'ngSanitize', 'ui.bootstrap']);

app.config(function ($stateProvider, $urlRouterProvider, $httpProvider, $locationProvider, $translateProvider,
                        tmhDynamicLocaleProvider, httpRequestInterceptorCacheBusterProvider, flowFactoryProvider,
                        $cookiesProvider) {
        //enable CSRF
        $httpProvider.defaults.xsrfCookieName = 'CSRF-TOKEN';
        $httpProvider.defaults.xsrfCookieName = 'CSRF-TOKEN';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRF-TOKEN';

        $httpProvider.interceptors.push(function($q) {
            return {
                'responseError': function(rejection) {
                    if (rejection.status == 401
                        && ! (rejection.config.url.startsWith('api/account')
                        || rejection.config.url.startsWith('api/authentication')
                        || rejection.config.url.startsWith('api/otpAuthentication'))) {
                        window.open('/#/login', 'Login', "width=300,height=400,scrollbars=yes");
                    }
                    return $q.reject(rejection);
                }
            };
        });

        //Cache everything except rest api requests
        httpRequestInterceptorCacheBusterProvider.setMatchlist([/.*api.*/, /.*protected.*/], true);

        $urlRouterProvider.otherwise('/');
        $stateProvider.state('site', {
            'abstract': true,
            views: {
                'navbar@': {
                    templateUrl: 'scripts/components/navbar/navbar.html',
                    controller: 'NavbarController'
                }
            },
            resolve: {
                authorize: ['Auth',
                    function (Auth) {
                        return Auth.authorize();
                    }
                ],
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('global');
                    $translatePartialLoader.addPart('language');
                    return $translate.refresh();
                }]
            }
        });


        // Initialize angular-translate
        $translateProvider.translations('en', {
                "recipeApp": {
                    "recipe" : {
                        "home": {
                            "title": "Recettes",
                            "createLabel": "Créer une nouvelle recette",
                            "editLabel": "Editer une recette"
                        },
                        "delete": {
                            "question": "Etes-vous certain de vouloir supprimer la recette {{ title }} ?"
                        },
                        "detail": {
                            "title": "Recette"
                        },
                        "form": {
                            "title": "Recette"
                        },
                        "title": "Titre",
                        "summary": "Description de la recette en une phrase",
                        "sharesNumber": "Nombre de convives ou de pièces",
                        "preparationTime": "Temps de préparation",
                        "cookingTime": "Temps de cuisson",
                        "restTime": "Temps de repos",
                        "betterPreparedInAdvance": "À l'avance",
                        "betterPreparedInAdvanceText": "Ce plat est encore meilleur s'il est préparé à l'avance",
                        "image": "Photographie de la recette",
                        "advice": "Conseil",
                        "type": "Type de la recette",
                        "categories": "Catégories",
                        "categoriesSelect": "Sélectionner une catégorie",
                        "costLevel": "Coût",
                        "difficultyLevel": "Difficulté",
                        "quantityUnit": "",
                        "foodQuantities": "Ingrédients",
                        "foodQuantitiesSelect": "Sélectionner un ingrédient",
                        "steps": "Préparation",
                        "cookingMode": "Mode de cuisson",
                        "cookingModeSelect": "Sélectionner une cuisson",
                        "durableLife": "Durée de conservation",
                        "durableLifeSelect": "Selectionner une durée de conservation",
                        "season": "Saison",
                        "editorNo": "Aucun éditeur",
                        "editor": "© Éditeur",
                        "editorSelect": "Selectionner un éditeur",
                        "authorNo": "Aucun auteur",
                        "author": "Auteur",
                        "authorSelect": "Selectionner un auteur",
                        "originCountry": "Pays d'origine",
                        "originCountrySelect": "Sélectionner un pays d'origine",
                        "originRegion": "Région",
                        "originRegionSelect": "Selectionner une region",
                        "theme": "Thêmes et fêtes",
                        "themeSelect": "Sélectionner un thême/fête",
                        "recipeProfile": "Profil",
                        "recipeProfileSelect": "Sélectionner un profil",
                        "selectImage": "Sélectionner une image",
                        "changeImage": "Changer",
                        "removeImage": "Supprimer",
                        "uploadImage": "Télécharger",
                        "completeImage": "Fini",
                        "draft": "Draft",
                        "noImage": "Aucune image",
                        "restrictionTextImage1": "Format accepté: jpg, jpeg ou png",
                        "restrictionTextImage2": "Taille maximum: 10Mo",
                        "lastModifiedBy": "Modifié par",
                        "lastModifiedDate": "Modifié le",
                        "state": "État",
                        "stepNumber": "Etape {{ stepNumber }}",
                        "stepAction": {
                            "delete": "Supprimer",
                            "add": "Ajouter"
                        },
                        "foodQuantityAction": {
                            "delete": "Supprimer",
                            "add": "Ajouter"
                        },
                        "photographer": "Photographe",
                        "photographerSelect": "Sélectionner un photographe",
                        "search": {
                            "withImage" : "Avec image",
                            "containsBasicFoods": "Contient les aliments",
                            "doesNotContainsBasicFoods": "Ne contient pas les aliments",
                            "with": "Avec",
                            "without": "Sans"
                        }
                    }
                }
            });

        $translateProvider.preferredLanguage('fr');
        $translateProvider.useCookieStorage();

        tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');
        tmhDynamicLocaleProvider.useCookieStorage('NG_TRANSLATE_LANG_KEY');

        // Initialize ng-flow
        flowFactoryProvider.defaults = {
            permanentErrors: [404, 500, 501],
            headers: function (file, chunk, isTest) {
                var token = $cookiesProvider.$get()[$httpProvider.defaults.xsrfCookieName];
                return {
                    'X-CSRF-TOKEN': token
                }
            }
        };
        flowFactoryProvider.on('catchAll', function (event) {
            console.log('catchAll', arguments);
        });
    })
    .controller('RecipeBloggerFormController', function (
      $scope, $rootScope, $state, $stateParams
      ) {
        $scope.recipe = {};
        $scope.recipetypes = [
          {id: 1, label: 'Entrée'},
          {id: 2, label: 'Plat principal' },
          {id: 3, label: 'Dessert'},
          {id: 4, label: 'Boissons'},
          {id: 5, label: 'Sauces et bouillons'},
          {id: 6, label: 'Bases'}
        ];

        $scope.recipecategorys = [
          {id: 1, label: 'Amuse-gueule et feuilleté'},
          {id: 2, label: 'Salade'},
          {id: 3, label: 'Soupe'},
          {id: 	4, label: 'Terrine, dip'},
          {id: 	5, label: 'A base de viande'},
          {id: 	6, label: 'A base de poisson'},
          {id: 	7, label: 'A base de fromage'},
          {id: 	8, label: 'Végétarien'},
          {id: 	9, label: 'Sandwich, cake et tarte salé'},
          {id: 	10, label: 'fruit, salade de fruit, sorbet'},
          {id: 	11, label: 'Tarte, cake et gâteau'},
          {id: 	12, label: 'Dessert lacté (crême, flan, mousse)'},
          {id: 	13, label: 'Glace et confiserie'},
          {id: 	14, label: 'boissons, cocktails'},
          {id: 	15, label: 'à base de légumes'},
          {id: 	16, label: 'sucré-salé'},
          {id: 	17, label: 'pâtes, risotto'},
          {id: 	18, label: 'bases'}];
        $scope.costlevels = [{ id:1, label: 'Economique' },
                             { id:2, label: 'Raisonnable' },
                             { id:3, label: 'Cher' }];
        $scope.difficultylevels = [{ id:1, label: 'Débutant' },
                             { id:2, label: 'Initié' },
                             { id:3, label: 'Expert' }];
        $scope.recipequantityunits = [{ id:1, label: 'Grammes', shortLabel: 'g' },
                                      { id:2, label: 'Centilitre', shortLabel: 'cl'  },
                                      { id:3, label: 'Décilitre', shortLabel: 'dl'  }];
        $scope.cookingmodes = [{ id:1, label: 'Grammes', shortLabel: 'g' },
                                      { id:2, label: 'Centilitre', shortLabel: 'cl'  },
                                      { id:3, label: 'Décilitre', shortLabel: 'dl'  }];
        $scope.recipedurablelifes = [{id: 1, label: 'Journée'},
                                    {id: 2, label: 'Semaine'},
                                    {id: 3, label: 'Température ambiante (frais/sec)'},
                                    {id: 4, label: 'Réfrigérateur'},
                                    {id: 5, label: 'Congélateur'},
                                    {id: 6, label: 'Aucune (au moment)'},
                                    {id: 7, label: 'au sec dans une boite hermétique'}];
        $scope.seasons = [{ id:1, label: 'Printemps'},
                          { id:2, label: 'Été'},
                          { id:3, label: 'Automne'},
                          { id:4, label: 'Hiver'},
                          { id:5, label: 'Toute saison'}];
        $scope.countrys = [{id: 1, code: 4, alpha2: 'AF', alpha3: 'AFG', 	name_en: 'Afghanistan', name_fr:'Afghanistan'},
                        	{id: 2, code: 8, alpha2: 'Al'  , alpha3: 	'ALB', 	name_en: 'Albania', name_fr:'Albanie'},
                          {id: 4, code: 12 , alpha2: 	'DZ', alpha3: 'DZA', 	name_en: 'Algeria', name_fr:'Algérie'},
                          {id: 6, code: 20, alpha2: 'AD' , alpha3: 'AND', 	name_en: 'Andorra', name_fr:'Andorre'}];
        $scope.regions = [{id: 1, code: 11, name:'Île-de-France'},
                           {id: 2, code: 21, name:'Champagne-Ardenne'},
                           {id: 3, code: 22, name:'Picardie'},
                           {id: 4, code: 23, name:'Haute-Normandie'}];
        $scope.recipethemes = [];
        $scope.recipeprofiles = [];
        //$scope.recipestates = RecipeState.query();
        $scope.foods = [{id: 	1000, Name: '	Pastis	', completeName: '	Pastis	', density: 	1	},
{id: 	1001, Name: '	Eau de vie	', completeName: '	Eau de vie	', density: 	1	},
{id: 	1002, Name: '	Gin	', completeName: '	Gin	', density: 	1	},
{id: 	1003, Name: '	Liqueur	', completeName: '	Liqueur	', density: 	1	},
{id: 	1004, Name: '	Rhum	', completeName: '	Rhum	', density: 	1	},
{id: 	1005, Name: '	Whisky	', completeName: '	Whisky	', density: 	1	},
{id: 	1006, Name: '	Vin doux	', completeName: '	Vin doux	', density: 	1	},
{id: 	1007, Name: '	Apéritif à base de vin ou vermouth	', completeName: '	Apéritif à base de vin ou vermouth	', density: 	1	},
{id: 	1008, Name: '	Vodka	', completeName: '	Vodka	', density: 	1	},
{id: 	1009, Name: '	Apéritif à la gentiane	', completeName: '	Apéritif à la gentiane	', density: 	1	},
{id: 	1010, Name: '	Pastis, prêt à boire (1+ 5)	', completeName: '	Pastis, prêt à boire (1+ 5)	', density: 	1	},
{id: 	1011, Name: '	Apéritif anisé sans alcool	', completeName: '	Apéritif anisé sans alcool	', density: 	1	},
{id: 	1017, Name: '	Sangria	', completeName: '	Sangria	', density: 	1	},
{id: 	1018, Name: '	Kir (au vin blanc)	', completeName: '	Kir (au vin blanc)	', density: 	1	},
{id: 	1019, Name: '	Kir royal (au champagne)	', completeName: '	Kir royal (au champagne)	', density: 	1	},
{id: 	2000, Name: '	Ananas, jus à base de concentré	', completeName: '	Ananas, jus à base de concentré	', density: 	1	},
{id: 	2002, Name: '	Jus multifruit, pur jus, multivitaminé	', completeName: '	Jus multifruit, pur jus, multivitaminé	', density: 	1	},
{id: 	2004, Name: '	Jus de fruits (aliment moyen)	', completeName: '	Jus de fruits (aliment moyen)	', density: 	1	},
{id: 	2006, Name: '	Carotte, pur jus	', completeName: '	Carotte, pur jus	', density: 	1	},
{id: 	2007, Name: '	Citron jaune, jus pressé maison	', completeName: '	Citron jaune, jus pressé maison	', density: 	1	},
{id: 	2008, Name: '	Cocktail sans alcool	', completeName: '	Cocktail sans alcool (à base de jus de fruits et de sirop)	', density: 	1	},
{id: 	2009, Name: '	Nectar multifruit - base pomme, standard	', completeName: '	Nectar multifruit - base pomme, standard	', density: 	1	},
{id: 	2010, Name: '	Nectar multifruit - base pomme, multivitaminé	', completeName: '	Nectar multifruit - base pomme, multivitaminé	', density: 	1	},
{id: 	2011, Name: '	Jus multifruit - base orange, multivitaminé	', completeName: '	Jus multifruit - base orange, multivitaminé	', density: 	1	},
{id: 	2012, Name: '	Orange, jus à base de concentré	', completeName: '	Orange, jus à base de concentré	', density: 	1	},
{id: 	2013, Name: '	Orange, jus pressé maison	', completeName: '	Orange, jus pressé maison	', density: 	1	},
{id: 	2014, Name: '	Pomme, jus à base de concentré	', completeName: '	Pomme, jus à base de concentré	', density: 	1	},
{id: 	2015, Name: '	Pamplemousse (pomélo), jus à base de concentré	', completeName: '	Pamplemousse (pomélo), jus à base de concentré	', density: 	1	},
{id: 	2016, Name: '	Raisin, pur jus	', completeName: '	Raisin, pur jus	', density: 	1	},
{id: 	2021, Name: '	Jus de tomate	', completeName: '	Tomate, pur jus	', density: 	1	},
{id: 	2023, Name: '	Mangue, jus frais	', completeName: '	Mangue, jus frais	', density: 	1	},
{id: 	2025, Name: '	Pamplemousse (pomélo), jus frais	', completeName: '	Pamplemousse (pomélo), jus frais	', density: 	1	},
{id: 	2027, Name: '	Pamplemousse (pomélo), pur jus	', completeName: '	Pamplemousse (pomélo), pur jus	', density: 	1	},
{id: 	2031, Name: '	Citron vert, pur jus	', completeName: '	Citron vert, pur jus	', density: 	1	},
{id: 	2034, Name: '	Clémentine/mandarine, pur jus	', completeName: '	Clémentine/mandarine, pur jus	', density: 	1	},
{id: 	2035, Name: '	Jus multifruit, pur jus, standard	', completeName: '	Jus multifruit, pur jus, standard	', density: 	1	},
{id: 	2038, Name: '	Jus multifruit - base orange, standard	', completeName: '	Jus multifruit - base orange, standard	', density: 	1	},
{id: 	2043, Name: '	Abricot, nectar	', completeName: '	Abricot, nectar	', density: 	1	},
{id: 	2048, Name: '	Jus multifruit - base pomme, standard	', completeName: '	Jus multifruit - base pomme, standard	', density: 	1	},
{id: 	2050, Name: '	Jus multifruit - base pomme, multivitaminé	', completeName: '	Jus multifruit - base pomme, multivitaminé	', density: 	1	},
{id: 	2054, Name: '	Poire, nectar	', completeName: '	Poire, nectar	', density: 	1	},
{id: 	2060, Name: '	Nectar multifruit, multivitaminé	', completeName: '	Nectar multifruit, multivitaminé	', density: 	1	},
{id: 	2061, Name: '	Nectar multifruit, standard	', completeName: '	Nectar multifruit, standard	', density: 	1	},
{id: 	2062, Name: '	Nectar multifruit - base orange, multivitaminé	', completeName: '	Nectar multifruit - base orange, multivitaminé	', density: 	1	},
{id: 	2063, Name: '	Nectar multifruit - base orange, standard	', completeName: '	Nectar multifruit - base orange, standard	', density: 	1	},
{id: 	2069, Name: '	Jus multifruit, à base de concentré	', completeName: '	Jus multifruit, à base de concentré	', density: 	1	},
{id: 	2070, Name: '	Orange, pur jus	', completeName: '	Orange, pur jus	', density: 	1	},
{id: 	2073, Name: '	Ananas, pur jus	', completeName: '	Ananas, pur jus	', density: 	1	},
{id: 	2074, Name: '	Pomme, pur jus	', completeName: '	Pomme, pur jus	', density: 	1	},
{id: 	2075, Name: '	Légumes, pur jus (aliment moyen)	', completeName: '	Légumes, pur jus (aliment moyen)	', density: 	1	},
{id: 	2076, Name: '	Pomme, nectar	', completeName: '	Pomme, nectar	', density: 	1	},
{id: 	2365, Name: '	Fruit de la passion ou Maracuja, nectar	', completeName: '	Fruit de la passion ou Maracuja, nectar	', density: 	1	},
{id: 	2370, Name: '	Mangue, nectar	', completeName: '	Mangue, nectar	', density: 	1	},
{id: 	2375, Name: '	Orange, nectar	', completeName: '	Orange, nectar	', density: 	1	},
{id: 	4002, Name: '	Pulpe de pomme de terre	', completeName: '	Pomme de terre, pulpe, cuite au four	', density: 	1	},
{id: 	4003, Name: '	Pomme de terre à l eau	', completeName: '	Pomme de terre, cuite à l eau	', density: 	1	},
{id: 	4004, Name: '	Chips	', completeName: '	Pomme de terre, chips salées	', density: 	1	},
{id: 	4005, Name: '	Frite	', completeName: '	Pomme de terre frite ou Frite, cuite, non salée	', density: 	1	},
{id: 	4006, Name: '	Pomme de terre en robe des champs à la vapeur	', completeName: '	Pomme de terre avec peau, cuite à la vapeur	', density: 	1	},
{id: 	4010, Name: '	Frite	', completeName: '	Pomme de terre frite ou Frite, surgelée, cuite, non salée	', density: 	1	},
{id: 	4013, Name: '	Pomme noisette	', completeName: '	Pomme de terre, noisette, précuite, surgelée	', density: 	1	},
{id: 	4016, Name: '	Flocons déshydratés au lait	', completeName: '	Pomme de terre, flocons déshydratés au lait	', density: 	1	},
{id: 	4018, Name: '	Purée de pomme de terre	', completeName: '	Pomme de terre, purée, avec lait et beurre, non salée	', density: 	1	},
{id: 	4019, Name: '	Purée de flocons pomme de terre	', completeName: '	Pomme de terre, purée, à base de flocons, reconstituée avec lait demi-écrémé et eau, non salée	', density: 	1	},
{id: 	4021, Name: '	Pomme dauphine	', completeName: '	Pomme de terre dauphine, cuite	', density: 	1	},
{id: 	4027, Name: '	Pomme rissolée	', completeName: '	Pomme de terre, rissolée, surgelée	', density: 	1	},
{id: 	4102, Name: '	Patate douce	', completeName: '	Patate douce, cuite	', density: 	1	},
{id: 	5000, Name: '	Bière brune	', completeName: '	Bière brune	', density: 	1	},
{id: 	5001, Name: '	Bière coeur de marché (4-5° alcool)	', completeName: '	Bière coeur de marché (4-5° alcool)	', density: 	1	},
{id: 	5002, Name: '	Bière forte (>8° alcool)	', completeName: '	Bière forte (>8° alcool)	', density: 	1	},
{id: 	5003, Name: '	Cidre (aliment moyen)	', completeName: '	Cidre (aliment moyen)	', density: 	1	},
{id: 	5004, Name: '	Panaché (bière + limonade)	', completeName: '	Panaché (bière + limonade)	', density: 	1	},
{id: 	5006, Name: '	Cidre brut	', completeName: '	Cidre brut	', density: 	1	},
{id: 	5007, Name: '	Cidre doux	', completeName: '	Cidre doux	', density: 	1	},
{id: 	5010, Name: '	Bière spéciale (5-6° alcool)	', completeName: '	Bière spéciale (5-6° alcool)	', density: 	1	},
{id: 	5011, Name: '	Bière de spécialités ou d abbaye	', completeName: '	Bière de spécialités ou d abbaye, régionales ou d une brasserie (degré d alcool variable)	', density: 	1	},
{id: 	5020, Name: '	Cidre traditionnel	', completeName: '	Cidre traditionnel	', density: 	1	},
{id: 	5030, Name: '	Bière sans alcool (<1,2° alcool)	', completeName: '	Bière sans alcool (<1,2° alcool)	', density: 	1	},
{id: 	5100, Name: '	Pétillant de fruits	', completeName: '	Pétillant de fruits	', density: 	1	},
{id: 	5200, Name: '	Vin blanc sec	', completeName: '	Vin blanc 11°	', density: 	1	},
{id: 	5201, Name: '	Vin blanc mousseux	', completeName: '	Vin blanc mousseux	', density: 	1	},
{id: 	5202, Name: '	Vin rouge  9°	', completeName: '	Vin rouge  9°	', density: 	1	},
{id: 	5203, Name: '	Vin rouge 10°	', completeName: '	Vin rouge 10°	', density: 	1	},
{id: 	5204, Name: '	Vin rouge 11°	', completeName: '	Vin rouge 11°	', density: 	1	},
{id: 	5205, Name: '	Vin rouge 12°	', completeName: '	Vin rouge 12°	', density: 	1	},
{id: 	5206, Name: '	Vin rosé 11°	', completeName: '	Vin rosé 11°	', density: 	1	},
{id: 	5207, Name: '	Champagne	', completeName: '	Champagne	', density: 	1	},
{id: 	5208, Name: '	Vin rouge 13°	', completeName: '	Vin rouge 13°	', density: 	1	},
{id: 	5210, Name: '	Vin (aliment moyen)	', completeName: '	Vin (aliment moyen)	', density: 	1	},
{id: 	6100, Name: '	Entrecote de boeuf	', completeName: '	Boeuf, entrecôte, grillée	', density: 	1	},
{id: 	6101, Name: '	Boeuf braisé	', completeName: '	Boeuf, braisé	', density: 	1	},
{id: 	6103, Name: '	Entrecote de boeuf	', completeName: '	Boeuf, entrecôte, crue	', density: 	1	},
{id: 	6110, Name: '	Faux-filet de boeuf	', completeName: '	Boeuf, faux-filet, grillé	', density: 	1	},
{id: 	6111, Name: '	Faux-filet de boeuf	', completeName: '	Boeuf, faux-filet, cru	', density: 	1	},
{id: 	6121, Name: '	Flanchet de boeuf	', completeName: '	Boeuf, flanchet, cuit	', density: 	1	},
{id: 	6122, Name: '	Plat de cote de boeuf	', completeName: '	Boeuf, plat de côtes, cru	', density: 	1	},
{id: 	6130, Name: '	Hampe de boeuf	', completeName: '	Boeuf, hampe, crue	', density: 	1	},
{id: 	6140, Name: '	Joue de boeuf	', completeName: '	Boeuf, joue, crue	', density: 	1	},
{id: 	6160, Name: '	Tende de tranche de boeuf	', completeName: '	Boeuf, tende de tranche, crue	', density: 	1	},
{id: 	6200, Name: '	Bifteck de boeuf	', completeName: '	Boeuf, bifteck, grillé	', density: 	1	},
{id: 	6202, Name: '	Macreuse de boeuf	', completeName: '	Boeuf, macreuse, crue	', density: 	1	},
{id: 	6210, Name: '	Rosbif	', completeName: '	Boeuf, rosbif, rôti	', density: 	1	},
{id: 	6212, Name: '	Bavette de boeuf	', completeName: '	Boeuf, bavette, crue	', density: 	1	},
{id: 	6220, Name: '	Boeuf à Bourguignon	', completeName: '	Boeuf, à bourguignon, cuit	', density: 	1	},
{id: 	6230, Name: '	Boeuf à pot-au-feu	', completeName: '	Boeuf, à pot-au-feu, cuit	', density: 	1	},
{id: 	6250, Name: '	Steak haché  5% MG	', completeName: '	Steak haché  5% MG, cru	', density: 	1	},
{id: 	6251, Name: '	Steak haché  5% MG	', completeName: '	Steak haché  5% MG, cuit	', density: 	1	},
{id: 	6252, Name: '	Steak haché 10% MG	', completeName: '	Steak haché 10% MG, cru	', density: 	1	},
{id: 	6253, Name: '	Steak haché 10% MG	', completeName: '	Steak haché 10% MG, cuit	', density: 	1	},
{id: 	6254, Name: '	Steak haché 15% MG	', completeName: '	Steak haché 15% MG, cru	', density: 	1	},
{id: 	6255, Name: '	Steak haché 15% MG	', completeName: '	Steak haché 15% MG, cuit	', density: 	1	},
{id: 	6256, Name: '	Steak haché 20% MG	', completeName: '	Steak haché 20% MG, cru	', density: 	1	},
{id: 	6257, Name: '	Steak haché 20% MG	', completeName: '	Steak haché 20% MG, cuit	', density: 	1	},
{id: 	6270, Name: '	Paleron de boeuf	', completeName: '	Boeuf, paleron, cru	', density: 	1	},
{id: 	6510, Name: '	Cote de veau	', completeName: '	Veau, côte, crue	', density: 	1	},
{id: 	6511, Name: '	Cote de veau	', completeName: '	Veau, côte, cuite	', density: 	1	},
{id: 	6520, Name: '	Escalope de veau	', completeName: '	Veau, escalope, cuite	', density: 	1	},
{id: 	6522, Name: '	Noix de veau	', completeName: '	Veau, noix, crue	', density: 	1	},
{id: 	6531, Name: '	Filet de veau	', completeName: '	Veau, filet, rôti	', density: 	1	},
{id: 	6540, Name: '	Poitrine de veau	', completeName: '	Veau, poitrine, crue	', density: 	1	},
{id: 	6550, Name: '	Roti de veau	', completeName: '	Veau, rôti	', density: 	1	},
{id: 	6560, Name: '	Epaule de veau	', completeName: '	Veau, épaule, crue	', density: 	1	},
{id: 	6570, Name: '	Mojoté de veau	', completeName: '	Veau, mijoté	', density: 	1	},
{id: 	6583, Name: '	Jarret de veau	', completeName: '	Veau, jarret, cru	', density: 	1	},
{id: 	6590, Name: '	Collier de veau	', completeName: '	Veau, collier, cru	', density: 	1	},
{id: 	6902, Name: '	Viande de Cheval	', completeName: '	Cheval, viande, rôtie	', density: 	1	},
{id: 	6903, Name: '	Tende de tranche de Cheval	', completeName: '	Cheval, tende de tranche, crue	', density: 	1	},
{id: 	6904, Name: '	Faux filet de Cheval	', completeName: '	Cheval, faux-filet, cru	', density: 	1	},
{id: 	6905, Name: '	Entrecote de Cheval	', completeName: '	Cheval, entrecôte muscle, cru	', density: 	1	},
{id: 	6999, Name: '	Viande cuite (aliment moyen)	', completeName: '	Viande cuite (aliment moyen)	', density: 	1	},
{id: 	7001, Name: '	Baguette	', completeName: '	Pain, baguette, courante	', density: 	1	},
{id: 	7004, Name: '	Pain grillé	', completeName: '	Pain grillé, domestique	', density: 	1	},
{id: 	7012, Name: '	Boule de pain	', completeName: '	Pain courant français, 400g ou boule	', density: 	1	},
{id: 	7100, Name: '	Boule de pain de campagne	', completeName: '	Pain, baguette ou boule, de campagne	', density: 	1	},
{id: 	7110, Name: '	Pain complet ou intégral (à la farine T150)	', completeName: '	Pain complet ou intégral (à la farine T150)	', density: 	1	},
{id: 	7111, Name: '	Pain de mie complet	', completeName: '	Pain de mie, complet	', density: 	1	},
{id: 	7113, Name: '	Pain de mie multicéréale	', completeName: '	Pain de mie, multicéréale	', density: 	1	},
{id: 	7125, Name: '	Pain de seigle froment	', completeName: '	Pain de seigle, et froment	', density: 	1	},
{id: 	7126, Name: '	Pain de seigle au raison	', completeName: '	Pain de seigle, aux raisins	', density: 	1	},
{id: 	7160, Name: '	Baguette sans sel	', completeName: '	Pain, baguette, sans sel	', density: 	1	},
{id: 	7180, Name: '	Pain pita	', completeName: '	Pain pita	', density: 	1	},
{id: 	7200, Name: '	Pain de mie	', completeName: '	Pain de mie, courant	', density: 	1	},
{id: 	7225, Name: '	Pain brioché ou viennois	', completeName: '	Pain brioché ou viennois	', density: 	1	},
{id: 	7255, Name: '	Boule de pain aux céréales	', completeName: '	Pain, baguette ou boule, aux céréales et graines, artisanal	', density: 	1	},
{id: 	7300, Name: '	Biscotte classique	', completeName: '	Biscotte classique	', density: 	1	},
{id: 	7310, Name: '	Biscotte sans adjonction de sel	', completeName: '	Biscotte sans adjonction de sel	', density: 	1	},
{id: 	7330, Name: '	Biscotte multicéréale	', completeName: '	Biscotte multicéréale	', density: 	1	},
{id: 	7340, Name: '	Biscotte complète ou riche en fibres	', completeName: '	Biscotte complète ou riche en fibres	', density: 	1	},
{id: 	7400, Name: '	Pain grillé, tranches, au froment	', completeName: '	Pain grillé, tranches, au froment	', density: 	1	},
{id: 	7407, Name: '	Pain grillé suédois au froment	', completeName: '	Pain grillé suédois au froment	', density: 	1	},
{id: 	7410, Name: '	Tartine craquante, extrudée et grillée	', completeName: '	Tartine craquante, extrudée et grillée	', density: 	1	},
{id: 	7411, Name: '	Tartine craquante, extrudée et grillée, fourrée au chocolat ou aux fruits	', completeName: '	Tartine craquante, extrudée et grillée, fourrée au chocolat ou aux fruits	', density: 	1	},
{id: 	7412, Name: '	Tartine craquante, extrudée et grillée, fourrée au chocolat	', completeName: '	Tartine craquante, extrudée et grillée, fourrée au chocolat	', density: 	1	},
{id: 	7413, Name: '	Tartine craquante, extrudée et grillée, fourrée aux fruits	', completeName: '	Tartine craquante, extrudée et grillée, fourrée aux fruits	', density: 	1	},
{id: 	7420, Name: '	Pain grillé suédois au blé complet	', completeName: '	Pain grillé suédois au blé complet	', density: 	1	},
{id: 	7425, Name: '	Pain grillé, tranches, multicéréale	', completeName: '	Pain grillé, tranches, multicéréale	', density: 	1	},
{id: 	7430, Name: '	Croûtons	', completeName: '	Croûtons	', density: 	1	},
{id: 	7500, Name: '	Chapelure	', completeName: '	Chapelure	', density: 	1	},
{id: 	7525, Name: '	Gressins	', completeName: '	Gressins	', density: 	1	},
{id: 	7601, Name: '	Croissant ordinaire ou au beurre	', completeName: '	Croissant ordinaire ou au beurre	', density: 	1	},
{id: 	7615, Name: '	Croissant ordinaire, artisanal	', completeName: '	Croissant ordinaire, artisanal	', density: 	1	},
{id: 	7620, Name: '	Croissant au beurre, artisanal	', completeName: '	Croissant au beurre, artisanal	', density: 	1	},
{id: 	7650, Name: '	Croissant aux amandes, artisanal	', completeName: '	Croissant aux amandes, artisanal	', density: 	1	},
{id: 	7710, Name: '	Pain au lait, artisanal	', completeName: '	Pain au lait, artisanal	', density: 	1	},
{id: 	7711, Name: '	Pain au lait	', completeName: '	Pain au lait, préemballé	', density: 	1	},
{id: 	7720, Name: '	Pain aux raisins (viennoiserie)	', completeName: '	Pain aux raisins (viennoiserie)	', density: 	1	},
{id: 	7730, Name: '	Pain au chocolat feuilleté, artisanal	', completeName: '	Pain au chocolat feuilleté, artisanal	', density: 	1	},
{id: 	7740, Name: '	Brioche, préemballée	', completeName: '	Brioche, préemballée	', density: 	1	},
{id: 	7741, Name: '	Brioche artisanale	', completeName: '	Brioche artisanale	', density: 	1	},
{id: 	7742, Name: '	Brioche, de boulangerie traditionnelle	', completeName: '	Brioche, de boulangerie traditionnelle	', density: 	1	},
{id: 	7812, Name: '	Fougasse, garnie	', completeName: '	Fougasse, garnie	', density: 	1	},
{id: 	7814, Name: '	Cake salé (garniture : fromage, légumes, viande, poisson, volaille, etc.)	', completeName: '	Cake salé (garniture : fromage, légumes, viande, poisson, volaille, etc.)	', density: 	1	},
{id: 	8000, Name: '	Rillettes traditionnelles de porc	', completeName: '	Rillettes traditionnelles de porc	', density: 	1	},
{id: 	8001, Name: '	Rillettes pur porc	', completeName: '	Rillettes pur porc	', density: 	1	},
{id: 	8055, Name: '	Rillettes de volailles	', completeName: '	Rillettes de viandes autres que pur porc (volaille...)	', density: 	1	},
{id: 	8081, Name: '	Rillettes de saumon	', completeName: '	Rillettes de saumon	', density: 	1	},
{id: 	8082, Name: '	Rillettes de thon	', completeName: '	Rillettes de thon	', density: 	1	},
{id: 	8110, Name: '	Confit de canard	', completeName: '	Confit de canard	', density: 	1	},
{id: 	8211, Name: '	Pâté de campagne	', completeName: '	Pâté de campagne	', density: 	1	},
{id: 	8232, Name: '	Terrine de canard	', completeName: '	Terrine de canard	', density: 	1	},
{id: 	8240, Name: '	Pâté de lapin	', completeName: '	Pâté de lapin	', density: 	1	},
{id: 	8291, Name: '	Terrine de poisson	', completeName: '	Terrine de poisson	', density: 	1	},
{id: 	8292, Name: '	Pâté à base de poisson	', completeName: '	Pâté à base de poisson ou de crustacés	', density: 	1	},
{id: 	8293, Name: '	Tarama	', completeName: '	Tarama préemballé	', density: 	1	},
{id: 	8295, Name: '	Mousse de poisson	', completeName: '	Mousse de poisson	', density: 	1	},
{id: 	8296, Name: '	Terrine ou mousse de légumes	', completeName: '	Terrine ou mousse de légumes	', density: 	1	},
{id: 	8305, Name: '	Pâté de foie de porc	', completeName: '	Pâté de foie de porc	', density: 	1	},
{id: 	8313, Name: '	Mousse de foie	', completeName: '	Mousse de foie	', density: 	1	},
{id: 	8316, Name: '	Pâté de foie de volaille	', completeName: '	Pâté de foie de volaille	', density: 	1	},
{id: 	8320, Name: '	Foie gras	', completeName: '	Foie gras, appertisé	', density: 	1	},
{id: 	8322, Name: '	Foie gras de canard entier	', completeName: '	Foie gras de canard, entier, appertisé	', density: 	1	},
{id: 	8350, Name: '	Galantine	', completeName: '	Galantine	', density: 	1	},
{id: 	8391, Name: '	Pâté en croûte	', completeName: '	Pâté en croûte	', density: 	1	},
{id: 	8395, Name: '	Jambon en croûte	', completeName: '	Jambon en croûte	', density: 	1	},
{id: 	8400, Name: '	Fromage de tête	', completeName: '	Fromage de tête	', density: 	1	},
{id: 	8406, Name: '	Museau de porc vinaigrette	', completeName: '	Museau de porc vinaigrette	', density: 	1	},
{id: 	8504, Name: '	Andouille	', completeName: '	Andouille, réchauffée à la poêle	', density: 	1	},
{id: 	8551, Name: '	Andouillette	', completeName: '	Andouillette, poêlée	', density: 	1	},
{id: 	8601, Name: '	Tripes à la mode de Caen	', completeName: '	Tripes à la mode de Caen	', density: 	1	},
{id: 	8704, Name: '	Boudin noir	', completeName: '	Boudin noir, poêlé	', density: 	1	},
{id: 	8800, Name: '	Boudin blanc	', completeName: '	Boudin blanc, poêlé	', density: 	1	},
{id: 	8913, Name: '	Quenelle de volaille	', completeName: '	Quenelle de volaille, appertisée	', density: 	1	},
{id: 	8934, Name: '	Quenelle de poisson	', completeName: '	Quenelle de poisson, cuite	', density: 	1	},
{id: 	8935, Name: '	Quenelle	', completeName: '	Quenelle au naturel, appertisée	', density: 	1	},
{id: 	8936, Name: '	Quenelle en sauce	', completeName: '	Quenelle en sauce, appertisée	', density: 	1	},
{id: 	9081, Name: '	Blé dur	', completeName: '	Blé dur précuit, grains entiers, cuit	', density: 	1	},
{id: 	9102, Name: '	Riz complet	', completeName: '	Riz complet, sec	', density: 	1	},
{id: 	9103, Name: '	Riz complet	', completeName: '	Riz complet, cuit	', density: 	1	},
{id: 	9104, Name: '	Riz blanc	', completeName: '	Riz blanc, cuit	', density: 	1	},
{id: 	9105, Name: '	Riz blanc	', completeName: '	Riz blanc étuvé, cuit	', density: 	1	},
{id: 	9108, Name: '	Riz sauvage	', completeName: '	Riz sauvage, sec	', density: 	1	},
{id: 	9109, Name: '	Riz rouge	', completeName: '	Riz rouge, sec	', density: 	1	},
{id: 	9110, Name: '	Riz rouge	', completeName: '	Riz rouge, cuit	', density: 	1	},
{id: 	9111, Name: '	Riz sauvage	', completeName: '	Riz sauvage, cuit	', density: 	1	},
{id: 	9230, Name: '	Pop-corn ou Maïs éclaté, à l huile, salé	', completeName: '	Pop-corn ou Maïs éclaté, à l huile, salé	', density: 	1	},
{id: 	9231, Name: '	Pop-corn ou Maïs éclaté, à l air, non salé	', completeName: '	Pop-corn ou Maïs éclaté, à l air, non salé	', density: 	1	},
{id: 	9313, Name: '	Flocons d avoine, cuits à l eau	', completeName: '	Flocons d avoine, cuits à l eau	', density: 	1	},
{id: 	9410, Name: '	Farine de blé tendre T110	', completeName: '	Blé (ou froment), farine T110	', density: 	1	},
{id: 	9415, Name: '	Farine de blé tendre T150	', completeName: '	Blé (ou froment), farine T150	', density: 	1	},
{id: 	9436, Name: '	Farine de blé tendre T55 (pour pains)	', completeName: '	Blé (ou froment), farine T55 (pour pains)	', density: 	1	},
{id: 	9445, Name: '	Farine de blé tendre T80	', completeName: '	Blé (ou froment), farine T80	', density: 	1	},
{id: 	9533, Name: '	Farine de seigle T130	', completeName: '	Seigle, farine T130	', density: 	1	},
{id: 	9540, Name: '	Farine de sarrasin	', completeName: '	Sarrasin, farine	', density: 	1	},
{id: 	9570, Name: '	Farine de châtaigne	', completeName: '	Châtaigne, farine	', density: 	1	},
{id: 	9614, Name: '	Semoule de maïs	', completeName: '	Semoule de maïs, sec	', density: 	1	},
{id: 	9615, Name: '	Polenta	', completeName: '	Polenta ou semoule de maïs, cuite	', density: 	1	},
{id: 	9660, Name: '	Germe de blé	', completeName: '	Germe de blé	', density: 	1	},
{id: 	9683, Name: '	Couscous	', completeName: '	Couscous, graine cuite	', density: 	1	},
{id: 	9811, Name: '	Pâtes	', completeName: '	Pâtes alimentaires cuites	', density: 	1	},
{id: 	9816, Name: '	Pâtes aux oeufs	', completeName: '	Pâtes alimentaires aux oeufs, fraîches, cuites	', density: 	1	},
{id: 	9822, Name: '	Pâtes aux oeufs	', completeName: '	Pâtes alimentaires aux oeufs, cuites	', density: 	1	},
{id: 	9870, Name: '	Pâtes au blé complet	', completeName: '	Pâtes alimentaires au blé complet, crues	', density: 	1	},
{id: 	9871, Name: '	Pâtes au blé complet	', completeName: '	Pâtes alimentaires au blé complet, cuites	', density: 	1	},
{id: 	9900, Name: '	Vermicelle de riz	', completeName: '	Riz, vermicelle sèche	', density: 	1	},
{id: 	9901, Name: '	Vermicelle de riz	', completeName: '	Riz, vermicelle cuite	', density: 	1	},
{id: 	9902, Name: '	Vermicelle de soja	', completeName: '	Soja, vermicelle sèche	', density: 	1	},
{id: 	9903, Name: '	Vermicelle de soja	', completeName: '	Soja, vermicelle cuite	', density: 	1	}];
        $scope.authors = [];
        $scope.editors = [];
        $scope.photographers = [];

        $scope.uploader = {};

        $scope.load = function (id, isDuplicate) {
                $scope.recipe = {title: null, summary: null, sharesNumber: 1,
                    preparationTime: 0, cookingTime: 0, restTime: 0,
                    betterPreparedInAdvance: null, advice: null, id: null,
                    state: {id: 1},
                    steps : [{stepNumber: 0, content: "", id: null, recipeId: $scope.recipe.id}],
                    foodQuantities : [{id: null, amountInGrams: 0, food: null}]
                };
        };

        $scope.addStep = function () {
            if (typeof $scope.recipe.steps === "undefined") $scope.recipe.steps = [];
            var stepNumber = $scope.recipe.steps.length;
            $scope.recipe.steps.push({
                    stepNumber: stepNumber, content: "", id: null
                });
        };

        $scope.removeStep = function (index) {
            $scope.recipe.steps.splice(index,  1);
            var index = 0;
            for (var step in $scope.recipe.steps) {
                $scope.recipe.steps[index].stepNumber = index;
                index = 1 + index;
            }
        };

        $scope.addFoodQuantity = function () {
            if (typeof $scope.recipe.foodQuantities === "undefined") $scope.recipe.foodQuantities = [];
            var foodQuantity = $scope.recipe.foodQuantities.length;
            $scope.recipe.foodQuantities.push({id: null, amountInGrams: 0, food: null});
        };

        $scope.removeFoodQuantity = function (index) {
            $scope.recipe.foodQuantities.splice(index,  1);
        };

        $scope.removeAccents = function (source) {
            var accent = [
                    /[\300-\306]/g, /[\340-\346]/g, // A, a
                    /[\310-\313]/g, /[\350-\353]/g, // E, e
                    /[\314-\317]/g, /[\354-\357]/g, // I, i
                    /[\322-\330]/g, /[\362-\370]/g, // O, o
                    /[\331-\334]/g, /[\371-\374]/g, // U, u
                    /[\321]/g, /[\361]/g, // N, n
                    /[\307]/g, /[\347]/g, // C, c
                ],
                noaccent = ['A','a','E','e','I','i','O','o','U','u','N','n','C','c'];

            for (var i = 0; i < accent.length; i++){
                source = source.replace(accent[i], noaccent[i]);
            }

            return source;
        };

        $scope.expectContainsOneWord = function (actual, expected) {
            if (! expected) return true;
            if (angular.isNumber(actual)) return angular.equals(actual, expected);
            var words = expected.split(" ");
            var hasAllWords = true;
            for (var index in words) {
                var upperActual = $scope.removeAccents('' + angular.uppercase(actual));
                var upperExpected = $scope.removeAccents('' + angular.uppercase(words[index]));
                hasAllWords &= upperActual.indexOf(upperExpected) >= 0;
            }
            return hasAllWords;
        };

        $scope.load($stateParams.id, $stateParams.isDuplicate);
    });
