	function setupRadio() {
        if ($('.radio input').length) {
			
            $('.radio .inline').each(function(){ 
                $(this).parent().find('label').removeClass('checked');
            });
            $('.radio input:checked').each(function(){
                $(this).parent('label').addClass('checked');
            });
        }
		
	}	
	
	
	
	function setupCheck() {
        if ($('.checkbox input').length) {
 
            $('.checkbox input:checked').each(function(){ 
                $(this).parent('label').toggleClass('checked');
            });                
        };
		
  };
  
  

$(document).ready(function(){
	
	//1st run, cherche checked="checked" dans les inputs et applique la classe
	
	 $('.radio input:checked').each(function(){
                $(this).parent('label').addClass('checked');
            });
			
			 $('.checkbox input:checked').each(function(){
                $(this).parent('label').addClass('checked');
            });
			
			

		 $('.radio label').click(function(){
            setupRadio();
        });

 $('.checkbox label').click(function(){
            setupCheck();
        });

});




  if ($('#maChecklist').length) {
	  
	  var isClosed= false;
	  $('#maChecklist h3').css({'cursor':'pointer'});
	  $('#maChecklist h3').click(function(){
		 if(isClosed== false){
		 $('#maChecklist ul').slideUp()
		 isClosed= true;}
		 else{
		$('#maChecklist ul').slideDown();
		 isClosed= false;
		 }
		  
	  });
	  
 
	$(window).scroll(function() {
						var theOffset = Math.round($('#preparation').offset().top);
						var maChecklistHeight = $('#maChecklist').outerHeight() + parseInt($('#maChecklist').css('margin-top'));
						var preparationHeight = $('#preparation').outerHeight();				
								if(($(window).scrollTop() - theOffset > 0)&&($(window).scrollTop() - theOffset < preparationHeight - maChecklistHeight)){									
										$('#maChecklist').css({'position':'fixed'});							
								}else{
								$('#maChecklist').css({'position':'absolute'});	
								};
										 
	});

  }