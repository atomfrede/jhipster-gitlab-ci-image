'use strict';

angular.module('recipeApp')
    .controller('RecipeBloggerController', function ($scope, $rootScope, ParseLinks,
                                                     Recipe, UserRecipeSearch, RecipeType, RecipeCategory, CostLevel, DifficultyLevel,
                                                     RecipeQuantityUnit, BasicFood, RecipeStep, CookingMode,
                                                     RecipeDurableLife, Season, Country, Region, RecipeTheme, RecipeProfile,
                                                     RecipeState, User) {
        $scope.recipesDraft = [];
        $scope.recipesSaved = [];
        $scope.recipesValidated = [];
        $scope.recipetypes = RecipeType.query();
        $scope.recipestates = RecipeState.query();
        $scope.seasons = Season.query();
        $scope.countries = Country.query();
        $scope.regions = Region.query();
        $scope.cookingmodes = CookingMode.query();
        $scope.basicFoods = BasicFood.list();
        $scope.costLevels = CostLevel.query();
        $scope.difficultyLevels = DifficultyLevel.query();
        $scope.users = User.query();
        $scope.totalElementsDraft = 0;
        $scope.totalElementsSaved = 0;
        $scope.totalElementsValidated = 0;
        $scope.totalPagesDraft = 0;
        $scope.totalPagesSaved = 0;
        $scope.totalPagesValidated = 0;

        $scope.loadDraft = function () {
            $rootScope.recipeSearchParams.stateId = 4;
            //TODO insert macro for recipe state
            UserRecipeSearch.query($rootScope.recipeSearchParams, function (result, headers) {
                $scope.linksDraft = ParseLinks.parse(headers('link'));
                $scope.recipesDraft = result.content;
                $scope.totalElementsDraft = result.totalElements;
                $scope.totalPagesDraft = result.totalPages;
            });
        };

        $scope.loadSaved = function () {
            $rootScope.recipeSearchParams.stateId = 1;
            //TODO insert macro for recipe state
            UserRecipeSearch.query($rootScope.recipeSearchParams, function (result, headers) {
                $scope.linksSaved = ParseLinks.parse(headers('link'));
                $scope.recipesSaved = result.content;
                $scope.totalElementsSaved = result.totalElements;
                $scope.totalPagesSaved = result.totalPages;
            });
        };

        $scope.loadValidated = function () {
            $rootScope.recipeSearchParams.stateId = 2;
            //TODO insert macro for recipe state
            UserRecipeSearch.query($rootScope.recipeSearchParams, function (result, headers) {
                $scope.linksValidated = ParseLinks.parse(headers('link'));
                $scope.recipesValidated = result.content;
                $scope.totalElementsValidated = result.totalElements;
                $scope.totalPagesValidated = result.totalPages;
            });
        };

        $scope.loadAll = function () {
            $rootScope.recipeSearchParams.per_page = 5;// TODO heu...  je le veux que pour cette page
            $scope.loadDraft();
            $scope.loadSaved();
            $scope.loadValidated();
        };

        $scope.loadPageDraft = function (page) {
            $rootScope.recipeSearchParams.page = page; //TODO  faut separer les trois listes
            $scope.loadDraft();
        };

        $scope.loadPageSaved = function (page) {
            $rootScope.recipeSearchParams.page = page;//TODO  faut separer les trois listes
            $scope.loadSaved();
        };

        $scope.loadPageValidated = function (page) {
            $rootScope.recipeSearchParams.page = page;//TODO  faut separer les trois listes
            $scope.loadValidated();
        };

        $scope.delete = function (id) {
            Recipe.get({id: id}, function (result) {
                $scope.recipe = result;
                $('#deleteRecipeConfirmation').modal('show');
            });
        };

        $scope.confirmDelete = function (id) {
            Recipe.delete({id: id},
                function () {
                    $scope.loadAll();
                    $('#deleteRecipeConfirmation').modal('hide');
                });
        };

        $scope.resetSearch = function () {
            $rootScope.recipeSearchParams = {
                page: 1,
                per_page: 5,
                sort: 'title,asc',
                stateId: '',
                TypeId: '',
                seasonId: ''
            };
        };


        $scope.search = function () {
            $rootScope.recipeSearchParams.page = 1;
            $scope.loadAll();
        };

        $scope.open = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened = true;
        };

        if (!$rootScope.recipeSearchParams) $scope.resetSearch();
        $scope.loadAll();
    });
