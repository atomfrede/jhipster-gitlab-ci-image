Alantaya
==========================

<table>
  <thead>
    <tr>
      <th>Branche</th>
      <th>Statut</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>master</td>
      <td><a href="https://gitlab.alantaya.com/ci/projects/1?ref=master"><img src="https://gitlab.alantaya.com/ci/projects/1/status.png?ref=master" alt="Java Build Status"></a></td>
    </tr>
    <tr>
      <td>develop</td>
      <td><a href="https://gitlab.alantaya.com/ci/projects/1?ref=develop"><img src="https://gitlab.alantaya.com/ci/projects/1/status.png?ref=develop" alt="Java Build Status"></a></td>
    </tr>
  </tbody>
</table>